=== Barnd AI SEO ===
Contributors: barndai
Tags: seo, sitemap, schema, local seo, image alt, redirects, 404, search console
Requires at least: 6.0
Tested up to: 6.6
Requires PHP: 7.4
Stable tag: 1.0.0-rc26
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Lightweight WordPress SEO cleanup, audits, schema, sitemap, image ALT checks, local SEO, redirects, 404 monitoring, and Google Performance Import.

== Description ==

Barnd AI SEO helps busy website owners, bloggers, local businesses, restaurants, affiliate publishers, and agencies find common WordPress SEO issues without a complicated setup.

The Free version focuses on practical SEO cleanup inside WordPress:

* SEO title and meta description fields
* Canonical URL and noindex controls
* Open Graph and X/Twitter social tags
* Safe schema for websites, articles, local businesses, and restaurants
* Domain sitemap
* LLMs.txt output
* SEO Audit & Quick Fixes dashboard
* Missing image ALT checks with direct table editing
* Local SEO and restaurant fields
* 404 monitor
* Redirect manager
* Internal link scanner
* SEO Plugin Check for compatible Yoast SEO, AIOSEO, and Rank Math data
* Affiliate disclosure warning
* Health, nutrition, franchise, and claim-risk warnings
* Google Performance Import using a Search Console Pages export

Barnd AI SEO Free works locally without requiring an account, license key, external AI key, or cloud connection. It also includes an optional Barnd AI Cloud page where site owners can register a Free site online with api.barndai.com, receive a Cloud Site ID, sync Free plan status, and prepare for future Pro features. Free tools continue to work if registration is skipped or if the cloud API is unavailable.

== Installation ==

1. Upload the plugin folder to `/wp-content/plugins/` or install the ZIP from WordPress admin.
2. Activate Barnd AI SEO.
3. Open Barnd AI SEO from the WordPress admin menu.
4. Run the Setup Wizard to choose your site type and import existing site information.
5. Run the SEO Audit and review the Fix These First items.

== Frequently Asked Questions ==

= Does the Free version use AI? =

No. This Free build is local and manual. AI draft tools are planned for a future Pro version connected through Barnd AI Cloud.

= Does this plugin send my content to an external service? =

No. The Free version does not require a Barnd AI account and does not send your content to Barnd AI Cloud. If an admin clicks Register Free Site Online, the plugin sends only basic connection details such as site URL, home URL, plugin slug/version, WordPress version, PHP version, selected site type, setup mode, plan, locale, timezone, and generated local Site ID. Post content, page content, media files, uploaded Google Performance reports, customer data, visitor analytics, admin usernames/emails, order data, scan dumps, and private SEO settings are not sent during Free registration.

= Why is Barnd AI Cloud included in Free? =

Barnd AI Cloud is included as an optional Free registration and Pro-preparation screen. Free SEO tools continue to work without registration, but registration helps Barnd AI count active Free sites, assign a Cloud Site ID, sync plan status, and prepare future license/Pro features.

= What is Google Performance Import? =

It lets you upload or paste a Google Search Console Pages export so the plugin can highlight pages with impressions, low click-through rate, or ranking positions worth improving.

= Can I use this with Yoast, AIOSEO, or Rank Math? =

Use only one plugin to output live SEO metadata and sitemaps on a production site. Barnd AI SEO includes an SEO Plugin Check tool to help you review existing SEO plugin data before cleaning anything.

== External Services ==

Barnd AI SEO Free works locally without registration. If the site administrator clicks Register Free Site Online, the plugin sends a request to `https://api.barndai.com/v1/sites/register`. If the administrator clicks Sync Site Status, the plugin sends a request to `https://api.barndai.com/v1/sites/status`.

These requests are used to assign and sync a Barnd Cloud Site ID, Free plan status, and feature flags. The request may include: site URL, home URL, plugin slug, plugin version, WordPress version, PHP version, selected site type, setup mode, plan, locale, timezone, local Site ID, and Cloud Site ID when syncing.

Free registration does not send post content, page content, media files, uploaded Google Performance reports, customer data, visitor analytics, admin usernames/emails, order data, scan dumps, or private SEO settings unrelated to Barnd.

== Screenshots ==

1. Barnd AI SEO dashboard.
2. SEO Audit page.
3. Image SEO missing ALT scan.
4. Google Performance Import.
5. Local SEO settings.

== Changelog ==

= 1.0.0-rc26 =
* Started the Better Page Cleanup roadmap milestone.
* Added a plain-English call-to-action audit check for substantial public pages.
* Added a dedicated Call-to-action audit filter and page-editor guidance.
* Changed content filters into focused page work queues that show only why each specific page matched.
* Added direct Edit This Page, View This Page, Local Setup, and Image SEO actions where relevant.
* Replaced the crowded audit filter button wall with one compact dropdown.
* Hid repetitive guidance cards from All issues and limited focused filters to one short action card per page.
* Preserved the verified RC25 cloud registration, status sync, debug persistence, and Copy Cloud Debug workflow.

= 1.0.0-rc25 =
* Stabilized the Free release after the RC23/RC24 audit.
* Made public comment hiding opt-in and added a visible Settings control.
* Made LLMs.txt, FAQ schema, and Menu schema respect their global output controls.
* Suppressed FAQ schema unless the matching visible FAQ markers exist in page content.
* Tightened Cloud Site ID parsing to approved cloud_site_id paths with the bsite_ prefix.
* Redacted secret-like Cloud Debug fields before storage.
* Replaced the old direct Bulk SEO Fixer screen with a locked Pro preview.
* Reduced SEO Audit noise for legal/system pages and removed the single-H1 score penalty.
* Added a 2 MB Google Performance CSV upload limit.

= 1.0.0-rc23 =
* Clarified SEO Audit UX: FAQ/checklist ideas, local proof, image/video support, thin/generic content, and heading structure are now shown as content-guidance actions instead of reusing the same metadata quick-fix slot.
* Content guidance filters now point users to the correct real fix: page editor, Local Setup, or Image SEO.
* Metadata quick-save fields remain available for title, meta description, helpful angle, and schema/about gaps.

= 1.0.0-rc22 =
* Moved Google Performance Import out of Simple Mode and clarified it as an Agency/Advanced workflow.
* Simple Mode now focuses on SEO Audit, Image SEO, setup, Cloud, and Pro preview.

= 1.0.0-rc21 =
* Polished SEO Audit filters with issue counts, helper explanations, and better empty-state messages.
* Renamed the claim-warning filter internally from health to claims while keeping old links compatible.
* Improved content-structure explanations for H1/H2 issues, FAQ/checklist ideas, local proof, image/video support, and thin/generic content.
* Added a What to fix next section to Google Performance Import with manual cleanup guidance for high impressions, low CTR, and position 4–20 opportunities.

= 1.0.0-rc20 =
* Added content structure checks for H1/H2 issues, FAQ/checklist opportunities, local proof details, image/video support, and thin/generic content warnings.
* Added audit filters for headings, local proof, media support, and thin content.

= 1.0.0-rc19 =
* Fixed mode menu refresh using post/redirect/get so Simple, Agency, and Advanced menus update cleanly after saving the Setup Wizard.
* Registered mode-hidden pages as hidden admin pages so old bookmarked links no longer show “Sorry, you are not allowed to access this page.”
* SEO Tools now shows an Advanced Mode notice when opened directly outside Advanced Mode.
* Kept Cloud API strict contract behavior from RC17.1/RC18.

= 1.0.0-rc18 =
* Refined SEO Audit & Quick Fixes with issue filters, per-row saved status, better placeholders, and re-run links after saving.
* Refined Image SEO Quick Fixes with Missing ALT, All Images, and Unattached filters, parent page display, file-size display, and clearer saved status.
* Hid Cloud Debug from normal users unless WordPress debug is enabled or barnd_debug=1 is added to the URL.

= 1.0.0-rc17.1 =
* Replaced broad Cloud Site ID discovery with strict whitelisted response mapping.
* Removed wildcard/regex Cloud ID extraction from production flow.
* Added CloudResponseSchema v1 normalization trace with source path and expected paths.
* Added explicit partial-sync state when api.barndai.com responds but does not return an approved Cloud Site ID field.
* Improved debug output so API contract mismatches are visible instead of hidden.

= 1.0.0-rc14 =
* Improved cloud registration state handling so register/sync responses update the UI consistently.

= 1.0.0-rc14 =
* Connected the Barnd AI Cloud page to live api.barndai.com Free site registration and status sync endpoints.
* Added Cloud Site ID, last registered, last synced, feature flags, and last cloud error display.
* Kept Free tools working locally if registration is skipped or cloud registration fails.

= 1.0.0-rc12 =
* Clarified setup mode behavior and Cloud local Site ID wording before online registration is connected.

= 1.0.0-rc11 =
* Added clearer mode explanation to Setup Wizard and Dashboard.
* Fixed Free Cloud local Site ID display to always create and show a local ID.

= 1.0.0-rc12 =
* Clarified setup mode behavior and Cloud local Site ID wording before online registration is connected.

= 1.0.0-rc11 =
* Added Barnd AI Cloud page inside the main Barnd AI SEO menu.
* Added optional Free site registration flow with local site ID creation.
* Added local Pro license key placeholder for future api.barndai.com validation.
* Added Free-mode privacy wording explaining that post content, page content, media files, Google reports, customer data, and visitor analytics are not sent to Barnd AI Cloud.
* Added dashboard card for Barnd AI Cloud and updated roadmap/pro wording.

= 1.0.0-rc7 =
* Cleaned duplicate Tools menu entries so Free uses the main Barnd AI SEO menu only.
* Hid the old Bulk SEO Fixer menu from the Free build.
* Dashboard cards now respect Simple, Agency, and Advanced setup modes.
* SEO Audit quick-fix area now shows only blank fields to reduce row height and make cleanup faster.
* Updated version constants and plugin header for RC7.

= 1.0.0-rc6 =
* Wizard layout fix so fields stay inside cards and the setup page uses cleaner two-column cards.

* Tightened SEO Audit quick-fix table layout: smaller Page/Post column, wider quick-fix area, compact two-row fields, and cleaner action buttons.

= 1.0.0-rc4 =
* Added quick-fix fields directly inside the SEO Audit table for SEO title, meta description, helpful angle/page notes, and schema description/about.
* Added direct image SEO editing inside the Image SEO table for ALT text, title, caption, and description.
* Made setup mode affect the Barnd AI SEO submenu: Simple Mode stays lighter, Agency Mode shows client workflow tools, and Advanced Mode shows technical tools/roadmap.
* Updated SEO Audit wording to focus on cleanup and quick fixes.

= 1.0.0-rc3 =
* Added Setup Wizard for site type selection, WordPress basics import, local/restaurant quick setup, setup mode, and tool activation.
* Added safe existing SEO data detection and optional fill-blanks-only import for SEO titles and meta descriptions.
* Added Pro Features preview page for planned Barnd AI Cloud features without activating Pro behavior.
* Renamed Competitor Footprints to SEO Plugin Check in the public menu.
* Removed AIOSEO-style wording from the SEO Tools page.

= 1.0.0-rc2 =
* Rebuilt dashboard into a cleaner card-based UI with a Fix These First priority section.
* Moved roadmap data into a structured public roadmap array.
* Replaced old internal version history with customer-facing Free and Pro Preview roadmap wording.
* Renamed dashboard sections for simpler public wording, including Sitemap & LLMs.txt, Google Performance Import, Competitor Check, and Broken Pages & Redirects.

= 1.0.0-rc1 =
* Rebranded internal Slab SEO Assistant base to Barnd AI SEO Free.
* Removed active AI/OpenAI settings and generation buttons from Free workflow.
* Added Free/local positioning and Google Performance Import wording.
* Kept SEO audit, schema, sitemap, image ALT scan, redirects, 404 monitor, link scanner, competitor footprint checker, local SEO, and content safety warnings.
