<?php
/**
 * Plugin Name: Barnd AI SEO
 * Description: Lightweight WordPress SEO cleanup, audits, schema, sitemap, image ALT checks, local SEO, redirects, 404 monitoring, and practical cleanup tools for busy website owners.
 * Version: 1.0.0-rc25
 * Author: Barnd AI
 * License: GPL2+
 * Text Domain: barnd-ai-seo
 */

if (!defined('ABSPATH')) {
    exit;
}

final class Barnd_AI_SEO {
    const VERSION = '1.0.0-rc25';
    const OPTION = 'slab_seo_assistant_options';
    const NONCE_ACTION = 'slabseo_nonce_action';
    const NONCE_NAME = 'slabseo_nonce';

    private static $instance = null;

    public static function instance() {
        if (self::$instance === null) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    private function __construct() {
        add_action('admin_menu', array($this, 'admin_menu'));
        add_action('admin_enqueue_scripts', array($this, 'admin_enqueue_scripts'));
        add_action('admin_init', array($this, 'register_settings'));
        add_action('admin_init', array($this, 'maybe_migrate_rc25_settings'));
        add_action('admin_init', array($this, 'redirect_legacy_admin_pages'));
        add_action('add_meta_boxes', array($this, 'add_meta_boxes'));
        add_action('save_post', array($this, 'save_post_meta'), 10, 2);

        add_filter('pre_get_document_title', array($this, 'filter_document_title'), 20);
        add_action('wp_head', array($this, 'output_head_tags'), 1);

        add_action('init', array($this, 'add_sitemap_rewrite'));
        add_filter('query_vars', array($this, 'query_vars'));
        add_action('template_redirect', array($this, 'render_sitemap'));

        add_filter('plugin_action_links_' . plugin_basename(__FILE__), array($this, 'plugin_action_links'));
        add_action('do_robotstxt', array($this, 'output_robots_txt'), 99, 2);
        add_action('init', array($this, 'maybe_disable_public_comments'), 20);
        add_action('wp_ajax_barndseo_quick_save_post_seo', array($this, 'ajax_quick_save_post_seo'));
        add_action('wp_ajax_barndseo_quick_save_image_seo', array($this, 'ajax_quick_save_image_seo'));
    }

    public static function activate() {
        self::set_default_options();
        self::instance()->add_sitemap_rewrite();
        flush_rewrite_rules();
    }

    public static function deactivate() {
        flush_rewrite_rules();
    }

    public static function default_options() {
        return array(
            'brand_name' => get_bloginfo('name'),
            'legal_owner' => get_bloginfo('name'),
            'site_type' => 'publisher_review',
            'site_description' => get_bloginfo('description'),
            'logo_url' => '',
            'logo_id' => '0',
            'business_email' => '',
            'business_phone' => '',
            'show_address' => '0',
            'street_address' => '',
            'address_locality' => '',
            'address_region' => '',
            'postal_code' => '',
            'address_country' => 'CA',
            'latitude' => '',
            'longitude' => '',
            'price_range' => '',
            'serves_cuisine' => '',
            'opening_hours' => '',
            'menu_url' => '',
            'order_url' => '',
            'area_served' => '',
            'google_verification' => '',
            'instagram_url' => '',
            'tiktok_url' => '',
            'facebook_url' => '',
            'pinterest_url' => '',
            'youtube_url' => '',
            'threads_url' => '',
            'x_url' => '',
            'linkedin_url' => '',
            'google_business_profile_url' => '',
            'reddit_url' => '',
            'social_profiles' => '',
            'enable_sitemap' => '1',
            'enable_schema' => '1',
            'enable_social_meta' => '1',
            'default_pov' => 'We help readers make clearer decisions using practical details, real customer concerns, value checks, and source-backed information.',
            'affiliate_domains' => 'amazon.com, amazon.ca, amzn.to, impact.com, awin1.com, shareasale.com, cj.com',
            'enable_robots' => '1',
            'robots_extra' => '',
            'enable_llms' => '1',
            'disable_public_comments' => '0',
            'rc25_comments_migrated' => '1',
            'setup_completed' => '0',
            'setup_mode' => 'simple',
            'cloud_local_site_id' => '',
            'cloud_site_id' => '',
            'cloud_status' => 'local_only',
            'cloud_plan' => 'free',
            'cloud_registered_at' => '',
            'cloud_last_seen_at' => '',
            'cloud_features' => array(),
            'last_cloud_error' => '',
            'cloud_license_key' => '',
            'last_cloud_debug' => array(),
        );
    }

    public static function set_default_options() {
        $existing = get_option(self::OPTION, array());
        if (is_array($existing) && !empty($existing) && empty($existing['rc25_comments_migrated'])) {
            // Earlier release candidates silently defaulted this to on and exposed no normal Settings control.
            $existing['disable_public_comments'] = '0';
            $existing['rc25_comments_migrated'] = '1';
        }
        update_option(self::OPTION, wp_parse_args($existing, self::default_options()));
    }

    private function opts() {
        $opts = get_option(self::OPTION, array());
        if (empty($opts) || !is_array($opts)) {
            self::set_default_options();
            $opts = get_option(self::OPTION, array());
        }
        return wp_parse_args($opts, self::default_options());
    }

    public function maybe_migrate_rc25_settings() {
        $existing = get_option(self::OPTION, array());
        if (!is_array($existing) || !empty($existing['rc25_comments_migrated'])) return;
        $existing['disable_public_comments'] = '0';
        $existing['rc25_comments_migrated'] = '1';
        update_option(self::OPTION, wp_parse_args($existing, self::default_options()));
    }

    public function admin_enqueue_scripts($hook) {
        if (strpos((string)$hook, 'slab') !== false || $hook === 'media_page_slabseo-image-seo') {
            wp_enqueue_media();
            wp_enqueue_script('jquery');
        }
    }

    public function plugin_action_links($links) {
        $url = admin_url('admin.php?page=slab-seo-assistant-settings');
        array_unshift($links, '<a href="' . esc_url($url) . '">Settings</a>');
        return $links;
    }

    public function admin_menu() {
        $mode = $this->get_setup_mode();
        add_menu_page('Barnd AI SEO', 'Barnd AI SEO', 'manage_options', 'slab-seo-assistant', array($this, 'dashboard_page'), 'dashicons-chart-area', 58);
        $this->add_mode_page('Dashboard', 'Dashboard', 'slab-seo-assistant', array($this, 'dashboard_page'), true);
        $this->add_mode_page('Setup Wizard', 'Setup Wizard', 'slabseo-setup-wizard', array($this, 'setup_wizard_page'), true);
        $this->add_mode_page('Settings', 'Settings', 'slab-seo-assistant-settings', array($this, 'settings_page'), true);
        $this->add_mode_page('SEO Audit & Quick Fixes', 'SEO Audit', 'slabseo-audit', 'slabseo14_audit_page', true);
        $this->add_mode_page('Image SEO Quick Fixes', 'Image SEO', 'slabseo-image-seo', array($this, 'image_seo_page'), true, 'upload_files');
        $show_agency = in_array($mode, array('agency','advanced'), true);
        // Google Performance Import is useful for agencies/advanced users, but too technical for Simple Mode.
        $this->add_mode_page('Google Performance Import', 'Google Performance Import', 'slabseo-search-console', 'slabseo24_search_console_page', $show_agency);

        $this->add_mode_page('Redirects & 404', 'Redirects & 404', 'slabseo-redirects-404', 'slabseo16_redirects_page', $show_agency);
        $this->add_mode_page('Link Scanner', 'Link Scanner', 'slabseo-link-scanner', 'slabseo16_link_scanner_page', $show_agency);
        $this->add_mode_page('SEO Plugin Check', 'SEO Plugin Check', 'slabseo-competitor-footprints', array($this, 'competitor_footprints_page'), $show_agency);

        $show_advanced = ($mode === 'advanced');
        $this->add_mode_page('Roadmap', 'Roadmap', 'slabseo-roadmap', array($this, 'roadmap_page'), $show_advanced);
        $this->add_mode_page('SEO Tools', 'SEO Tools', 'slabseo-tools', array($this, 'tools_page'), $show_advanced);

        $this->add_mode_page('Barnd AI Cloud', 'Barnd AI Cloud', 'slabseo-cloud', array($this, 'cloud_page'), true);
        $this->add_mode_page('Pro Features', 'Pro Features', 'slabseo-pro-features', array($this, 'pro_features_page'), true);
    }

    private function add_mode_page($page_title, $menu_title, $slug, $callback, $visible = true, $capability = 'manage_options') {
        $parent = $visible ? 'slab-seo-assistant' : null;
        add_submenu_page($parent, $page_title, $menu_title, $capability, $slug, $callback);
    }

    private function get_setup_mode() {
        $o = $this->opts();
        $mode = isset($o['setup_mode']) ? sanitize_key($o['setup_mode']) : 'simple';
        return in_array($mode, array('simple', 'agency', 'advanced'), true) ? $mode : 'simple';
    }

    private function domain_sitemap_url() {
        if (function_exists('slabseo14_get_domain_sitemap_url')) {
            return slabseo14_get_domain_sitemap_url();
        }
        $host = parse_url(home_url(), PHP_URL_HOST);
        $host = preg_replace('/^www\./', '', (string)$host);
        $base = preg_replace('/[^a-z0-9]+/i', '', explode('.', $host)[0] ?? 'slab');
        if (!$base) {
            $base = 'slab';
        }
        return home_url('/' . strtolower($base) . '-sitemap.xml');
    }

    private function get_roadmap_items() {
        return array(
            array(
                'version' => '1.0.0',
                'status' => 'current',
                'plan' => 'Free',
                'label' => 'Free Core',
                'focus' => 'Lightweight SEO cleanup, metadata fields, safe schema, sitemap, LLMs.txt, image ALT checks, local SEO setup, broken page tracking, redirects, competitor check, and Google Performance Import.',
                'public' => true,
            ),
            array(
                'version' => '1.0.0 RC9',
                'status' => 'current',
                'plan' => 'Free',
                'label' => 'Setup Wizard',
                'focus' => 'Guided setup, site type selection, mode-based menus, quick SEO audit fixes, image ALT quick editing, WordPress basics import, and safe existing SEO data detection.',
                'public' => true,
            ),
            array(
                'version' => '1.0.0 RC9',
                'status' => 'current',
                'plan' => 'Free / Cloud Prep',
                'label' => 'Barnd AI Cloud Registration',
                'focus' => 'Optional Free site registration with api.barndai.com, Cloud Site ID sync, Free plan feature flags, and privacy-safe Pro preparation.',
                'public' => true,
            ),
            array(
                'version' => '1.1.0',
                'status' => 'planned',
                'plan' => 'Free',
                'label' => 'Better Page Cleanup',
                'focus' => 'More plain-English checks for missing headings, thin content, weak calls-to-action, missing internal links, and local SEO gaps.',
                'public' => true,
            ),
            array(
                'version' => 'Pro',
                'status' => 'planned',
                'plan' => 'Pro Preview',
                'label' => 'AI Draft Fixes',
                'focus' => 'AI-drafted SEO titles, descriptions, FAQs, image ALT text, internal link ideas, and Google performance suggestions through Barnd AI Cloud. Planned features may change before release.',
                'public' => true,
            ),
        );
    }

    private function get_status_badge_class($status) {
        if ($status === 'current') return 'slabseo-done';
        if ($status === 'next') return 'slabseo-next';
        return '';
    }

    private function get_status_label($status) {
        if ($status === 'current') return 'Current';
        if ($status === 'next') return 'Next';
        return 'Planned';
    }

    private function count_missing_meta_safe($meta_key, $limit = 250) {
        $count = 0;
        try {
            $q = new WP_Query(array(
                'post_type' => array('post', 'page'),
                'post_status' => 'publish',
                'posts_per_page' => intval($limit),
                'fields' => 'ids',
                'no_found_rows' => true,
                'orderby' => 'date',
                'order' => 'DESC',
            ));
            foreach ($q->posts as $post_id) {
                if (!get_post_meta($post_id, $meta_key, true)) {
                    $count++;
                }
            }
            wp_reset_postdata();
        } catch (Throwable $e) {
            $count = 0;
        }
        return $count;
    }

    private function get_fix_first_items($published_total, $missing_alt, $o) {
        $items = array();
        if (empty($o['setup_completed']) || $o['setup_completed'] !== '1') {
            $items[] = array('level' => 'high', 'text' => 'Finish the setup wizard to import existing site information and choose your site type.', 'url' => admin_url('admin.php?page=slabseo-setup-wizard'), 'button' => 'Run Setup Wizard');
        }
        $missing_titles = $this->count_missing_meta_safe('_slabseo_title');
        $missing_desc = $this->count_missing_meta_safe('_slabseo_description');
        if ($missing_desc > 0) {
            $items[] = array('level' => 'high', 'text' => sprintf('%d recent posts/pages are missing Google preview descriptions.', $missing_desc), 'url' => admin_url('admin.php?page=slabseo-audit'), 'button' => 'Run SEO Audit');
        }
        if ($missing_titles > 0) {
            $items[] = array('level' => 'high', 'text' => sprintf('%d recent posts/pages are missing SEO titles.', $missing_titles), 'url' => admin_url('admin.php?page=slabseo-audit'), 'button' => 'Review Titles');
        }
        if ($missing_alt > 0) {
            $items[] = array('level' => 'medium', 'text' => sprintf('%d images are missing image descriptions / ALT text.', $missing_alt), 'url' => admin_url('admin.php?page=slabseo-image-seo'), 'button' => 'Review Images');
        }
        $site_type = isset($o['site_type']) ? (string)$o['site_type'] : '';
        if (in_array($site_type, array('local_business', 'restaurant'), true)) {
            $local_missing = array();
            foreach (array('business_phone' => 'phone', 'opening_hours' => 'hours', 'google_business_profile_url' => 'Google Business Profile URL') as $key => $label) {
                if (empty($o[$key])) $local_missing[] = $label;
            }
            if ($site_type === 'restaurant') {
                foreach (array('menu_url' => 'menu URL', 'order_url' => 'order URL') as $key => $label) {
                    if (empty($o[$key])) $local_missing[] = $label;
                }
            }
            if ($local_missing) {
                $items[] = array('level' => 'medium', 'text' => 'Local SEO setup is missing: ' . implode(', ', $local_missing) . '.', 'url' => admin_url('admin.php?page=slab-seo-assistant-settings'), 'button' => 'Complete Setup');
            }
        }
        if (($o['setup_mode'] ?? 'simple') !== 'simple') {
            $items[] = array('level' => 'info', 'text' => 'Import one Google Search Console Pages report to find pages with impressions but weak clicks.', 'url' => admin_url('admin.php?page=slabseo-search-console'), 'button' => 'Import Google Report');
        }
        if (!$items) {
            $items[] = array('level' => 'good', 'text' => 'No urgent dashboard issues found from the quick check. Run a full SEO Audit for deeper cleanup.', 'url' => admin_url('admin.php?page=slabseo-audit'), 'button' => 'Run SEO Audit');
        }
        return array_slice($items, 0, 5);
    }

    private function dashboard_card($title, $body, $button_url, $button_text, $badge = '') {
        ?>
        <div class="slabseo-card">
            <?php if ($badge !== ''): ?><span class="slabseo-mini-badge"><?php echo esc_html($badge); ?></span><?php endif; ?>
            <h2><?php echo esc_html($title); ?></h2>
            <p><?php echo wp_kses_post($body); ?></p>
            <p><a class="button" href="<?php echo esc_url($button_url); ?>"><?php echo esc_html($button_text); ?></a></p>
        </div>
        <?php
    }

    public function dashboard_page() {
        if (!current_user_can('manage_options')) return;
        $o = $this->opts();
        $mode = $this->get_setup_mode();
        $mode_labels = array(
            'simple' => 'Simple Mode',
            'agency' => 'Agency Mode',
            'advanced' => 'Advanced Mode',
        );
        $mode_help = array(
            'simple' => 'Simple Mode keeps the menu focused on setup, audit, image SEO, Cloud, and Pro preview. Google report imports stay hidden until Agency or Advanced Mode.',
            'agency' => 'Agency Mode adds client workflow tools such as redirects, link scanner, and SEO Plugin Check.',
            'advanced' => 'Advanced Mode shows technical controls such as SEO Tools and Roadmap in addition to agency tools.',
        );
        $brand = isset($o['brand_name']) && $o['brand_name'] !== '' ? $o['brand_name'] : get_bloginfo('name');
        $site_type = isset($o['site_type']) && $o['site_type'] !== '' ? $o['site_type'] : 'Not set';
        $sitemap = method_exists($this, 'domain_sitemap_url') ? $this->domain_sitemap_url() : home_url('/sitemap.xml');
        $llms = home_url('/llms.txt');

        $published_total = 0;
        $missing_alt = 0;
        try {
            $post_count = wp_count_posts('post');
            $page_count = wp_count_posts('page');
            $published_total = intval($post_count->publish ?? 0) + intval($page_count->publish ?? 0);
        } catch (Throwable $e) {
            $published_total = 0;
        }
        try {
            $missing_alt = $this->count_missing_alt_images_safe();
        } catch (Throwable $e) {
            $missing_alt = 0;
        }
        $fix_items = $this->get_fix_first_items($published_total, $missing_alt, $o);
        $roadmap_items = array_slice($this->get_roadmap_items(), 0, 3);
        ?>
        <div class="wrap slabseo-wrap">
            <h1>Barnd AI SEO <span style="font-size:14px;color:#646970;font-weight:400;">v<?php echo esc_html(self::VERSION); ?></span></h1>
            <p class="slabseo-lead">Simple SEO cleanup for busy WordPress sites. Find missing titles, weak descriptions, image ALT gaps, local SEO issues, broken links, and content cleanup opportunities without a heavy setup.</p>
            <div class="notice notice-info inline" style="margin:12px 0 16px;"><p><strong><?php echo esc_html($mode_labels[$mode] ?? 'Simple Mode'); ?> active.</strong> <?php echo esc_html($mode_help[$mode] ?? $mode_help['simple']); ?> <a href="<?php echo esc_url(admin_url('admin.php?page=slabseo-setup-wizard')); ?>">Change mode</a>.</p></div>
            <style>
                .slabseo-lead{font-size:15px;max-width:900px}.slabseo-grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(240px,1fr));gap:16px;margin-top:18px}.slabseo-card{position:relative;background:#fff;border:1px solid #dcdcde;border-radius:12px;padding:18px;box-shadow:0 1px 2px rgba(0,0,0,.04)}.slabseo-card h2{margin-top:0;font-size:18px}.slabseo-status{display:inline-block;padding:4px 8px;border-radius:999px;background:#eef7f1;color:#05603a;font-weight:600}.slabseo-warn{background:#fff7ed;color:#9a3412}.slabseo-big{font-size:28px;font-weight:700;color:#1d2327}.slabseo-muted{color:#646970}.slabseo-url{word-break:break-all;font-family:monospace;background:#f6f7f7;padding:4px 6px;border-radius:4px}.slabseo-hero{background:#fff;border:1px solid #dcdcde;border-radius:14px;padding:20px;margin:18px 0;box-shadow:0 1px 2px rgba(0,0,0,.04)}.slabseo-fix-list{margin:0;padding:0;list-style:none}.slabseo-fix-list li{display:flex;gap:12px;align-items:flex-start;border-top:1px solid #f0f0f1;padding:12px 0}.slabseo-fix-list li:first-child{border-top:0}.slabseo-dot{width:10px;height:10px;border-radius:999px;background:#2271b1;margin-top:5px;flex:0 0 10px}.slabseo-dot.high{background:#b32d2e}.slabseo-dot.medium{background:#b45f06}.slabseo-dot.good{background:#008a20}.slabseo-mini-badge{position:absolute;right:14px;top:14px;background:#f0f6fc;color:#0a4b78;border-radius:999px;padding:3px 8px;font-size:12px;font-weight:600}.slabseo-badge{display:inline-block;padding:3px 7px;border-radius:999px;background:#e7f5ff;color:#075985;font-size:12px;font-weight:600}.slabseo-done{background:#dcfce7;color:#166534}.slabseo-next{background:#fef3c7;color:#92400e}.slabseo-roadmap-table{background:#fff;border:1px solid #dcdcde;border-collapse:collapse;width:100%;margin-top:12px}.slabseo-roadmap-table th,.slabseo-roadmap-table td{border-bottom:1px solid #dcdcde;padding:10px;text-align:left;vertical-align:top}.slabseo-actions{margin-top:8px}.slabseo-actions .button{margin-right:6px}.slabseo-section-title{margin-top:28px}
            </style>

            <div class="slabseo-hero">
                <h2 style="margin-top:0;">Fix These First</h2>
                <p class="slabseo-muted">Quick priorities based on the latest dashboard check. Run the full audit for deeper results.</p>
                <ul class="slabseo-fix-list">
                    <?php foreach ($fix_items as $item): ?>
                        <li>
                            <span class="slabseo-dot <?php echo esc_attr($item['level']); ?>"></span>
                            <div>
                                <strong><?php echo esc_html($item['text']); ?></strong>
                                <div class="slabseo-actions"><a class="button button-small" href="<?php echo esc_url($item['url']); ?>"><?php echo esc_html($item['button']); ?></a></div>
                            </div>
                        </li>
                    <?php endforeach; ?>
                </ul>
            </div>

            <div class="slabseo-grid">
                <div class="slabseo-card"><span class="slabseo-mini-badge">Free / Local</span><h2>Setup Status</h2><p>Brand: <strong><?php echo esc_html($brand); ?></strong></p><p>Site type: <strong><?php echo esc_html($site_type); ?></strong></p><p><a class="button button-primary" href="<?php echo esc_url(admin_url('admin.php?page=slabseo-setup-wizard')); ?>">Run Setup Wizard</a> <a class="button" href="<?php echo esc_url(admin_url('admin.php?page=slab-seo-assistant-settings')); ?>">Settings</a></p></div>
                <div class="slabseo-card"><h2>SEO Audit</h2><p class="slabseo-big"><?php echo intval($published_total); ?></p><p class="slabseo-muted">Published posts/pages to monitor.</p><p><a class="button" href="<?php echo esc_url(admin_url('admin.php?page=slabseo-audit')); ?>">Run SEO Audit</a></p></div>
                <div class="slabseo-card"><h2>Image SEO</h2><p class="slabseo-big"><?php echo intval($missing_alt); ?></p><p class="slabseo-muted">Images missing descriptions / ALT text.</p><p><a class="button" href="<?php echo esc_url(admin_url('admin.php?page=slabseo-image-seo')); ?>">Review Images</a></p></div>
                <?php $this->dashboard_card('Local SEO Setup', 'Business fields, restaurant details, menu/order links, hours, and local search markup.', admin_url('admin.php?page=slab-seo-assistant-settings'), 'Complete Local Setup', 'Site Type'); ?>
                <?php if ($mode !== 'simple'): ?>
                    <?php $this->dashboard_card('Broken Pages & Redirects', 'Track missing URLs and send old pages to the right new pages.', admin_url('admin.php?page=slabseo-redirects-404'), 'Open Redirects'); ?>
                    <?php $this->dashboard_card('Link Scanner', 'Find broken internal links and pages that need better discovery.', admin_url('admin.php?page=slabseo-link-scanner'), 'Scan Links'); ?>
                <?php endif; ?>
                <div class="slabseo-card"><h2>Sitemap &amp; LLMs.txt</h2><p>Sitemap:<br><span class="slabseo-url"><?php echo esc_html($sitemap); ?></span></p><p>LLMs.txt:<br><span class="slabseo-url"><?php echo esc_html($llms); ?></span></p><?php if ($mode === 'advanced'): ?><p><a class="button" href="<?php echo esc_url(admin_url('admin.php?page=slabseo-tools')); ?>">Open SEO Tools</a></p><?php endif; ?></div>
                <?php if ($mode !== 'simple'): ?>
                    <?php $this->dashboard_card('Google Performance Import', 'Agency/advanced tool: upload one Google Search Console Pages export to find pages with impressions but weak clicks.', admin_url('admin.php?page=slabseo-search-console'), 'Import Google Report', 'Agency'); ?>
                <?php endif; ?>
                <?php if ($mode !== 'simple'): ?>
                    <?php $this->dashboard_card('SEO Plugin Check', 'Check whether Yoast SEO, AIOSEO, or Rank Math data exists before switching SEO tools. Nothing is deleted automatically.', admin_url('admin.php?page=slabseo-competitor-footprints'), 'Run Check'); ?>
                <?php endif; ?>
                <?php $this->dashboard_card('Barnd AI Cloud', 'Register this Free site online, sync its Free plan status, and prepare for future Pro features. Free tools still work without registration.', admin_url('admin.php?page=slabseo-cloud'), 'Open Cloud Setup', 'Optional'); ?>
                <?php $this->dashboard_card('Pro Preview', 'Planned AI draft fixes will use Barnd AI Cloud. Free mode does not require a cloud account.', admin_url('admin.php?page=slabseo-pro-features'), 'View Pro Features', 'Coming Later'); ?>
            </div>

            <h2 class="slabseo-section-title">Roadmap Snapshot</h2>
            <table class="slabseo-roadmap-table">
                <thead><tr><th>Version</th><th>Status</th><th>Focus</th></tr></thead>
                <tbody>
                <?php foreach ($roadmap_items as $item): ?>
                    <tr>
                        <td><?php echo esc_html($item['version']); ?></td>
                        <td><span class="slabseo-badge <?php echo esc_attr($this->get_status_badge_class($item['status'])); ?>"><?php echo esc_html($this->get_status_label($item['status'])); ?></span></td>
                        <td><strong><?php echo esc_html($item['label']); ?></strong><br><?php echo esc_html($item['focus']); ?></td>
                    </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
            <p><a class="button" href="<?php echo esc_url(admin_url('admin.php?page=slabseo-roadmap')); ?>">Open Full Roadmap</a></p>
        </div>
        <?php
    }


    public function roadmap_page() {
        if (!current_user_can('manage_options')) return;
        $items = $this->get_roadmap_items();
        ?>
        <div class="wrap slabseo-wrap">
            <h1>Barnd AI SEO Roadmap <span style="font-size:14px;color:#646970;font-weight:400;">Current v<?php echo esc_html(self::VERSION); ?></span></h1>
            <p>Public roadmap for the Free plugin and future Pro preview. Internal Slab development history is intentionally hidden from this customer-facing view.</p>
            <style>
                .slabseo-roadmap-table{background:#fff;border:1px solid #dcdcde;border-collapse:collapse;width:100%;margin-top:12px}.slabseo-roadmap-table th,.slabseo-roadmap-table td{border-bottom:1px solid #dcdcde;padding:10px;text-align:left;vertical-align:top}.slabseo-badge{display:inline-block;padding:3px 7px;border-radius:999px;background:#e7f5ff;color:#075985;font-size:12px;font-weight:600}.slabseo-done{background:#dcfce7;color:#166534}.slabseo-next{background:#fef3c7;color:#92400e}.slabseo-note{background:#f6f7f7;border-left:4px solid #2271b1;padding:10px 12px;margin:14px 0}.slabseo-pro{background:#fef3c7;color:#92400e;border-radius:999px;padding:3px 7px;font-size:12px;font-weight:600}
            </style>
            <div class="slabseo-note"><strong>Product rule:</strong> Free stays lightweight and useful without a cloud account. Pro features are previewed only and may change before release.</div>
            <table class="slabseo-roadmap-table">
                <thead><tr><th>Version</th><th>Status</th><th>Plan</th><th>Feature Group</th><th>Details</th></tr></thead>
                <tbody>
                <?php foreach ($items as $item): ?>
                    <tr>
                        <td><?php echo esc_html($item['version']); ?></td>
                        <td><span class="slabseo-badge <?php echo esc_attr($this->get_status_badge_class($item['status'])); ?>"><?php echo esc_html($this->get_status_label($item['status'])); ?></span></td>
                        <td><?php echo $item['plan'] === 'Pro Preview' ? '<span class="slabseo-pro">Pro Preview</span>' : esc_html($item['plan']); ?></td>
                        <td><strong><?php echo esc_html($item['label']); ?></strong></td>
                        <td><?php echo esc_html($item['focus']); ?></td>
                    </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
            <h2>Recommended Free workflow</h2>
            <ol>
                <li>Use <strong>Fix These First</strong> on the dashboard to choose the first cleanup task.</li>
                <li>Run <strong>SEO Audit</strong> for missing titles, weak descriptions, content risks, and local gaps.</li>
                <li>Run <strong>Image SEO</strong> to find images missing ALT text.</li>
                <li>Use <strong>Google Performance Import</strong> only in Agency/Advanced Mode after exporting one Pages report from Google Search Console.</li>
                <li>Use <strong>Broken Pages &amp; Redirects</strong> after changing URLs or removing pages.</li>
            </ol>
        </div>
        <?php
    }

    public function maybe_disable_public_comments() {
        $o = $this->opts();
        if (empty($o['disable_public_comments']) || $o['disable_public_comments'] !== '1') {
            return;
        }

        // Front-end only: hide public comment systems without deleting stored comments.
        add_filter('comments_open', '__return_false', 20, 2);
        add_filter('pings_open', '__return_false', 20, 2);
        add_filter('comments_array', array($this, 'hide_public_comments_array'), 20, 2);
        add_filter('get_comments_number', array($this, 'hide_public_comments_number'), 20, 2);
        add_filter('comments_number', array($this, 'hide_public_comments_text'), 20, 2);
        add_filter('comments_link', array($this, 'hide_public_comments_link'), 20);
        add_action('wp_head', array($this, 'output_comment_hide_css'), 99);
    }

    public function hide_public_comments_array($comments, $post_id) {
        if (is_admin()) {
            return $comments;
        }
        return array();
    }

    public function hide_public_comments_number($count, $post_id = 0) {
        if (is_admin()) {
            return $count;
        }
        return 0;
    }

    public function hide_public_comments_text($output, $number = null) {
        if (is_admin()) {
            return $output;
        }
        return '';
    }

    public function hide_public_comments_link($link) {
        if (is_admin()) {
            return $link;
        }
        return '';
    }

    public function output_comment_hide_css() {
        if (is_admin()) {
            return;
        }
        echo "\n<style id=\"slabseo-hide-comments\">.comments-area,.comment-respond,#comments,#respond,.post-comments,.entry-comments,.comments-link,.comment-link,.comment-metadata .comments,.wp-block-post-comments,.wp-block-comments,.wp-block-comments-title{display:none!important;}</style>\n";
    }

    private function count_missing_alt_images_safe() {
        global $wpdb;
        if (!isset($wpdb) || !isset($wpdb->posts)) return 0;
        $sql = "SELECT COUNT(p.ID) FROM {$wpdb->posts} p LEFT JOIN {$wpdb->postmeta} m ON p.ID=m.post_id AND m.meta_key='_wp_attachment_image_alt' WHERE p.post_type='attachment' AND p.post_mime_type LIKE 'image/%' AND (m.meta_id IS NULL OR m.meta_value='' OR m.meta_value IS NULL)";
        return (int) $wpdb->get_var($sql);
    }

    public function tools_page() {
        if (!current_user_can('manage_options')) return;
        $o = $this->opts();
        if (isset($_POST['slabseo_tools_nonce']) && wp_verify_nonce(sanitize_text_field(wp_unslash($_POST['slabseo_tools_nonce'])), 'slabseo_tools')) {
            $o['enable_robots'] = !empty($_POST['enable_robots']) ? '1' : '0';
            $o['enable_llms'] = !empty($_POST['enable_llms']) ? '1' : '0';
            $o['robots_extra'] = isset($_POST['robots_extra']) ? sanitize_textarea_field(wp_unslash($_POST['robots_extra'])) : '';
            update_option(self::OPTION, $o);
            echo '<div class="notice notice-success"><p>SEO tools saved.</p></div>';
        }
        $sitemap = $this->domain_sitemap_url();
        $mode = $this->get_setup_mode();
        ?>
        <div class="wrap"><h1>Barnd AI SEO Tools</h1>
            <?php if ($mode !== 'advanced'): ?>
                <div class="notice notice-info inline"><p><strong>Advanced tool opened directly.</strong> SEO Tools is hidden from the left menu unless Advanced Mode is selected, but this page stays accessible so saved links do not show an access error. <a href="<?php echo esc_url(admin_url('admin.php?page=slabseo-setup-wizard')); ?>">Change mode</a>.</p></div>
            <?php endif; ?>
            <p>This page groups technical SEO utilities such as sitemap, LLMs.txt, robots.txt additions, and quick SEO links.</p>
            <h2>Useful URLs</h2>
            <ul>
                <li>Sitemap: <a href="<?php echo esc_url($sitemap); ?>" target="_blank"><?php echo esc_html($sitemap); ?></a></li>
                <li>LLMs.txt: <a href="<?php echo esc_url(home_url('/llms.txt')); ?>" target="_blank"><?php echo esc_html(home_url('/llms.txt')); ?></a></li>
                <li>Robots.txt: <a href="<?php echo esc_url(home_url('/robots.txt')); ?>" target="_blank"><?php echo esc_html(home_url('/robots.txt')); ?></a></li>
                <li>SEO Plugin Check: <a href="<?php echo esc_url(admin_url('admin.php?page=slabseo-competitor-footprints')); ?>">Open check</a></li>
            </ul>
            <form method="post">
                <?php wp_nonce_field('slabseo_tools','slabseo_tools_nonce'); ?>
                <table class="form-table" role="presentation">
                    <tr><th scope="row">Enable LLMs.txt</th><td><label><input type="checkbox" name="enable_llms" value="1" <?php checked($o['enable_llms'] ?? '1','1'); ?>> Output /llms.txt for search discovery.</label></td></tr>
                    <tr><th scope="row">Enable Robots Additions</th><td><label><input type="checkbox" name="enable_robots" value="1" <?php checked($o['enable_robots'] ?? '1','1'); ?>> Add Barnd AI SEO sitemap line and custom rules to robots.txt.</label></td></tr>
                    <tr><th scope="row">Extra Robots.txt Rules</th><td><textarea name="robots_extra" rows="8" class="large-text code"><?php echo esc_textarea($o['robots_extra'] ?? ''); ?></textarea><p class="description">Optional. Be careful: wrong robots rules can block Google. Example: <code>Sitemap: <?php echo esc_html($sitemap); ?></code></p></td></tr>
                </table>
                <p><button class="button button-primary">Save SEO Tools</button></p>
            </form>
        </div>
        <?php
    }

    public function redirect_legacy_admin_pages() {
        if (!current_user_can('manage_options')) return;
        global $pagenow;
        $page = isset($_GET['page']) ? sanitize_key(wp_unslash($_GET['page'])) : '';
        if ($pagenow === 'options-general.php' && $page === 'slab-seo-assistant-settings') {
            wp_safe_redirect(admin_url('admin.php?page=slab-seo-assistant-settings'));
            exit;
        }
        if ($pagenow === 'upload.php' && $page === 'slabseo-image-seo') {
            wp_safe_redirect(admin_url('admin.php?page=slabseo-image-seo'));
            exit;
        }
    }

    public function competitor_footprints_page() {
        if (!current_user_can('manage_options')) return;
        $scan = $this->scan_competitor_footprints();
        ?>
        <div class="wrap slabseo-wrap">
            <h1>SEO Plugin Check</h1>
            <p>Check whether Yoast SEO, AIOSEO, or Rank Math data exists on this site before switching SEO tools. Barnd AI SEO does <strong>not</strong> delete existing SEO plugin data automatically.</p>
            <div class="notice notice-warning"><p><strong>Safe rule:</strong> analyze first, export/back up second, clean later only if we decide the data is not needed. Some old SEO titles, meta descriptions, and redirects may be useful to import into Barnd AI SEO.</p></div>
            <h2>Installed / Active SEO Plugins</h2>
            <table class="widefat striped"><thead><tr><th>Plugin</th><th>Installed</th><th>Active</th><th>Recommendation</th></tr></thead><tbody>
            <?php foreach ($scan['plugins'] as $row): ?>
                <tr>
                    <td><?php echo esc_html($row['name']); ?></td>
                    <td><?php echo $row['installed'] ? '<span style="color:#007017;font-weight:600">Yes</span>' : 'No'; ?></td>
                    <td><?php echo $row['active'] ? '<span style="color:#b45f06;font-weight:600">Active</span>' : 'No'; ?></td>
                    <td><?php echo esc_html($row['note']); ?></td>
                </tr>
            <?php endforeach; ?>
            </tbody></table>

            <h2>Database Footprints</h2>
            <table class="widefat striped"><thead><tr><th>Source</th><th>Options</th><th>Post Meta</th><th>Term Meta</th><th>User Meta</th><th>Risk / Action</th></tr></thead><tbody>
            <?php foreach ($scan['footprints'] as $row): ?>
                <tr>
                    <td><strong><?php echo esc_html($row['name']); ?></strong></td>
                    <td><?php echo intval($row['options']); ?></td>
                    <td><?php echo intval($row['postmeta']); ?></td>
                    <td><?php echo intval($row['termmeta']); ?></td>
                    <td><?php echo intval($row['usermeta']); ?></td>
                    <td><?php echo esc_html($row['advice']); ?></td>
                </tr>
            <?php endforeach; ?>
            </tbody></table>

            <h2>Cleanup Decision Guide</h2>
            <ol>
                <li><strong>Do not delete yet</strong> if old SEO titles/descriptions exist. We may import useful fields first.</li>
                <li><strong>Deactivate competitor SEO plugins</strong> if they are still active, otherwise duplicate meta/schema can happen.</li>
                <li><strong>Keep data temporarily</strong> while Barnd AI SEO is tested on live pages.</li>
                <li><strong>Clean later</strong> only after a backup and after we confirm Barnd AI SEO fields are working.</li>
            </ol>
            <p><a class="button button-primary" href="<?php echo esc_url(admin_url('admin.php?page=slab-seo-assistant')); ?>">Back to Barnd AI SEO Dashboard</a></p>
        </div>
        <?php
    }

    private function scan_competitor_footprints() {
        if (!function_exists('get_plugins')) {
            require_once ABSPATH . 'wp-admin/includes/plugin.php';
        }
        $known_plugins = array(
            'wordpress-seo/wp-seo.php' => 'Yoast SEO',
            'all-in-one-seo-pack/all_in_one_seo_pack.php' => 'AIOSEO',
            'seo-by-rank-math/rank-math.php' => 'Rank Math',
        );
        $installed = get_plugins();
        $plugins = array();
        foreach ($known_plugins as $file => $name) {
            $is_installed = isset($installed[$file]);
            $is_active = function_exists('is_plugin_active') && is_plugin_active($file);
            $plugins[] = array(
                'name' => $name,
                'installed' => $is_installed,
                'active' => $is_active,
                'note' => $is_active ? 'Active competitor SEO plugin. Check for duplicate meta/schema output.' : ($is_installed ? 'Installed but inactive. Data may still remain in database.' : 'Not installed.'),
            );
        }
        $patterns = array(
            array('name'=>'Yoast SEO', 'options'=>array('wpseo%'), 'postmeta'=>array('_yoast_wpseo_%'), 'termmeta'=>array('wpseo_%'), 'usermeta'=>array('wpseo_%')),
            array('name'=>'AIOSEO', 'options'=>array('aioseo%','aioseop%'), 'postmeta'=>array('_aioseo_%','_aioseop_%'), 'termmeta'=>array('_aioseo_%','_aioseop_%'), 'usermeta'=>array('_aioseo_%','_aioseop_%')),
            array('name'=>'Rank Math', 'options'=>array('rank_math%'), 'postmeta'=>array('rank_math_%'), 'termmeta'=>array('rank_math_%'), 'usermeta'=>array('rank_math_%')),
        );
        $footprints = array();
        foreach ($patterns as $p) {
            $options = $this->count_option_patterns($p['options']);
            $postmeta = $this->count_meta_patterns('postmeta', 'meta_key', $p['postmeta']);
            $termmeta = $this->count_meta_patterns('termmeta', 'meta_key', $p['termmeta']);
            $usermeta = $this->count_meta_patterns('usermeta', 'meta_key', $p['usermeta']);
            $total = $options + $postmeta + $termmeta + $usermeta;
            $advice = $total > 0 ? 'Analyze/import useful SEO fields before cleanup. Do not delete blindly.' : 'No obvious footprint found.';
            $footprints[] = array('name'=>$p['name'], 'options'=>$options, 'postmeta'=>$postmeta, 'termmeta'=>$termmeta, 'usermeta'=>$usermeta, 'advice'=>$advice);
        }
        return array('plugins'=>$plugins, 'footprints'=>$footprints);
    }

    private function count_option_patterns($patterns) {
        global $wpdb;
        $total = 0;
        foreach ((array)$patterns as $pattern) {
            $like = str_replace('%', '\\%', $pattern);
            $like = str_replace('\\%', '%', $like);
            $total += (int)$wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM {$wpdb->options} WHERE option_name LIKE %s", $like));
        }
        return $total;
    }

    private function count_meta_patterns($table_key, $key_column, $patterns) {
        global $wpdb;
        $table_map = array('postmeta'=>$wpdb->postmeta, 'termmeta'=>$wpdb->termmeta, 'usermeta'=>$wpdb->usermeta);
        if (empty($table_map[$table_key])) return 0;
        $table = $table_map[$table_key];
        $total = 0;
        foreach ((array)$patterns as $pattern) {
            $total += (int)$wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM {$table} WHERE {$key_column} LIKE %s", $pattern));
        }
        return $total;
    }

    public function output_robots_txt($output, $public) {
        $o = $this->opts();
        if (($o['enable_robots'] ?? '1') !== '1') return;
        echo "
# Barnd AI SEO
";
        echo 'Sitemap: ' . esc_url_raw($this->domain_sitemap_url()) . "
";
        if (!empty($o['robots_extra'])) {
            echo trim($o['robots_extra']) . "
";
        }
    }


    private function detect_existing_seo_counts() {
        global $wpdb;
        $sources = array(
            'Yoast SEO' => array('_yoast_wpseo_title', '_yoast_wpseo_metadesc'),
            'Rank Math' => array('rank_math_title', 'rank_math_description', '_rank_math_title', '_rank_math_description'),
            'AIOSEO' => array('_aioseo_title', '_aioseo_description'),
        );
        $counts = array();
        foreach ($sources as $name => $keys) {
            $placeholders = implode(',', array_fill(0, count($keys), '%s'));
            $sql = $wpdb->prepare("SELECT COUNT(DISTINCT post_id) FROM {$wpdb->postmeta} WHERE meta_key IN ($placeholders) AND meta_value <> ''", $keys);
            $counts[$name] = intval($wpdb->get_var($sql));
        }
        return $counts;
    }

    private function import_existing_seo_meta($limit = 300) {
        $mappings = array(
            '_slabseo_title' => array('_yoast_wpseo_title', 'rank_math_title', '_rank_math_title', '_aioseo_title'),
            '_slabseo_description' => array('_yoast_wpseo_metadesc', 'rank_math_description', '_rank_math_description', '_aioseo_description'),
        );
        $posts = get_posts(array(
            'post_type' => array('post', 'page'),
            'post_status' => array('publish', 'draft', 'future', 'private'),
            'posts_per_page' => absint($limit),
            'fields' => 'ids',
            'orderby' => 'date',
            'order' => 'DESC',
        ));
        $updated = 0;
        foreach ($posts as $post_id) {
            foreach ($mappings as $target_key => $source_keys) {
                if (get_post_meta($post_id, $target_key, true)) {
                    continue;
                }
                foreach ($source_keys as $source_key) {
                    $value = get_post_meta($post_id, $source_key, true);
                    if (is_string($value) && trim($value) !== '') {
                        update_post_meta($post_id, $target_key, sanitize_text_field($value));
                        $updated++;
                        break;
                    }
                }
            }
        }
        return $updated;
    }

    private function detect_setup_suggestion() {
        $title = strtolower(get_bloginfo('name') . ' ' . get_bloginfo('description'));
        if (strpos($title, 'restaurant') !== false || strpos($title, 'pizza') !== false || strpos($title, 'burger') !== false || strpos($title, 'sushi') !== false || strpos($title, 'menu') !== false) {
            return 'restaurant';
        }
        if (strpos($title, 'agency') !== false || strpos($title, 'client') !== false) {
            return 'agency_client';
        }
        return 'blog';
    }

    public function setup_wizard_page() {
        if (!current_user_can('manage_options')) return;
        $o = $this->opts();
        $message = '';
        if (isset($_POST['barndseo_wizard_nonce']) && wp_verify_nonce(sanitize_text_field(wp_unslash($_POST['barndseo_wizard_nonce'])), 'barndseo_wizard_save')) {
            $allowed_site_types = array('blog','publisher_review','restaurant','franchise','local_business','organization','agency_client');
            $allowed_modes = array('simple','agency','advanced');
            $site_type = isset($_POST['site_type']) ? sanitize_key(wp_unslash($_POST['site_type'])) : 'blog';
            $setup_mode = isset($_POST['setup_mode']) ? sanitize_key(wp_unslash($_POST['setup_mode'])) : 'simple';
            $o['site_type'] = in_array($site_type, $allowed_site_types, true) ? $site_type : 'blog';
            $o['setup_mode'] = in_array($setup_mode, $allowed_modes, true) ? $setup_mode : 'simple';
            $o['brand_name'] = isset($_POST['brand_name']) ? sanitize_text_field(wp_unslash($_POST['brand_name'])) : get_bloginfo('name');
            $o['legal_owner'] = isset($_POST['legal_owner']) ? sanitize_text_field(wp_unslash($_POST['legal_owner'])) : $o['brand_name'];
            $o['site_description'] = isset($_POST['site_description']) ? sanitize_text_field(wp_unslash($_POST['site_description'])) : get_bloginfo('description');
            $o['business_phone'] = isset($_POST['business_phone']) ? sanitize_text_field(wp_unslash($_POST['business_phone'])) : ($o['business_phone'] ?? '');
            $o['opening_hours'] = isset($_POST['opening_hours']) ? sanitize_text_field(wp_unslash($_POST['opening_hours'])) : ($o['opening_hours'] ?? '');
            $o['menu_url'] = isset($_POST['menu_url']) ? esc_url_raw(wp_unslash($_POST['menu_url'])) : ($o['menu_url'] ?? '');
            $o['order_url'] = isset($_POST['order_url']) ? esc_url_raw(wp_unslash($_POST['order_url'])) : ($o['order_url'] ?? '');
            $o['google_business_profile_url'] = isset($_POST['google_business_profile_url']) ? esc_url_raw(wp_unslash($_POST['google_business_profile_url'])) : ($o['google_business_profile_url'] ?? '');
            foreach (array('enable_sitemap','enable_schema','enable_social_meta','enable_llms','enable_robots') as $bool) {
                $o[$bool] = !empty($_POST[$bool]) ? '1' : '0';
            }
            $imported = 0;
            if (!empty($_POST['import_existing_seo'])) {
                $imported = $this->import_existing_seo_meta(300);
            }
            $o['setup_completed'] = '1';
            update_option(self::OPTION, wp_parse_args($o, self::default_options()));
            $redirect_args = array(
                'page' => 'slabseo-setup-wizard',
                'barnd_setup_saved' => $o['setup_mode'],
                'barnd_imported' => absint($imported),
            );
            wp_safe_redirect(add_query_arg($redirect_args, admin_url('admin.php')));
            exit;
        }
        if (!empty($_GET['barnd_setup_saved'])) {
            $saved_mode = sanitize_key(wp_unslash($_GET['barnd_setup_saved']));
            $saved_mode_label = array('simple' => 'Simple Mode', 'agency' => 'Agency Mode', 'advanced' => 'Advanced Mode');
            $imported = isset($_GET['barnd_imported']) ? absint($_GET['barnd_imported']) : 0;
            $message = '<div class="notice notice-success"><p>Setup saved in ' . esc_html($saved_mode_label[$saved_mode] ?? 'Simple Mode') . '. The left menu and dashboard now use this mode.' . ($imported ? ' Imported ' . intval($imported) . ' SEO fields into blank Barnd AI SEO fields.' : '') . ' <a href="' . esc_url(admin_url('admin.php?page=slab-seo-assistant')) . '">Open dashboard</a>.</p></div>';
        }
        $o = $this->opts();
        $detected_counts = $this->detect_existing_seo_counts();
        $suggested_type = $this->detect_setup_suggestion();
        $site_logo_id = get_theme_mod('custom_logo');
        $site_logo_url = $site_logo_id ? wp_get_attachment_image_url($site_logo_id, 'full') : '';
        $brand = !empty($o['brand_name']) ? $o['brand_name'] : get_bloginfo('name');
        ?>
        <div class="wrap slabseo-wrap">
            <h1>Barnd AI SEO Setup Wizard</h1>
            <p class="description">Import what already exists, choose the site type, and turn on the lightweight SEO tools you need. Free mode works without a cloud account.</p>
            <?php $current_mode_label = array('simple' => 'Simple Mode', 'agency' => 'Agency Mode', 'advanced' => 'Advanced Mode'); ?>
            <div class="notice notice-info inline" style="margin:12px 0 16px;"><p><strong>Current mode:</strong> <?php echo esc_html($current_mode_label[$this->get_setup_mode()] ?? 'Simple Mode'); ?>. Change Step 5 and save to update the left menu and dashboard cards. If another Barnd plugin is active, its separate menu items may still appear outside Barnd AI SEO.</p></div>
            <?php echo wp_kses_post($message); ?>
            <style>
                
                .barndseo-wizard-grid{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:16px;margin:18px 0;max-width:1220px;align-items:start;}
                .barndseo-wizard-card{background:#fff;border:1px solid #dcdcde;border-radius:12px;padding:18px;box-shadow:0 1px 2px rgba(0,0,0,.04);box-sizing:border-box;min-width:0;overflow:hidden;}
                .barndseo-wizard-card h2{margin-top:8px;font-size:18px;line-height:1.25;}
                .barndseo-wizard-card p{margin:10px 0;}
                .barndseo-wizard-card input.regular-text,.barndseo-wizard-card input[type="text"],.barndseo-wizard-card input[type="url"],.barndseo-wizard-card textarea{width:100%;max-width:100%;box-sizing:border-box;}
                .barndseo-wizard-card input[type="radio"],.barndseo-wizard-card input[type="checkbox"]{width:auto;max-width:none;}
                .barndseo-pill{display:inline-block;background:#f0f6fc;color:#0a4b78;border-radius:999px;padding:4px 9px;font-weight:600;font-size:12px;}
                .barndseo-choice label{display:block;margin:8px 0;}
                .barndseo-found{color:#008a20;font-weight:600;}.barndseo-missing{color:#8a1f11;font-weight:600;}.barndseo-actions{margin-top:20px;}
                @media (max-width: 1100px){.barndseo-wizard-grid{grid-template-columns:1fr;max-width:760px;}}
                
            </style>
            <form method="post">
                <?php wp_nonce_field('barndseo_wizard_save','barndseo_wizard_nonce'); ?>
                <div class="barndseo-wizard-grid">
                    <div class="barndseo-wizard-card">
                        <span class="barndseo-pill">Step 1</span>
                        <h2>Choose Site Type</h2>
                        <p>Suggested: <strong><?php echo esc_html(ucwords(str_replace('_',' ', $suggested_type))); ?></strong></p>
                        <div class="barndseo-choice">
                            <?php
                            $types = array(
                                'blog' => 'Blog',
                                'local_business' => 'Local Business',
                                'restaurant' => 'Restaurant / Food Business',
                                'publisher_review' => 'Affiliate / Review Site',
                                'agency_client' => 'Agency Client Site',
                                'organization' => 'Organization',
                                'franchise' => 'Franchise / Business Opportunity Site',
                            );
                            $current_type = $o['site_type'] ?? $suggested_type;
                            foreach ($types as $key => $label) {
                                echo '<label><input type="radio" name="site_type" value="' . esc_attr($key) . '" ' . checked($current_type, $key, false) . '> ' . esc_html($label) . '</label>';
                            }
                            ?>
                        </div>
                    </div>
                    <div class="barndseo-wizard-card">
                        <span class="barndseo-pill">Step 2</span>
                        <h2>Import Website Basics</h2>
                        <p>WordPress site title: <strong><?php echo esc_html(get_bloginfo('name')); ?></strong></p>
                        <p>Tagline: <strong><?php echo esc_html(get_bloginfo('description')); ?></strong></p>
                        <p>Site logo: <?php echo $site_logo_url ? '<span class="barndseo-found">Found</span>' : '<span class="barndseo-missing">Not found</span>'; ?></p>
                        <p><label>Brand name<br><input type="text" name="brand_name" class="regular-text" value="<?php echo esc_attr($brand); ?>"></label></p>
                        <p><label>Legal owner<br><input type="text" name="legal_owner" class="regular-text" value="<?php echo esc_attr($o['legal_owner'] ?? $brand); ?>"></label></p>
                        <p><label>Site description<br><input type="text" name="site_description" class="regular-text" value="<?php echo esc_attr($o['site_description'] ?? get_bloginfo('description')); ?>"></label></p>
                    </div>
                    <div class="barndseo-wizard-card">
                        <span class="barndseo-pill">Step 3</span>
                        <h2>Existing SEO Data</h2>
                        <p>Barnd can copy compatible SEO titles and meta descriptions into blank Barnd fields. Nothing is deleted.</p>
                        <ul>
                            <?php foreach ($detected_counts as $source => $count): ?>
                                <li><?php echo esc_html($source); ?>: <strong><?php echo intval($count); ?></strong> posts/pages with detectable SEO data</li>
                            <?php endforeach; ?>
                        </ul>
                        <label><input type="checkbox" name="import_existing_seo" value="1"> Import SEO titles and descriptions into blank Barnd AI SEO fields</label>
                        <p class="description">Safe rule: import fills blanks only. Keep old plugin data until you confirm Barnd output works.</p>
                    </div>
                    <div class="barndseo-wizard-card">
                        <span class="barndseo-pill">Step 4</span>
                        <h2>Local / Restaurant Quick Setup</h2>
                        <p><label>Phone<br><input type="text" name="business_phone" class="regular-text" value="<?php echo esc_attr($o['business_phone'] ?? ''); ?>"></label></p>
                        <p><label>Opening hours<br><input type="text" name="opening_hours" class="regular-text" value="<?php echo esc_attr($o['opening_hours'] ?? ''); ?>" placeholder="Mo-Fr 11:00-21:00"></label></p>
                        <p><label>Google Business Profile URL<br><input type="url" name="google_business_profile_url" class="regular-text" value="<?php echo esc_attr($o['google_business_profile_url'] ?? ''); ?>"></label></p>
                        <p><label>Menu URL<br><input type="url" name="menu_url" class="regular-text" value="<?php echo esc_attr($o['menu_url'] ?? ''); ?>"></label></p>
                        <p><label>Order URL<br><input type="url" name="order_url" class="regular-text" value="<?php echo esc_attr($o['order_url'] ?? ''); ?>"></label></p>
                    </div>
                    <div class="barndseo-wizard-card">
                        <span class="barndseo-pill">Step 5</span>
                        <h2>Choose Mode</h2>
                        <?php $mode = $o['setup_mode'] ?? 'simple'; ?>
                        <div class="barndseo-choice">
                            <label><input type="radio" name="setup_mode" value="simple" <?php checked($mode, 'simple'); ?>> <strong>Simple Mode</strong><br><span class="description">Best for business owners and bloggers. Shows only the cleanup tools most people need.</span></label>
                            <label><input type="radio" name="setup_mode" value="agency" <?php checked($mode, 'agency'); ?>> <strong>Agency Mode</strong><br><span class="description">Adds client workflow tools: redirects, link scanner, SEO Plugin Check, and import checks.</span></label>
                            <label><input type="radio" name="setup_mode" value="advanced" <?php checked($mode, 'advanced'); ?>> <strong>Advanced Mode</strong><br><span class="description">Shows technical controls such as SEO Tools and Roadmap in addition to agency tools.</span></label>
                        </div>
                        <p class="description"><strong>After saving:</strong> the left menu and dashboard cards change based on the mode you choose.</p>
                    </div>
                    <div class="barndseo-wizard-card">
                        <span class="barndseo-pill">Step 6</span>
                        <h2>Enable Tools</h2>
                        <label><input type="checkbox" name="enable_sitemap" value="1" <?php checked($o['enable_sitemap'] ?? '1','1'); ?>> Sitemap</label><br>
                        <label><input type="checkbox" name="enable_llms" value="1" <?php checked($o['enable_llms'] ?? '1','1'); ?>> LLMs.txt</label><br>
                        <label><input type="checkbox" name="enable_schema" value="1" <?php checked($o['enable_schema'] ?? '1','1'); ?>> Search markup / schema</label><br>
                        <label><input type="checkbox" name="enable_social_meta" value="1" <?php checked($o['enable_social_meta'] ?? '1','1'); ?>> Social sharing preview tags</label><br>
                        <label><input type="checkbox" name="enable_robots" value="1" <?php checked($o['enable_robots'] ?? '1','1'); ?>> Robots.txt sitemap line</label>
                    </div>
                </div>
                <input type="hidden" name="setup_completed" value="1">
                <p class="barndseo-actions"><button class="button button-primary button-hero">Save Setup and Go to Dashboard</button> <a class="button button-hero" href="<?php echo esc_url(admin_url('admin.php?page=slab-seo-assistant')); ?>">Skip for Now</a></p>
            </form>
        </div>
        <?php
    }

    private function get_or_create_cloud_local_site_id() {
        $o = $this->opts();
        $local_id = !empty($o['cloud_local_site_id']) ? sanitize_text_field($o['cloud_local_site_id']) : '';

        // Backward compatibility: older RC builds stored the local barnd_ ID in cloud_site_id.
        if ($local_id === '' && !empty($o['cloud_site_id']) && strpos((string)$o['cloud_site_id'], 'barnd_') === 0) {
            $local_id = sanitize_text_field($o['cloud_site_id']);
            $o['cloud_local_site_id'] = $local_id;
            $o['cloud_site_id'] = '';
        }

        if ($local_id === '') {
            $local_id = 'barnd_' . wp_generate_password(20, false, false);
            $o['cloud_local_site_id'] = $local_id;
            if (empty($o['cloud_plan'])) {
                $o['cloud_plan'] = 'free';
            }
            update_option(self::OPTION, wp_parse_args($o, self::default_options()));
        }
        return $local_id;
    }

    // Backward-compatible wrapper for older internal calls.
    private function get_or_create_cloud_site_id() {
        return $this->get_or_create_cloud_local_site_id();
    }

    private function cloud_api_base_url() {
        return 'https://api.barndai.com';
    }

    private function cloud_payload_base() {
        $o = $this->opts();
        return array(
            'local_site_id' => $this->get_or_create_cloud_local_site_id(),
            'site_url' => site_url(),
            'home_url' => home_url(),
            'plugin' => 'barnd-ai-seo',
            'plugin_version' => self::VERSION,
            'wordpress_version' => get_bloginfo('version'),
            'php_version' => PHP_VERSION,
            'site_type' => !empty($o['site_type']) ? sanitize_key($o['site_type']) : 'blog',
            'setup_mode' => !empty($o['setup_mode']) ? sanitize_key($o['setup_mode']) : 'simple',
            'plan' => 'free',
            'locale' => get_locale(),
            'timezone' => wp_timezone_string(),
        );
    }

    private function cloud_post($path, $payload) {
        $url = trailingslashit($this->cloud_api_base_url()) . ltrim($path, '/');
        $safe_payload = $this->redact_cloud_debug_value($payload);

        $response = wp_remote_post($url, array(
            'timeout' => 15,
            'redirection' => 2,
            'sslverify' => true,
            'headers' => array(
                'Content-Type' => 'application/json',
                'Accept' => 'application/json',
            ),
            'body' => wp_json_encode($payload),
        ));

        if (is_wp_error($response)) {
            $this->save_cloud_debug(array(
                'endpoint' => $url,
                'request' => $safe_payload,
                'http_code' => 0,
                'raw_body' => '',
                'parsed' => array(),
                'error' => $response->get_error_message(),
                'time' => current_time('mysql'),
            ));
            return $response;
        }

        $code = (int) wp_remote_retrieve_response_code($response);
        $body = wp_remote_retrieve_body($response);
        $data = json_decode($body, true);
        $safe_data = is_array($data) ? $this->redact_cloud_debug_value($data) : array();
        $debug = array(
            'endpoint' => $url,
            'request' => $safe_payload,
            'http_code' => $code,
            'raw_body' => $safe_data ? substr(wp_json_encode($safe_data), 0, 3000) : '',
            'parsed' => $safe_data,
            'error' => '',
            'time' => current_time('mysql'),
        );
        $this->save_cloud_debug($debug);

        if ($code < 200 || $code >= 300) {
            return new WP_Error('barndseo_cloud_http_error', 'Cloud API returned HTTP ' . $code . '.', array('body' => $body));
        }
        if (!is_array($data)) {
            return new WP_Error('barndseo_cloud_bad_json', 'Cloud API returned an unreadable response.');
        }
        if ((isset($data['ok']) && empty($data['ok'])) || (isset($data['success']) && empty($data['success']))) {
            $msg = !empty($data['message']) ? sanitize_text_field($data['message']) : 'Cloud API did not confirm success.';
            return new WP_Error('barndseo_cloud_not_ok', $msg, $data);
        }
        if (isset($data['status']) && in_array(strtolower((string)$data['status']), array('error', 'failed', 'fail'), true)) {
            $msg = !empty($data['message']) ? sanitize_text_field($data['message']) : 'Cloud API returned an error status.';
            return new WP_Error('barndseo_cloud_status_error', $msg, $data);
        }
        $data['_barndseo_debug'] = $debug;
        return $data;
    }

    private function redact_cloud_debug_value($value, $key = '') {
        $sensitive = array('token', 'secret', 'password', 'license', 'license_key', 'api_key', 'apikey', 'authorization');
        $normalized_key = strtolower((string)$key);
        foreach ($sensitive as $needle) {
            if ($normalized_key !== '' && strpos($normalized_key, $needle) !== false) {
                return '[redacted]';
            }
        }
        if (is_array($value)) {
            $clean = array();
            foreach ($value as $child_key => $child_value) {
                $clean[$child_key] = $this->redact_cloud_debug_value($child_value, $child_key);
            }
            return $clean;
        }
        return $value;
    }

    private function save_cloud_debug($debug) {
        $o = $this->opts();
        $o['last_cloud_debug'] = is_array($debug) ? $this->sanitize_cloud_debug_value($debug) : array();
        update_option(self::OPTION, wp_parse_args($o, self::default_options()));
    }

    private function sanitize_cloud_debug_value($value) {
        if (is_array($value)) {
            $clean = array();
            foreach ($value as $key => $child) {
                $clean[sanitize_key((string) $key)] = $this->sanitize_cloud_debug_value($child);
            }
            return $clean;
        }
        if (is_bool($value)) {
            return $value;
        }
        if (is_int($value) || is_float($value)) {
            return $value;
        }
        if ($value === null) {
            return null;
        }
        return sanitize_text_field((string) $value);
    }

    private function cloud_get_path($data, $path) {
        if (!is_array($data)) {
            return null;
        }
        $current = $data;
        foreach (explode('.', $path) as $part) {
            if (!is_array($current) || !array_key_exists($part, $current)) {
                return null;
            }
            $current = $current[$part];
        }
        return $current;
    }

    private function cloud_normalize_success($data) {
        if (!is_array($data)) {
            return false;
        }
        if (array_key_exists('ok', $data)) {
            return !empty($data['ok']);
        }
        if (array_key_exists('success', $data)) {
            return !empty($data['success']);
        }
        if (array_key_exists('status', $data)) {
            $status = strtolower((string)$data['status']);
            return in_array($status, array('ok', 'success', 'active', 'registered'), true);
        }
        // HTTP 2xx plus valid JSON is allowed only if a whitelisted Cloud Site ID is present.
        return null;
    }

    private function normalize_cloud_response($data) {
        if (!is_array($data)) {
            return array(
                'ok' => false,
                'error_code' => 'INVALID_RESPONSE',
                'message' => 'Cloud API response was not a JSON object.',
                '_barndseo_trace' => array('source_path' => '', 'expected_paths' => array(), 'notes' => array('Invalid JSON object.')),
            );
        }

        $allowed_id_paths = array(
            'cloud_site_id',
            'data.cloud_site_id',
            'result.cloud_site_id',
        );
        $allowed_feature_paths = array(
            'features',
            'feature_flags',
            'data.features',
            'data.feature_flags',
            'result.features',
            'result.feature_flags',
        );
        $allowed_plan_paths = array('plan', 'data.plan', 'result.plan');
        $allowed_status_paths = array('status', 'data.status', 'result.status');
        $allowed_registered_paths = array('registered_at', 'data.registered_at', 'result.registered_at');
        $allowed_last_seen_paths = array('last_seen_at', 'data.last_seen_at', 'result.last_seen_at', 'synced_at', 'data.synced_at', 'result.synced_at');

        $trace = array(
            'schema' => 'CloudResponseSchema v1 strict whitelist',
            'source_path' => '',
            'expected_paths' => $allowed_id_paths,
            'notes' => array(),
        );

        $normalized = array(
            'ok' => $this->cloud_normalize_success($data),
            'cloud_site_id' => '',
            'plan' => '',
            'status' => '',
            'registered_at' => '',
            'last_seen_at' => '',
            'features' => array(),
            '_barndseo_trace' => $trace,
        );

        foreach ($allowed_id_paths as $path) {
            $value = $this->cloud_get_path($data, $path);
            if (is_scalar($value) && trim((string)$value) !== '') {
                $candidate = sanitize_text_field((string)$value);
                if (strpos($candidate, 'barnd_') === 0) {
                    $normalized['_barndseo_trace']['notes'][] = 'Ignored local barnd_ ID at ' . $path . ' because Cloud Site ID must be assigned by api.barndai.com.';
                    continue;
                }
                if (strpos($candidate, 'bsite_') !== 0) {
                    $normalized['_barndseo_trace']['notes'][] = 'Ignored invalid Cloud Site ID at ' . $path . '; expected the bsite_ prefix.';
                    continue;
                }
                $normalized['cloud_site_id'] = $candidate;
                $normalized['_barndseo_trace']['source_path'] = $path;
                break;
            }
        }

        foreach ($allowed_plan_paths as $path) {
            $value = $this->cloud_get_path($data, $path);
            if (is_scalar($value) && trim((string)$value) !== '') {
                $normalized['plan'] = sanitize_key((string)$value);
                break;
            }
        }
        foreach ($allowed_status_paths as $path) {
            $value = $this->cloud_get_path($data, $path);
            if (is_scalar($value) && trim((string)$value) !== '') {
                $normalized['status'] = sanitize_key((string)$value);
                break;
            }
        }
        foreach ($allowed_registered_paths as $path) {
            $value = $this->cloud_get_path($data, $path);
            if (is_scalar($value) && trim((string)$value) !== '') {
                $normalized['registered_at'] = sanitize_text_field((string)$value);
                break;
            }
        }
        foreach ($allowed_last_seen_paths as $path) {
            $value = $this->cloud_get_path($data, $path);
            if (is_scalar($value) && trim((string)$value) !== '') {
                $normalized['last_seen_at'] = sanitize_text_field((string)$value);
                break;
            }
        }
        foreach ($allowed_feature_paths as $path) {
            $value = $this->cloud_get_path($data, $path);
            if (is_array($value)) {
                $normalized['features'] = $value;
                break;
            }
        }

        if ($normalized['ok'] === null) {
            $normalized['ok'] = ($normalized['cloud_site_id'] !== '');
        }
        if ($normalized['cloud_site_id'] === '') {
            $normalized['error_code'] = 'MISSING_CLOUD_SITE_ID';
            $normalized['message'] = 'Cloud API response did not include a Cloud Site ID in the approved schema paths.';
            $normalized['_barndseo_trace']['notes'][] = 'No regex or wildcard extraction was used. Update api.barndai.com to return cloud_site_id or data.cloud_site_id.';
        }

        return $normalized;
    }

    private function update_cloud_debug_normalized($normalized) {
        $o = $this->opts();
        $debug = (!empty($o['last_cloud_debug']) && is_array($o['last_cloud_debug'])) ? $o['last_cloud_debug'] : array();
        $debug['normalized'] = $normalized;
        $debug['normalization_trace'] = !empty($normalized['_barndseo_trace']) ? $normalized['_barndseo_trace'] : array();
        $this->save_cloud_debug($debug);
    }

    private function get_cloud_state() {
        $o = $this->opts();
        return array(
            'local_site_id' => $this->get_or_create_cloud_local_site_id(),
            'cloud_site_id' => !empty($o['cloud_site_id']) ? sanitize_text_field($o['cloud_site_id']) : '',
            'plan' => !empty($o['cloud_plan']) ? sanitize_key($o['cloud_plan']) : 'free',
            'status' => !empty($o['cloud_status']) ? sanitize_key($o['cloud_status']) : 'local_only',
            'registered_at' => !empty($o['cloud_registered_at']) ? sanitize_text_field($o['cloud_registered_at']) : '',
            'last_seen_at' => !empty($o['cloud_last_seen_at']) ? sanitize_text_field($o['cloud_last_seen_at']) : '',
            'features' => (!empty($o['cloud_features']) && is_array($o['cloud_features'])) ? $o['cloud_features'] : array(),
            'last_error' => !empty($o['last_cloud_error']) ? sanitize_text_field($o['last_cloud_error']) : '',
            'debug' => (!empty($o['last_cloud_debug']) && is_array($o['last_cloud_debug'])) ? $o['last_cloud_debug'] : array(),
        );
    }

    private function save_cloud_response($data) {
        $normalized = $this->normalize_cloud_response($data);
        $this->update_cloud_debug_normalized($normalized);

        $o = $this->opts();
        $o['cloud_local_site_id'] = $this->get_or_create_cloud_local_site_id();

        if (empty($normalized['cloud_site_id'])) {
            $o['cloud_status'] = 'partial_sync';
            $o['last_cloud_error'] = !empty($normalized['message']) ? sanitize_text_field($normalized['message']) : 'Cloud API response did not include a Cloud Site ID.';
            update_option(self::OPTION, wp_parse_args($o, self::default_options()));
            return $normalized;
        }

        $o['cloud_site_id'] = sanitize_text_field($normalized['cloud_site_id']);
        $o['cloud_plan'] = !empty($normalized['plan']) ? sanitize_key($normalized['plan']) : (!empty($o['cloud_plan']) ? sanitize_key($o['cloud_plan']) : 'free');
        $o['cloud_status'] = !empty($normalized['status']) ? sanitize_key($normalized['status']) : 'active';

        if (!empty($normalized['registered_at'])) {
            $o['cloud_registered_at'] = sanitize_text_field($normalized['registered_at']);
        } elseif (empty($o['cloud_registered_at'])) {
            $o['cloud_registered_at'] = current_time('mysql');
        }

        if (!empty($normalized['last_seen_at'])) {
            $o['cloud_last_seen_at'] = sanitize_text_field($normalized['last_seen_at']);
        } else {
            $o['cloud_last_seen_at'] = current_time('mysql');
        }

        if (!empty($normalized['features']) && is_array($normalized['features'])) {
            $o['cloud_features'] = $this->sanitize_cloud_features($normalized['features']);
        }

        $o['last_cloud_error'] = '';
        update_option(self::OPTION, wp_parse_args($o, self::default_options()));
        return $normalized;
    }

    private function sanitize_cloud_features($features) {
        $clean = array();
        foreach ((array)$features as $key => $value) {
            $clean[sanitize_key($key)] = !empty($value) ? true : false;
        }
        return $clean;
    }

    private function cloud_feature_labels() {
        return array(
            'free_registration' => 'Free registration',
            'ai_meta' => 'AI title/meta drafts',
            'ai_image_alt' => 'AI image ALT drafts',
            'ai_faq' => 'AI FAQ drafts',
            'bulk_ai' => 'Bulk AI fixes',
            'search_console_api' => 'Search Console API',
            'scheduled_scans' => 'Scheduled scans',
            'pdf_reports' => 'PDF reports',
            'agency_dashboard' => 'Agency dashboard',
        );
    }

    public function cloud_page() {
        if (!current_user_can('manage_options')) return;
        $message = '';
        $error = '';
        $local_site_id = $this->get_or_create_cloud_local_site_id();
        $o = $this->opts();

        if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['barndseo_cloud_action'])) {
            check_admin_referer(self::NONCE_ACTION, self::NONCE_NAME);
            $action = sanitize_key(wp_unslash($_POST['barndseo_cloud_action']));
            $this->save_cloud_debug(array(
                'stage' => 'cloud_form_post_received',
                'posted_action' => $action,
                'request_uri' => isset($_SERVER['REQUEST_URI']) ? sanitize_text_field(wp_unslash($_SERVER['REQUEST_URI'])) : '',
                'time' => current_time('mysql'),
                'note' => 'Barnd AI Cloud admin form submitted before API request handling.',
            ));
            if ($action === 'register_free_online') {
                $payload = $this->cloud_payload_base();
                $result = $this->cloud_post('/v1/sites/register', $payload);
                if (is_wp_error($result)) {
                    $error = $result->get_error_message();
                    $o = $this->opts();
                    $o['last_cloud_error'] = $error;
                    update_option(self::OPTION, wp_parse_args($o, self::default_options()));
                } else {
                    $this->save_cloud_response($result);
                    $o_after_register = $this->opts();
                    // Immediately refresh status when the API returned a Cloud Site ID so the UI does not show stale/local-only state.
                    if (!empty($o_after_register['cloud_site_id'])) {
                        $sync_payload = array(
                            'local_site_id' => $this->get_or_create_cloud_local_site_id(),
                            'cloud_site_id' => sanitize_text_field($o_after_register['cloud_site_id']),
                            'site_url' => site_url(),
                            'plugin' => 'barnd-ai-seo',
                        );
                        $sync_result = $this->cloud_post('/v1/sites/status', $sync_payload);
                        if (!is_wp_error($sync_result)) {
                            $this->save_cloud_response($sync_result);
                        }
                    }
                    $state_after = $this->get_cloud_state();
                    if (!empty($state_after['cloud_site_id'])) {
                        $message = !empty($result['message']) ? sanitize_text_field($result['message']) : 'Free site registered with Barnd AI Cloud.';
                    } else {
                        $error = 'Cloud replied, but no Cloud Site ID was returned. Free tools still work locally. See Cloud Debug below and update the Cloud API response mapping if needed.';
                        $o_tmp = $this->opts();
                        $o_tmp['last_cloud_error'] = $error;
                        update_option(self::OPTION, wp_parse_args($o_tmp, self::default_options()));
                    }
                }
            } elseif ($action === 'sync_status') {
                $o = $this->opts();
                if (empty($o['cloud_site_id'])) {
                    $error = 'Please register this site online first.';
                    $o['last_cloud_error'] = $error;
                    update_option(self::OPTION, wp_parse_args($o, self::default_options()));
                } else {
                    $payload = array(
                        'local_site_id' => $this->get_or_create_cloud_local_site_id(),
                        'cloud_site_id' => sanitize_text_field($o['cloud_site_id']),
                        'site_url' => site_url(),
                        'plugin' => 'barnd-ai-seo',
                    );
                    $result = $this->cloud_post('/v1/sites/status', $payload);
                    if (is_wp_error($result)) {
                        $error = $result->get_error_message();
                        $o = $this->opts();
                        $o['last_cloud_error'] = $error;
                        update_option(self::OPTION, wp_parse_args($o, self::default_options()));
                    } else {
                        $this->save_cloud_response($result);
                        $message = 'Cloud status synced.';
                    }
                }
            } elseif ($action === 'save_license') {
                $o = $this->opts();
                $license = isset($_POST['cloud_license_key']) ? sanitize_text_field(wp_unslash($_POST['cloud_license_key'])) : '';
                $o['cloud_license_key'] = $license;
                update_option(self::OPTION, wp_parse_args($o, self::default_options()));
                $message = 'License key saved locally. License activation will be connected after the license endpoint is ready.';
            } elseif ($action === 'clear_debug') {
                $o = $this->opts();
                $o['last_cloud_debug'] = array();
                $o['last_cloud_error'] = '';
                update_option(self::OPTION, wp_parse_args($o, self::default_options()));
                $message = 'Cloud debug details cleared.';
            } elseif ($action === 'disconnect') {
                $o = $this->opts();
                $o['cloud_site_id'] = '';
                $o['cloud_status'] = 'local_only';
                $o['cloud_plan'] = 'free';
                $o['cloud_registered_at'] = '';
                $o['cloud_last_seen_at'] = '';
                $o['cloud_features'] = array();
                $o['last_cloud_error'] = '';
                $o['cloud_license_key'] = '';
                $o['last_cloud_debug'] = array();
                update_option(self::OPTION, wp_parse_args($o, self::default_options()));
                $message = 'Online cloud status reset locally. The local Site ID remains saved and Free SEO tools continue to work.';
            }
            $local_site_id = $this->get_or_create_cloud_local_site_id();
            $o = $this->opts();
        }

        $state = $this->get_cloud_state();
        $o = $this->opts();
        $local_site_id = $state['local_site_id'];
        $cloud_site_id = $state['cloud_site_id'];
        $status = $state['status'];
        $plan = $state['plan'];
        $registered_at = $state['registered_at'] ? $state['registered_at'] : 'Not registered online yet';
        $last_seen_at = $state['last_seen_at'] ? $state['last_seen_at'] : 'Not synced yet';
        $features = $state['features'];
        $last_error = $error ? $error : $state['last_error'];
        $debug = !empty($state['debug']) && is_array($state['debug']) ? $state['debug'] : array();

        if ($cloud_site_id && $status === 'active') {
            $status_label = 'Registered Free';
            $status_class = 'barndseo-cloud-ok';
        } elseif ($status === 'partial_sync') {
            $status_label = 'Partial Sync';
            $status_class = 'barndseo-cloud-error';
        } elseif ($last_error) {
            $status_label = 'Cloud Error';
            $status_class = 'barndseo-cloud-error';
        } else {
            $status_label = 'Local Only';
            $status_class = '';
        }
        ?>
        <div class="wrap slabseo-wrap">
            <h1>Barnd AI Cloud</h1>
            <?php if ($message): ?><div class="notice notice-success"><p><?php echo esc_html($message); ?></p></div><?php endif; ?>
            <?php if ($last_error): ?><div class="notice notice-error"><p><strong>Cloud error:</strong> <?php echo esc_html($last_error); ?></p></div><?php endif; ?>
            <p>Free SEO tools work locally without online registration. Registering this site sends basic site/plugin information to Barnd AI Cloud so we can assign a Cloud Site ID, sync plan status, and prepare future Pro features.</p>
            <div class="notice notice-info inline" style="margin:12px 0 16px;"><p><strong>Privacy note:</strong> Free registration does not send post content, page content, media files, uploaded Google reports, customer data, visitor analytics, or private SEO settings.</p></div>
            <style>
                .barndseo-cloud-grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(280px,1fr));gap:16px;margin-top:18px}.barndseo-cloud-card{background:#fff;border:1px solid #dcdcde;border-radius:12px;padding:18px}.barndseo-cloud-card h2{margin-top:0}.barndseo-status{display:inline-block;border-radius:999px;padding:4px 10px;background:#eef6ff;color:#0a4b78;font-weight:700}.barndseo-cloud-code{background:#f6f7f7;border:1px solid #dcdcde;padding:8px 10px;border-radius:6px;word-break:break-all;font-family:monospace}.barndseo-cloud-muted{color:#646970}.barndseo-cloud-card input[type=text]{width:100%;max-width:100%;box-sizing:border-box}.barndseo-cloud-ok{background:#ecfdf3;color:#006b3f}.barndseo-cloud-error{background:#fff1f2;color:#b91c1c}.barndseo-cloud-row{margin:10px 0}.barndseo-feature-list{margin:0;padding:0;list-style:none}.barndseo-feature-list li{display:flex;justify-content:space-between;border-bottom:1px solid #f0f0f1;padding:6px 0;gap:12px}.barndseo-feature-on{color:#008a20;font-weight:700}.barndseo-feature-off{color:#646970}.barndseo-debug-pre{max-height:320px;overflow:auto;background:#111827;color:#e5e7eb;padding:12px;border-radius:8px;font-size:12px;white-space:pre-wrap;word-break:break-word}
            </style>
            <div class="barndseo-cloud-grid">
                <div class="barndseo-cloud-card">
                    <h2>Connection Status</h2>
                    <p><span class="barndseo-status <?php echo esc_attr($status_class); ?>"><?php echo esc_html($status_label); ?></span></p>
                    <p class="barndseo-cloud-row"><strong>Plan:</strong> <?php echo esc_html(ucfirst($plan)); ?></p>
                    <p class="barndseo-cloud-row"><strong>Status:</strong> <?php echo esc_html($status); ?></p>
                    <p class="barndseo-cloud-row"><strong>Last Registered:</strong> <?php echo esc_html($registered_at); ?></p>
                    <p class="barndseo-cloud-row"><strong>Last Synced:</strong> <?php echo esc_html($last_seen_at); ?></p>
                    <p class="barndseo-cloud-row"><strong>Local Site ID:</strong></p>
                    <div class="barndseo-cloud-code"><?php echo esc_html($local_site_id); ?></div>
                    <p class="barndseo-cloud-row"><strong>Cloud Site ID:</strong></p>
                    <div class="barndseo-cloud-code"><?php echo $cloud_site_id ? esc_html($cloud_site_id) : 'Not registered online yet'; ?></div>
                </div>
                <div class="barndseo-cloud-card">
                    <h2>Register Free Site Online</h2>
                    <p>Click once to register this Free site with Barnd AI Cloud. Free tools still work if registration fails or if you skip this step.</p>
                    <p class="barndseo-cloud-muted">Allowed data: site URL, home URL, plugin/version, WordPress/PHP version, site type, setup mode, locale, timezone, plan, and local Site ID.</p>
                    <form method="post">
                        <?php wp_nonce_field(self::NONCE_ACTION, self::NONCE_NAME); ?>
                        <input type="hidden" name="barndseo_cloud_action" value="register_free_online">
                        <button class="button button-primary"><?php echo $cloud_site_id ? 'Refresh Free Registration Online' : 'Register Free Site Online'; ?></button>
                    </form>
                    <form method="post" style="margin-top:10px;">
                        <?php wp_nonce_field(self::NONCE_ACTION, self::NONCE_NAME); ?>
                        <input type="hidden" name="barndseo_cloud_action" value="sync_status">
                        <button class="button">Sync Site Status</button>
                    </form>
                </div>
                <div class="barndseo-cloud-card">
                    <h2>Feature Flags</h2>
                    <?php if (empty($features)): ?>
                        <p class="barndseo-cloud-muted">No cloud feature flags synced yet. Register online to load the Free plan flags.</p>
                    <?php else: ?>
                        <ul class="barndseo-feature-list">
                        <?php foreach ($this->cloud_feature_labels() as $key => $label): ?>
                            <li><span><?php echo esc_html($label); ?></span><span class="<?php echo !empty($features[$key]) ? 'barndseo-feature-on' : 'barndseo-feature-off'; ?>"><?php echo !empty($features[$key]) ? 'On' : 'Off'; ?></span></li>
                        <?php endforeach; ?>
                        </ul>
                    <?php endif; ?>
                </div>
                <div class="barndseo-cloud-card">
                    <h2>Pro License</h2>
                    <p>Save a license key now if you are testing a Pro flow. Validation will connect to Barnd AI Cloud after the license endpoint is ready.</p>
                    <form method="post">
                        <?php wp_nonce_field(self::NONCE_ACTION, self::NONCE_NAME); ?>
                        <input type="hidden" name="barndseo_cloud_action" value="save_license">
                        <p><input type="text" name="cloud_license_key" value="<?php echo esc_attr($o['cloud_license_key'] ?? ''); ?>" placeholder="BARND-XXXX-XXXX"></p>
                        <button class="button">Save License Key</button>
                    </form>
                </div>
                <div class="barndseo-cloud-card">
                    <h2>Privacy Promise for Free</h2>
                    <p>Free mode does not send post content, page content, uploaded Google reports, media files, customer data, visitor analytics, admin usernames/emails, order data, scan dumps, or private plugin settings unrelated to Barnd.</p>
                    <p>Online registration only starts after an admin clicks <strong>Register Free Site Online</strong>.</p>
                    <form method="post">
                        <?php wp_nonce_field(self::NONCE_ACTION, self::NONCE_NAME); ?>
                        <input type="hidden" name="barndseo_cloud_action" value="disconnect">
                        <button class="button">Reset Online Cloud Status</button>
                    </form>
                </div>
                <div class="barndseo-cloud-card">
                    <h2>Last Cloud Error</h2>
                    <p><?php echo $last_error ? esc_html($last_error) : 'No cloud error saved.'; ?></p>
                </div>
                <?php $show_debug = (defined('WP_DEBUG') && WP_DEBUG) || !empty($_GET['barnd_debug']); ?>
                <?php if ($show_debug): ?>
                <div class="barndseo-cloud-card" style="grid-column:1/-1;">
                    <h2>Cloud Debug</h2>
                    <p class="barndseo-cloud-muted">Strict schema mode is active. Cloud Site ID is accepted only from approved response paths; no wildcard or raw-text guessing is used. This panel appears only when WordPress debug is on or <code>barnd_debug=1</code> is in the URL.</p>
                    <?php if (empty($debug)): ?>
                        <p>No cloud debug details saved yet.</p>
                    <?php else: ?>
                        <?php $debug_json = wp_json_encode($debug, JSON_PRETTY_PRINT); ?>
                        <pre id="barndseo-cloud-debug-json" class="barndseo-debug-pre"><?php echo esc_html($debug_json); ?></pre>
                        <div style="display:flex;gap:8px;align-items:center;flex-wrap:wrap;margin-top:10px;">
                            <button type="button" class="button" id="barndseo-copy-cloud-debug">Copy Cloud Debug</button>
                            <span id="barndseo-copy-cloud-debug-status" aria-live="polite"></span>
                        <form method="post" style="margin:0;">
                            <?php wp_nonce_field(self::NONCE_ACTION, self::NONCE_NAME); ?>
                            <input type="hidden" name="barndseo_cloud_action" value="clear_debug">
                            <button class="button">Clear Cloud Debug</button>
                        </form>
                        </div>
                        <script>
                        (function () {
                            var button = document.getElementById('barndseo-copy-cloud-debug');
                            var source = document.getElementById('barndseo-cloud-debug-json');
                            var status = document.getElementById('barndseo-copy-cloud-debug-status');
                            if (!button || !source) return;

                            button.addEventListener('click', function () {
                                var text = source.textContent || '';
                                var copied = function () {
                                    button.textContent = 'Copied!';
                                    if (status) status.textContent = 'Cloud debug copied to clipboard.';
                                    window.setTimeout(function () {
                                        button.textContent = 'Copy Cloud Debug';
                                        if (status) status.textContent = '';
                                    }, 2500);
                                };

                                if (navigator.clipboard && window.isSecureContext) {
                                    navigator.clipboard.writeText(text).then(copied).catch(function () {
                                        fallbackCopy(text, copied);
                                    });
                                } else {
                                    fallbackCopy(text, copied);
                                }
                            });

                            function fallbackCopy(text, onSuccess) {
                                var area = document.createElement('textarea');
                                area.value = text;
                                area.setAttribute('readonly', '');
                                area.style.position = 'fixed';
                                area.style.opacity = '0';
                                document.body.appendChild(area);
                                area.select();
                                try {
                                    if (document.execCommand('copy')) onSuccess();
                                } finally {
                                    document.body.removeChild(area);
                                }
                            }
                        }());
                        </script>
                    <?php endif; ?>
                </div>
                <?php else: ?>
                <div class="barndseo-cloud-card" style="grid-column:1/-1;">
                    <h2>Cloud Debug</h2>
                    <p class="barndseo-cloud-muted">Hidden for normal users. Add <code>&barnd_debug=1</code> to this page URL if you need to inspect the latest cloud request and response.</p>
                </div>
                <?php endif; ?>
            </div>
            <p><a class="button" href="<?php echo esc_url(admin_url('admin.php?page=slabseo-pro-features')); ?>">View Pro Features</a> <a class="button" href="<?php echo esc_url(admin_url('admin.php?page=slab-seo-assistant')); ?>">Back to Dashboard</a></p>
        </div>
        <?php
    }

    public function pro_features_page() {
        if (!current_user_can('manage_options')) return;
        ?>
        <div class="wrap slabseo-wrap">
            <h1>Barnd AI SEO Pro Features</h1>
            <p>Free stays lightweight and useful. This build can register a Free site online with api.barndai.com and sync Free plan feature flags. Pro AI features remain planned and require future license activation.</p>
            <style>.barndseo-pro-grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(260px,1fr));gap:16px;margin-top:18px}.barndseo-pro-card{background:#fff;border:1px solid #dcdcde;border-radius:12px;padding:18px}.barndseo-pro-card h2{margin-top:0}.barndseo-tag{display:inline-block;background:#fef3c7;color:#92400e;border-radius:999px;padding:4px 9px;font-weight:600;font-size:12px}</style>
            <div class="barndseo-pro-grid">
                <div class="barndseo-pro-card"><span class="barndseo-tag">Free Now</span><h2>Included in Free</h2><p>SEO audit, metadata fields, safe schema, sitemap, LLMs.txt, image ALT checks, local SEO fields, redirects, broken page tracking, link scanner, Google Performance Import, and SEO Plugin Check.</p></div>
                <div class="barndseo-pro-card"><span class="barndseo-tag">Planned Pro</span><h2>AI Draft Fixes</h2><p>AI-drafted SEO titles, descriptions, image ALT text, FAQs, internal link ideas, and Google performance suggestions through api.barndai.com.</p></div>
                <div class="barndseo-pro-card"><span class="barndseo-tag">Planned Pro</span><h2>Google API + Reports</h2><p>Direct Search Console connection, scheduled scans, monthly reports, and agency-friendly summaries after the Free plugin is stable.</p></div>
                <div class="barndseo-pro-card"><span class="barndseo-tag">Agency Later</span><h2>White-label Workflow</h2><p>Multi-site checks, client-ready notes, usage controls, webhooks, and reporting for busy agencies and solo SEO operators.</p></div>
            </div>
            <p><a class="button button-primary" href="<?php echo esc_url(admin_url('admin.php?page=slab-seo-assistant')); ?>">Back to Dashboard</a></p>
        </div>
        <?php
    }

    public function register_settings() {
        register_setting('slabseo_settings_group', self::OPTION, array($this, 'sanitize_options'));
    }

    public function sanitize_options($input) {
        $defaults = self::default_options();
        $output = array();

        $text_fields = array(
            'brand_name','legal_owner','site_description','business_email','business_phone','street_address',
            'address_locality','address_region','postal_code','address_country','latitude','longitude','price_range',
            'serves_cuisine','opening_hours','area_served','google_verification','default_pov','affiliate_domains','setup_mode'
        );
        foreach ($text_fields as $field) {
            $output[$field] = isset($input[$field]) ? sanitize_text_field($input[$field]) : ($defaults[$field] ?? '');
        }

        $url_fields = array(
            'logo_url','menu_url','order_url','instagram_url','tiktok_url','facebook_url','pinterest_url','youtube_url',
            'threads_url','x_url','linkedin_url','google_business_profile_url','reddit_url'
        );
        foreach ($url_fields as $field) {
            $output[$field] = isset($input[$field]) ? esc_url_raw($input[$field]) : '';
        }

        $output['logo_id'] = isset($input['logo_id']) ? (string)absint($input['logo_id']) : '0';
        $output['social_profiles'] = isset($input['social_profiles']) ? sanitize_textarea_field($input['social_profiles']) : '';
        $output['robots_extra'] = isset($input['robots_extra']) ? sanitize_textarea_field($input['robots_extra']) : ($defaults['robots_extra'] ?? '');

        $allowed_site_types = array('blog','publisher_review','restaurant','franchise','local_business','organization','agency_client');
        $output['site_type'] = in_array($input['site_type'] ?? '', $allowed_site_types, true) ? $input['site_type'] : 'publisher_review';
        foreach (array('show_address','enable_sitemap','enable_schema','enable_social_meta','enable_robots','enable_llms','disable_public_comments','setup_completed') as $bool) {
            $output[$bool] = !empty($input[$bool]) ? '1' : '0';
        }

        // Preserve cloud fields when the normal Settings page omits them, while allowing
        // internal cloud update_option() calls to persist the values they explicitly pass.
        // WordPress applies this registered sanitizer to direct update_option() calls too.
        $existing = $this->opts();
        foreach (array('cloud_local_site_id','cloud_site_id','cloud_status','cloud_plan','cloud_registered_at','cloud_last_seen_at','last_cloud_error','cloud_license_key') as $cloud_field) {
            if (array_key_exists($cloud_field, $input)) {
                $output[$cloud_field] = sanitize_text_field($input[$cloud_field]);
            } else {
                $output[$cloud_field] = isset($existing[$cloud_field]) ? sanitize_text_field($existing[$cloud_field]) : ($defaults[$cloud_field] ?? '');
            }
        }
        if (array_key_exists('cloud_features', $input)) {
            $output['cloud_features'] = is_array($input['cloud_features']) ? $this->sanitize_cloud_features($input['cloud_features']) : array();
        } else {
            $output['cloud_features'] = (!empty($existing['cloud_features']) && is_array($existing['cloud_features'])) ? $this->sanitize_cloud_features($existing['cloud_features']) : array();
        }
        if (array_key_exists('last_cloud_debug', $input)) {
            $output['last_cloud_debug'] = is_array($input['last_cloud_debug']) ? $this->sanitize_cloud_debug_value($input['last_cloud_debug']) : array();
        } else {
            $output['last_cloud_debug'] = (!empty($existing['last_cloud_debug']) && is_array($existing['last_cloud_debug'])) ? $this->sanitize_cloud_debug_value($existing['last_cloud_debug']) : array();
        }

        return wp_parse_args($output, $defaults);
    }

    public function settings_page() {
        if (!current_user_can('manage_options')) return;
        $o = $this->opts();
        ?>
        <div class="wrap">
            <h1>Barnd AI SEO Settings</h1>
            <?php $mode = $this->get_setup_mode(); ?>
            <p><a class="button" href="<?php echo esc_url(admin_url('admin.php?page=slab-seo-assistant')); ?>">Dashboard</a> <a class="button" href="<?php echo esc_url(admin_url('admin.php?page=slabseo-image-seo')); ?>">Image SEO</a> <a class="button" href="<?php echo esc_url(admin_url('admin.php?page=slabseo-audit')); ?>">SEO Audit</a><?php if ($mode === 'advanced'): ?> <a class="button" href="<?php echo esc_url(admin_url('admin.php?page=slabseo-tools')); ?>">SEO Tools</a><?php endif; ?></p>
            <p>Lightweight SEO setup, schema, snippets, image ALT checks, sitemap, local SEO, and content cleanup for busy WordPress sites.</p>
            <form method="post" action="options.php">
                <?php settings_fields('slabseo_settings_group'); ?>
                <h2>Site Identity</h2>
                <table class="form-table" role="presentation">
                    <?php $this->text_row('Brand Name', 'brand_name', $o); ?>
                    <?php $this->text_row('Legal Owner', 'legal_owner', $o, 'Example: Your company name'); ?>
                    <?php $this->select_row('Site Type', 'site_type', $o, array(
                        'blog' => 'Blog',
                        'publisher_review' => 'Publisher / Affiliate Review Site',
                        'restaurant' => 'Restaurant / Food Business',
                        'franchise' => 'Franchise / Business Opportunity Site',
                        'local_business' => 'Local Business',
                        'organization' => 'Organization',
                        'agency_client' => 'Agency Client Site'
                    )); ?>
                    <?php $this->text_row('Site Description', 'site_description', $o); ?>
                    <?php $this->logo_picker_row($o); ?>
                    <tr><th scope="row">Default Brand Point of View</th><td><textarea name="<?php echo esc_attr(self::OPTION); ?>[default_pov]" rows="3" class="large-text"><?php echo esc_textarea($o['default_pov'] ?? ''); ?></textarea><p class="description">Optional manual guidance used for page cleanup notes and schema descriptions.</p></td></tr>
                </table>

                <h2>Local / Restaurant SEO</h2>
                <table class="form-table" role="presentation">
                    <tr><th scope="row">Show Address in Schema</th><td><label><input type="checkbox" name="<?php echo esc_attr(self::OPTION); ?>[show_address]" value="1" <?php checked($o['show_address'] ?? '', '1'); ?>> Include address fields in LocalBusiness / Restaurant schema.</label></td></tr>
                    <?php $this->text_row('Street Address', 'street_address', $o); ?>
                    <?php $this->text_row('City', 'address_locality', $o); ?>
                    <?php $this->text_row('Province / State', 'address_region', $o); ?>
                    <?php $this->text_row('Postal Code', 'postal_code', $o); ?>
                    <?php $this->text_row('Country', 'address_country', $o); ?>
                    <?php $this->text_row('Phone', 'business_phone', $o); ?>
                    <?php $this->text_row('Email', 'business_email', $o); ?>
                    <?php $this->text_row('Latitude', 'latitude', $o); ?>
                    <?php $this->text_row('Longitude', 'longitude', $o); ?>
                    <?php $this->text_row('Price Range', 'price_range', $o, 'Example: $$'); ?>
                    <?php $this->text_row('Serves Cuisine', 'serves_cuisine', $o, 'Restaurant sites only. Example: Burgers, Pizza, Sushi'); ?>
                    <?php $this->text_row('Opening Hours', 'opening_hours', $o, 'Schema format: Mo-Fr 11:00-21:00. Use comma-separated ranges.'); ?>
                    <?php $this->text_row('Menu URL', 'menu_url', $o, 'Restaurant/menu page URL.'); ?>
                    <?php $this->text_row('Order URL', 'order_url', $o, 'Online ordering URL, if available.'); ?>
                    <?php $this->text_row('Area Served', 'area_served', $o, 'Example: Toronto, GTA, Ajax.'); ?>
                </table>

                <h2>Google / Social</h2>
                <table class="form-table" role="presentation">
                    <?php $this->text_row('Google Search Console Verification Code', 'google_verification', $o, 'Paste only the content value, not the full meta tag.'); ?>
                    <?php $this->text_row('Instagram URL', 'instagram_url', $o); ?>
                    <?php $this->text_row('TikTok URL', 'tiktok_url', $o); ?>
                    <?php $this->text_row('Facebook URL', 'facebook_url', $o); ?>
                    <?php $this->text_row('Pinterest URL', 'pinterest_url', $o); ?>
                    <?php $this->text_row('YouTube URL', 'youtube_url', $o); ?>
                    <?php $this->text_row('Threads URL', 'threads_url', $o); ?>
                    <?php $this->text_row('X.com URL', 'x_url', $o); ?>
                    <?php $this->text_row('LinkedIn URL', 'linkedin_url', $o); ?>
                    <?php $this->text_row('Google Business Profile URL', 'google_business_profile_url', $o); ?>
                    <?php $this->text_row('Reddit URL', 'reddit_url', $o); ?>
                    <tr><th scope="row">Additional Social Profile URLs</th><td><textarea name="<?php echo esc_attr(self::OPTION); ?>[social_profiles]" rows="3" class="large-text"><?php echo esc_textarea($o['social_profiles'] ?? ''); ?></textarea><p class="description">Optional. One extra URL per line. Used in sameAs schema.</p></td></tr>
                </table>

                <h2>Output Controls</h2>
                <table class="form-table" role="presentation">
                    <tr><th scope="row">Schema Output</th><td><label><input type="checkbox" name="<?php echo esc_attr(self::OPTION); ?>[enable_schema]" value="1" <?php checked($o['enable_schema'] ?? '', '1'); ?>> Enable JSON-LD schema output.</label></td></tr>
                    <tr><th scope="row">Social Meta Output</th><td><label><input type="checkbox" name="<?php echo esc_attr(self::OPTION); ?>[enable_social_meta]" value="1" <?php checked($o['enable_social_meta'] ?? '', '1'); ?>> Enable Open Graph and X/Twitter card tags.</label></td></tr>
                    <tr><th scope="row">Domain Sitemap</th><td><label><input type="checkbox" name="<?php echo esc_attr(self::OPTION); ?>[enable_sitemap]" value="1" <?php checked($o['enable_sitemap'] ?? '', '1'); ?>> Enable the domain-based sitemap.</label><p class="description">Example: tailandhome.org uses /tailandhome-sitemap.xml. Use only one SEO sitemap plugin at a time.</p></td></tr>
                    <tr><th scope="row">LLMs.txt</th><td><label><input type="checkbox" name="<?php echo esc_attr(self::OPTION); ?>[enable_llms]" value="1" <?php checked($o['enable_llms'] ?? '', '1'); ?>> Enable /llms.txt and its discovery link.</label></td></tr>
                    <tr><th scope="row">Robots.txt Additions</th><td><label><input type="checkbox" name="<?php echo esc_attr(self::OPTION); ?>[enable_robots]" value="1" <?php checked($o['enable_robots'] ?? '', '1'); ?>> Add the Barnd sitemap and saved custom rules to WordPress robots.txt.</label></td></tr>
                    <tr><th scope="row">Public Comments</th><td><label><input type="checkbox" name="<?php echo esc_attr(self::OPTION); ?>[disable_public_comments]" value="1" <?php checked($o['disable_public_comments'] ?? '0', '1'); ?>> Hide public comments without deleting stored comments.</label><p class="description">Off by default. Enable only when you intentionally want this plugin to hide the front-end comment system.</p></td></tr>
                    <?php $this->text_row('Affiliate Domains', 'affiliate_domains', $o, 'Comma-separated domains for disclosure/link checks.'); ?>
                </table>
                <?php submit_button(); ?>
            </form>
            <hr>
            <h2>Useful URLs</h2>
            <p><strong>Sitemap:</strong> <a href="<?php echo esc_url($this->get_sitemap_url()); ?>" target="_blank"><?php echo esc_html($this->get_sitemap_url()); ?></a></p>
        </div>
        <?php
    }


    public function image_seo_page() {
        if (!current_user_can('upload_files')) return;
        $paged = max(1, absint($_GET['paged'] ?? 1));
        $filter = isset($_GET['image_filter']) ? sanitize_key($_GET['image_filter']) : 'missing_alt';
        $allowed_filters = array('missing_alt','all','unattached');
        if (!in_array($filter, $allowed_filters, true)) $filter = 'missing_alt';
        $per_page = 40;
        $args = array(
            'post_type' => 'attachment',
            'post_mime_type' => 'image',
            'post_status' => 'inherit',
            'posts_per_page' => $per_page,
            'paged' => $paged,
            'orderby' => 'date',
            'order' => 'DESC',
        );
        if ($filter === 'missing_alt') {
            $args['meta_query'] = array(
                'relation' => 'OR',
                array('key' => '_wp_attachment_image_alt', 'compare' => 'NOT EXISTS'),
                array('key' => '_wp_attachment_image_alt', 'value' => '', 'compare' => '='),
            );
        } elseif ($filter === 'unattached') {
            $args['post_parent'] = 0;
        }
        $q = new WP_Query($args);
        $nonce = wp_create_nonce(self::NONCE_ACTION);
        $filter_urls = array(
            'missing_alt' => admin_url('admin.php?page=slabseo-image-seo&image_filter=missing_alt'),
            'all' => admin_url('admin.php?page=slabseo-image-seo&image_filter=all'),
            'unattached' => admin_url('admin.php?page=slabseo-image-seo&image_filter=unattached'),
        );
        ?>
        <div class="wrap">
            <h1>Barnd Image SEO Quick Fixes</h1>
            <p>Fix image ALT text directly from this table. This avoids opening every Media Library item one by one.</p>
            <div class="notice notice-info"><p><strong>Free mode:</strong> manually edit and save image SEO fields. AI image drafts will belong to Barnd AI SEO Pro later.</p></div>
            <div id="barndseo-image-status" class="notice notice-success" style="display:none;"><p></p></div>
            <style>
                .barndseo-image-filters{background:#fff;border:1px solid #dcdcde;border-radius:8px;padding:10px 12px;margin:12px 0;display:flex;gap:8px;align-items:center;flex-wrap:wrap;}
                #slabseo-image-table{table-layout:fixed;}
                #slabseo-image-table th:nth-child(1){width:92px;}
                #slabseo-image-table th:nth-child(2){width:24%;}
                #slabseo-image-table th:nth-child(4){width:145px;}
                #slabseo-image-table td{vertical-align:top;}
                #slabseo-image-table input[type="text"],#slabseo-image-table textarea{width:100%;max-width:none;box-sizing:border-box;}
                #slabseo-image-table textarea{min-height:44px;height:44px;resize:vertical;}
                .barndseo-image-row-saved{display:none;color:#007017;font-weight:600;font-size:12px;margin-top:4px;}
                .barndseo-image-meta{color:#646970;font-size:12px;}
            </style>
            <div class="barndseo-image-filters">
                <strong>Show:</strong>
                <a class="button button-small <?php echo $filter === 'missing_alt' ? 'button-primary' : ''; ?>" href="<?php echo esc_url($filter_urls['missing_alt']); ?>">Missing ALT only</a>
                <a class="button button-small <?php echo $filter === 'all' ? 'button-primary' : ''; ?>" href="<?php echo esc_url($filter_urls['all']); ?>">All images</a>
                <a class="button button-small <?php echo $filter === 'unattached' ? 'button-primary' : ''; ?>" href="<?php echo esc_url($filter_urls['unattached']); ?>">Unattached images</a>
                <a class="button button-small" href="<?php echo esc_url(admin_url('upload.php')); ?>">Open Media Library</a>
            </div>
            <table class="widefat fixed striped" id="slabseo-image-table">
                <thead><tr>
                    <th>Image</th>
                    <th>Current Status</th>
                    <th>Quick Fix Fields</th>
                    <th>Action</th>
                </tr></thead>
                <tbody>
                <?php if ($q->have_posts()): foreach ($q->posts as $att):
                    $alt = (string)get_post_meta($att->ID, '_wp_attachment_image_alt', true);
                    $thumb = wp_get_attachment_image($att->ID, array(80,80), true, array('style'=>'max-width:80px;height:auto;'));
                    $missing = array();
                    if (!$alt) $missing[] = 'ALT';
                    if (!$att->post_title) $missing[] = 'Title';
                    if (!$att->post_excerpt) $missing[] = 'Caption';
                    if (!$att->post_content) $missing[] = 'Description';
                    $parent_title = '';
                    $parent_link = '';
                    if (!empty($att->post_parent)) {
                        $parent_title = get_the_title($att->post_parent);
                        $parent_link = get_edit_post_link($att->post_parent);
                    }
                    $file_path = get_attached_file($att->ID);
                    $file_size = ($file_path && file_exists($file_path)) ? size_format(filesize($file_path)) : '';
                    ?>
                    <tr data-attachment-id="<?php echo esc_attr($att->ID); ?>">
                        <td><?php echo $thumb; ?></td>
                        <td>
                            <p><strong><?php echo esc_html($att->post_title ?: '(no title)'); ?></strong></p>
                            <p><strong>Status:</strong> <?php echo $missing ? '<span style="color:#b45f06;font-weight:600;">Missing '.esc_html(implode(', ', $missing)).'</span>' : '<span style="color:#007017;font-weight:600;">Complete</span>'; ?></p>
                            <?php if ($file_size): ?><p class="barndseo-image-meta">File size: <?php echo esc_html($file_size); ?></p><?php endif; ?>
                            <p class="barndseo-image-meta">Parent: <?php echo $parent_title ? '<a href="'.esc_url($parent_link).'">'.esc_html($parent_title).'</a>' : 'Unattached'; ?></p>
                            <p><a href="<?php echo esc_url(get_edit_post_link($att->ID)); ?>" target="_blank">Open media</a></p>
                        </td>
                        <td>
                            <label><strong>ALT text</strong><br><input type="text" class="regular-text barndseo-image-alt" value="<?php echo esc_attr($alt); ?>" placeholder="Describe the image for search and accessibility"></label>
                            <p style="margin:8px 0 0;"><label><strong>Title</strong><br><input type="text" class="regular-text barndseo-image-title" value="<?php echo esc_attr($att->post_title); ?>"></label></p>
                            <p style="margin:8px 0 0;"><label><strong>Caption</strong><br><textarea class="large-text barndseo-image-caption" rows="2"><?php echo esc_textarea($att->post_excerpt); ?></textarea></label></p>
                            <p style="margin:8px 0 0;"><label><strong>Description</strong><br><textarea class="large-text barndseo-image-description" rows="2"><?php echo esc_textarea($att->post_content); ?></textarea></label></p>
                        </td>
                        <td>
                            <button type="button" class="button button-primary barndseo-save-image" data-id="<?php echo esc_attr($att->ID); ?>">Save Image SEO</button>
                            <div class="barndseo-image-row-saved">Saved</div>
                            <p><a class="button" href="<?php echo esc_url(get_edit_post_link($att->ID)); ?>">Edit Media</a></p>
                        </td>
                    </tr>
                <?php endforeach; else: ?>
                    <tr><td colspan="4">No images found for this filter.</td></tr>
                <?php endif; ?>
                </tbody>
            </table>
            <div class="tablenav"><div class="tablenav-pages">
                <?php
                echo paginate_links(array(
                    'base' => add_query_arg(array('paged'=>'%#%', 'image_filter'=>$filter)),
                    'format' => '',
                    'prev_text' => '&laquo;',
                    'next_text' => '&raquo;',
                    'total' => max(1, $q->max_num_pages),
                    'current' => $paged,
                ));
                ?>
            </div></div>
        </div>
        <script>
        (function($){
            const ajaxUrl = <?php echo wp_json_encode(admin_url('admin-ajax.php')); ?>;
            const nonce = <?php echo wp_json_encode($nonce); ?>;
            function showStatus(message, ok){
                const box = $('#barndseo-image-status');
                box.removeClass('notice-success notice-error').addClass(ok ? 'notice-success' : 'notice-error');
                box.find('p').html(message);
                box.show();
            }
            $('.barndseo-save-image').on('click', function(){
                const btn = $(this);
                const row = btn.closest('tr');
                btn.prop('disabled', true).text('Saving...');
                $.post(ajaxUrl, {
                    action: 'barndseo_quick_save_image_seo',
                    nonce: nonce,
                    attachment_id: btn.data('id'),
                    alt: row.find('.barndseo-image-alt').val(),
                    title: row.find('.barndseo-image-title').val(),
                    caption: row.find('.barndseo-image-caption').val(),
                    description: row.find('.barndseo-image-description').val()
                }).done(function(resp){
                    if(resp && resp.success){
                        row.find('.barndseo-image-row-saved').show();
                        showStatus('Image SEO saved. <a href="' + window.location.href + '">Refresh this view</a> to update filters and missing counts.', true);
                    } else {
                        showStatus((resp && resp.data) ? resp.data : 'Save failed.', false);
                    }
                }).fail(function(){
                    showStatus('Request failed.', false);
                }).always(function(){
                    btn.prop('disabled', false).text('Save Image SEO');
                });
            });
        })(jQuery);
        </script>
        <?php
    }

    private function logo_picker_row($o) {
        $logo_id = absint($o['logo_id'] ?? 0);
        $logo_url = $this->get_logo_url($o);
        ?>
        <tr>
            <th scope="row"><label for="slabseo_logo_url">Logo</label></th>
            <td>
                <input id="slabseo_logo_id" type="hidden" name="<?php echo esc_attr(self::OPTION); ?>[logo_id]" value="<?php echo esc_attr($logo_id); ?>">
                <input id="slabseo_logo_url" type="text" class="regular-text" name="<?php echo esc_attr(self::OPTION); ?>[logo_url]" value="<?php echo esc_attr($o['logo_url'] ?? ''); ?>" placeholder="Optional fallback logo URL">
                <button type="button" class="button" id="slabseo_select_logo">Choose Logo from Media Library</button>
                <button type="button" class="button" id="slabseo_remove_logo">Remove</button>
                <div id="slabseo_logo_preview" style="margin-top:10px;">
                    <?php if ($logo_url): ?><img src="<?php echo esc_url($logo_url); ?>" style="max-width:180px;height:auto;border:1px solid #ccd0d4;padding:6px;background:#fff;"><?php endif; ?>
                </div>
                <p class="description">Recommended: choose a logo from the WordPress Media Library. URL fallback still works for external/CDN logos.</p>
                <script>
                jQuery(function($){
                    let frame;
                    $('#slabseo_select_logo').on('click', function(e){
                        e.preventDefault();
                        if(frame){ frame.open(); return; }
                        frame = wp.media({ title:'Choose Logo', button:{ text:'Use this logo' }, multiple:false });
                        frame.on('select', function(){
                            const attachment = frame.state().get('selection').first().toJSON();
                            $('#slabseo_logo_id').val(attachment.id || 0);
                            $('#slabseo_logo_url').val(attachment.url || '');
                            $('#slabseo_logo_preview').html('<img src="'+attachment.url+'" style="max-width:180px;height:auto;border:1px solid #ccd0d4;padding:6px;background:#fff;">');
                        });
                        frame.open();
                    });
                    $('#slabseo_remove_logo').on('click', function(e){
                        e.preventDefault();
                        $('#slabseo_logo_id').val('0');
                        $('#slabseo_logo_url').val('');
                        $('#slabseo_logo_preview').empty();
                    });
                });
                </script>
            </td>
        </tr>
        <?php
    }

    private function text_row($label, $key, $o, $desc = '') {
        ?>
        <tr><th scope="row"><label for="slabseo_<?php echo esc_attr($key); ?>"><?php echo esc_html($label); ?></label></th><td><input id="slabseo_<?php echo esc_attr($key); ?>" type="text" class="regular-text" name="<?php echo esc_attr(self::OPTION); ?>[<?php echo esc_attr($key); ?>]" value="<?php echo esc_attr($o[$key] ?? ''); ?>"><?php if ($desc): ?><p class="description"><?php echo esc_html($desc); ?></p><?php endif; ?></td></tr>
        <?php
    }

    private function password_row($label, $key, $o) {
        ?>
        <tr><th scope="row"><label for="slabseo_<?php echo esc_attr($key); ?>"><?php echo esc_html($label); ?></label></th><td><input id="slabseo_<?php echo esc_attr($key); ?>" type="password" class="regular-text" name="<?php echo esc_attr(self::OPTION); ?>[<?php echo esc_attr($key); ?>]" value="<?php echo esc_attr($o[$key] ?? ''); ?>"><p class="description">Stored in WordPress options. Keep server/admin access secure.</p></td></tr>
        <?php
    }

    private function select_row($label, $key, $o, $choices) {
        ?>
        <tr><th scope="row"><label for="slabseo_<?php echo esc_attr($key); ?>"><?php echo esc_html($label); ?></label></th><td><select id="slabseo_<?php echo esc_attr($key); ?>" name="<?php echo esc_attr(self::OPTION); ?>[<?php echo esc_attr($key); ?>]">
            <?php foreach ($choices as $value => $text): ?><option value="<?php echo esc_attr($value); ?>" <?php selected($o[$key] ?? '', $value); ?>><?php echo esc_html($text); ?></option><?php endforeach; ?>
        </select></td></tr>
        <?php
    }

    public function ajax_quick_save_image_seo() {
        check_ajax_referer(self::NONCE_ACTION, 'nonce');
        $attachment_id = absint($_POST['attachment_id'] ?? 0);
        if (!$attachment_id || get_post_type($attachment_id) !== 'attachment' || !wp_attachment_is_image($attachment_id)) {
            wp_send_json_error('Invalid image.');
        }
        if (!current_user_can('edit_post', $attachment_id)) {
            wp_send_json_error('You do not have permission to edit this image.');
        }
        $alt = sanitize_text_field(wp_unslash($_POST['alt'] ?? ''));
        $title = sanitize_text_field(wp_unslash($_POST['title'] ?? ''));
        $caption = sanitize_textarea_field(wp_unslash($_POST['caption'] ?? ''));
        $description = wp_kses_post(wp_unslash($_POST['description'] ?? ''));

        update_post_meta($attachment_id, '_wp_attachment_image_alt', $alt);
        wp_update_post(array(
            'ID' => $attachment_id,
            'post_title' => $title,
            'post_excerpt' => $caption,
            'post_content' => $description,
        ));
        wp_send_json_success(array('attachment_id' => $attachment_id));
    }

    public function ajax_quick_save_post_seo() {
        check_ajax_referer(self::NONCE_ACTION, 'nonce');
        $post_id = absint($_POST['post_id'] ?? 0);
        if (!$post_id || !current_user_can('edit_post', $post_id)) {
            wp_send_json_error('You do not have permission to edit this page.');
        }
        $fields = array(
            '_slabseo_title' => 'seo_title',
            '_slabseo_description' => 'meta_description',
            '_slabseo_pov' => 'pov',
            '_slabseo_schema_about' => 'schema_about',
        );
        foreach ($fields as $meta_key => $post_key) {
            if (isset($_POST[$post_key])) {
                update_post_meta($post_id, $meta_key, sanitize_textarea_field(wp_unslash($_POST[$post_key])));
            }
        }
        wp_send_json_success(array('post_id' => $post_id));
    }

    public function add_meta_boxes() {
        $screens = array('post', 'page');
        foreach ($screens as $screen) {
            add_meta_box('slabseo_meta_box', 'Barnd AI SEO', array($this, 'render_meta_box'), $screen, 'normal', 'high');
        }
    }

    public function render_meta_box($post) {
        wp_nonce_field(self::NONCE_ACTION, self::NONCE_NAME);
        $meta = $this->get_post_seo_meta($post->ID);
        $check = $this->seo_checklist($post);
        ?>
        <style>
            .slabseo-grid{display:grid;grid-template-columns:1fr 1fr;gap:14px}.slabseo-grid textarea,.slabseo-grid input{width:100%}.slabseo-box{background:#fff;border:1px solid #dcdcde;border-radius:8px;padding:12px;margin:10px 0}.slabseo-badge-ok{color:#007017;font-weight:600}.slabseo-badge-warn{color:#b45f06;font-weight:600}.slabseo-actions button{margin-right:8px}.slabseo-small{font-size:12px;color:#646970}
        </style>
        <div class="slabseo-box"><p><strong>Free mode:</strong> edit these SEO fields manually. AI draft tools will belong to Barnd AI SEO Pro later.</p></div>
        <div class="slabseo-grid">
            <p><label><strong>SEO Title</strong><br><input type="text" name="slabseo_title" value="<?php echo esc_attr($meta['title']); ?>" maxlength="70"></label></p>
            <p><label><strong>Meta Description / Google Snippet</strong><br><textarea name="slabseo_description" rows="3" maxlength="170"><?php echo esc_textarea($meta['description']); ?></textarea></label></p>
            <p><label><strong>Open Graph Title</strong><br><input type="text" name="slabseo_og_title" value="<?php echo esc_attr($meta['og_title']); ?>" maxlength="70"></label></p>
            <p><label><strong>Open Graph Description</strong><br><textarea name="slabseo_og_description" rows="3" maxlength="200"><?php echo esc_textarea($meta['og_description']); ?></textarea></label></p>
        </div>
        <p><label><strong>Helpful Angle / Page Notes</strong><br><textarea name="slabseo_pov" rows="3" style="width:100%;"><?php echo esc_textarea($meta['pov']); ?></textarea></label></p>
        <p><label><strong>Schema Description / About</strong><br><textarea name="slabseo_schema_about" rows="3" style="width:100%;"><?php echo esc_textarea($meta['schema_about']); ?></textarea></label></p>
        <p><label><input type="checkbox" name="slabseo_noindex" value="1" <?php checked($meta['noindex'], '1'); ?>> Noindex this page/post</label></p>

        <div class="slabseo-box">
            <h4>Page Cleanup Checklist</h4>
            <ul>
                <?php foreach ($check as $item): ?>
                    <li><span class="<?php echo $item['ok'] ? 'slabseo-badge-ok' : 'slabseo-badge-warn'; ?>"><?php echo $item['ok'] ? '✓' : '!' ; ?></span> <?php echo esc_html($item['label']); ?></li>
                <?php endforeach; ?>
            </ul>
            <p class="slabseo-small">This checklist focuses on helpful content, snippets, images, schema, affiliate safety, and claim warnings. It is not a guarantee of ranking.</p>
        </div>
        <script>
        (function(){
            const ajaxUrl = <?php echo json_encode(admin_url('admin-ajax.php')); ?>;
            const nonce = <?php echo json_encode(wp_create_nonce(self::NONCE_ACTION)); ?>;
            function setStatus(msg){ document.getElementById('slabseo-status').textContent = msg; }
            function fillFields(data){
                const map = {
                    slabseo_title:'seo_title', slabseo_description:'meta_description', slabseo_og_title:'og_title', slabseo_og_description:'og_description', slabseo_pov:'point_of_view', slabseo_schema_about:'schema_about'
                };
                Object.keys(map).forEach(function(name){ const el = document.querySelector('[name="'+name+'"]'); if(el && data[map[name]]) el.value = data[map[name]]; });
            }
            const btn = document.getElementById('slabseo-generate-ai');
            if(btn){ btn.addEventListener('click', function(){
                setStatus('Generating SEO fields...'); btn.disabled = true;
                const fd = new FormData(); fd.append('action','slabseo_generate_post_ai'); fd.append('nonce',nonce); fd.append('post_id',btn.dataset.postId);
                fetch(ajaxUrl,{method:'POST',credentials:'same-origin',body:fd}).then(r=>r.json()).then(j=>{ if(j.success){ fillFields(j.data); setStatus('Generated. Save/update the post to keep changes.'); } else { setStatus(j.data || 'Generation failed.'); } }).catch(()=>setStatus('Request failed.')).finally(()=>btn.disabled=false);
            });}
            const altBtn = document.getElementById('slabseo-generate-alt');
            if(altBtn){ altBtn.addEventListener('click', function(){
                setStatus('Generating ALT text...'); altBtn.disabled = true;
                const fd = new FormData(); fd.append('action','slabseo_generate_image_alt'); fd.append('nonce',nonce); fd.append('post_id',altBtn.dataset.postId);
                fetch(ajaxUrl,{method:'POST',credentials:'same-origin',body:fd}).then(r=>r.json()).then(j=>{ if(j.success){ setStatus('ALT text saved: '+j.data.alt); } else { setStatus(j.data || 'ALT generation failed.'); } }).catch(()=>setStatus('Request failed.')).finally(()=>altBtn.disabled=false);
            });}
        })();
        </script>
        <?php
    }

    private function get_post_seo_meta($post_id) {
        return array(
            'title' => (string)get_post_meta($post_id, '_slabseo_title', true),
            'description' => (string)get_post_meta($post_id, '_slabseo_description', true),
            'og_title' => (string)get_post_meta($post_id, '_slabseo_og_title', true),
            'og_description' => (string)get_post_meta($post_id, '_slabseo_og_description', true),
            'pov' => (string)get_post_meta($post_id, '_slabseo_pov', true),
            'schema_about' => (string)get_post_meta($post_id, '_slabseo_schema_about', true),
            'noindex' => (string)get_post_meta($post_id, '_slabseo_noindex', true),
        );
    }

    public function save_post_meta($post_id, $post) {
        if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) return;
        if (wp_is_post_revision($post_id)) return;
        if (!in_array($post->post_type, array('post','page'), true)) return;
        if (!current_user_can('edit_post', $post_id)) return;

        if (isset($_POST[self::NONCE_NAME]) && wp_verify_nonce(sanitize_text_field(wp_unslash($_POST[self::NONCE_NAME])), self::NONCE_ACTION)) {
            $fields = array(
                '_slabseo_title' => 'slabseo_title',
                '_slabseo_description' => 'slabseo_description',
                '_slabseo_og_title' => 'slabseo_og_title',
                '_slabseo_og_description' => 'slabseo_og_description',
                '_slabseo_pov' => 'slabseo_pov',
                '_slabseo_schema_about' => 'slabseo_schema_about',
            );
            foreach ($fields as $meta_key => $form_key) {
                if (isset($_POST[$form_key])) {
                    update_post_meta($post_id, $meta_key, sanitize_textarea_field(wp_unslash($_POST[$form_key])));
                }
            }
            update_post_meta($post_id, '_slabseo_noindex', isset($_POST['slabseo_noindex']) ? '1' : '0');
        }

        $o = $this->opts();
        if (($o['auto_generate_on_draft'] ?? '0') === '1' && $post->post_status === 'draft') {
            if (!get_post_meta($post_id, '_slabseo_title', true) && !get_post_meta($post_id, '_slabseo_ai_generated_once', true)) {
                update_post_meta($post_id, '_slabseo_ai_generated_once', '1');
                $generated = $this->generate_ai_fields_for_post($post_id);
                if (is_array($generated)) {
                    $this->save_generated_fields($post_id, $generated);
                }
            }
        }
    }

    private function seo_checklist($post) {
        $meta = $this->get_post_seo_meta($post->ID);
        $content = wp_strip_all_tags($post->post_content);
        $featured_id = get_post_thumbnail_id($post->ID);
        $alt = $featured_id ? get_post_meta($featured_id, '_wp_attachment_image_alt', true) : '';
        $affiliate = $this->has_affiliate_links($post->post_content);
        $has_disclosure = (stripos($content, 'affiliate') !== false || stripos($content, 'commission') !== false || stripos($content, 'sponsored') !== false);
        $claim_warning = $this->has_health_claim_language($content);
        $duplicate_hint = $this->title_similarity_warning($post);
        return array(
            array('label' => 'SEO title exists', 'ok' => !empty($meta['title'])),
            array('label' => 'Meta description / snippet exists', 'ok' => !empty($meta['description'])),
            array('label' => 'Featured image exists', 'ok' => !empty($featured_id)),
            array('label' => 'Featured image ALT text exists', 'ok' => !empty($alt)),
            array('label' => 'Helpful angle / page notes exist', 'ok' => !empty($meta['pov'])),
            array('label' => 'Internal link appears in content', 'ok' => preg_match('/href=["\']https?:\/\/[^"\']*' . preg_quote(parse_url(home_url(), PHP_URL_HOST), '/') . '/i', $post->post_content) || preg_match('/href=["\']\//i', $post->post_content)),
            array('label' => 'Affiliate disclosure present when affiliate links are detected', 'ok' => !$affiliate || $has_disclosure),
            array('label' => 'Health/nutrition claim warning clear', 'ok' => !$claim_warning),
            array('label' => 'No obvious duplicate-title warning', 'ok' => !$duplicate_hint),
        );
    }

    private function has_affiliate_links($content) {
        $o = $this->opts();
        $domains = array_filter(array_map('trim', explode(',', $o['affiliate_domains'] ?? '')));
        foreach ($domains as $domain) {
            if ($domain && stripos($content, $domain) !== false) return true;
        }
        return false;
    }

    private function has_health_claim_language($text) {
        $terms = array('cure','treats','treatment','prevent disease','prevents disease','heal','guaranteed results','medical','clinically proven','vitamin','supplement','nutrition','immune','inflammation','blood sugar','weight loss','anxiety','depression','pain relief');
        foreach ($terms as $term) {
            if (stripos($text, $term) !== false) return true;
        }
        return false;
    }

    private function title_similarity_warning($post) {
        $title = strtolower($post->post_title);
        if (strlen($title) < 12) return false;
        $recent = get_posts(array('post_type' => $post->post_type, 'post_status' => array('publish','draft'), 'numberposts' => 20, 'exclude' => array($post->ID)));
        foreach ($recent as $p) {
            similar_text($title, strtolower($p->post_title), $percent);
            if ($percent > 82) return true;
        }
        return false;
    }

    public function ajax_generate_post_ai() {
        if (!current_user_can('edit_posts')) wp_send_json_error('Permission denied.');
        check_ajax_referer(self::NONCE_ACTION, 'nonce');
        $post_id = absint($_POST['post_id'] ?? 0);
        if (!$post_id || !current_user_can('edit_post', $post_id)) wp_send_json_error('Invalid post.');
        $data = $this->generate_ai_fields_for_post($post_id);
        if (is_wp_error($data)) wp_send_json_error($data->get_error_message());
        $this->save_generated_fields($post_id, $data);
        wp_send_json_success($data);
    }

    private function save_generated_fields($post_id, $data) {
        $map = array(
            '_slabseo_title' => 'seo_title',
            '_slabseo_description' => 'meta_description',
            '_slabseo_og_title' => 'og_title',
            '_slabseo_og_description' => 'og_description',
            '_slabseo_pov' => 'point_of_view',
            '_slabseo_schema_about' => 'schema_about',
        );
        foreach ($map as $meta_key => $json_key) {
            if (!empty($data[$json_key])) update_post_meta($post_id, $meta_key, sanitize_textarea_field($data[$json_key]));
        }
        if (!empty($data['image_alt'])) $this->set_featured_image_alt($post_id, $data['image_alt']);
    }

    public function ajax_generate_image_alt() {
        if (!current_user_can('edit_posts')) wp_send_json_error('Permission denied.');
        check_ajax_referer(self::NONCE_ACTION, 'nonce');
        $post_id = absint($_POST['post_id'] ?? 0);
        if (!$post_id || !current_user_can('edit_post', $post_id)) wp_send_json_error('Invalid post.');
        $alt = $this->generate_alt_for_post($post_id);
        if (is_wp_error($alt)) wp_send_json_error($alt->get_error_message());
        $this->set_featured_image_alt($post_id, $alt);
        wp_send_json_success(array('alt' => $alt));
    }

    private function generate_ai_fields_for_post($post_id) {
        return new WP_Error('barndseo_free_no_ai', 'AI generation is not available in Barnd AI SEO Free.');
    }

    private function generate_alt_for_post($post_id) {
        return new WP_Error('barndseo_free_no_ai', 'AI generation is not available in Barnd AI SEO Free.');
    }

    private function call_openai($prompt, $json = true) {
        return new WP_Error('barndseo_free_no_ai', 'AI generation is not available in Barnd AI SEO Free.');
    }

    private function set_featured_image_alt($post_id, $alt) {
        $thumb_id = get_post_thumbnail_id($post_id);
        if ($thumb_id && !get_post_meta($thumb_id, '_wp_attachment_image_alt', true)) {
            update_post_meta($thumb_id, '_wp_attachment_image_alt', sanitize_text_field($alt));
        }
    }


    public function ajax_generate_attachment_image_seo() {
        if (!current_user_can('upload_files')) wp_send_json_error('Permission denied.');
        check_ajax_referer(self::NONCE_ACTION, 'nonce');
        $attachment_id = absint($_POST['attachment_id'] ?? 0);
        $replace = !empty($_POST['replace']);
        if (!$attachment_id || get_post_type($attachment_id) !== 'attachment') wp_send_json_error('Invalid image.');
        if (!wp_attachment_is_image($attachment_id)) wp_send_json_error('Attachment is not an image.');
        $data = $this->generate_attachment_image_seo($attachment_id);
        if (is_wp_error($data)) wp_send_json_error($data->get_error_message());
        $saved = $this->save_attachment_image_seo($attachment_id, $data, $replace);
        wp_send_json_success($saved);
    }

    public function ajax_bulk_generate_attachment_image_seo() {
        if (!current_user_can('upload_files')) wp_send_json_error('Permission denied.');
        check_ajax_referer(self::NONCE_ACTION, 'nonce');
        $ids = isset($_POST['attachment_ids']) ? array_map('absint', (array)$_POST['attachment_ids']) : array();
        $replace = !empty($_POST['replace']);
        $results = array();
        foreach ($ids as $attachment_id) {
            if (!$attachment_id || get_post_type($attachment_id) !== 'attachment' || !wp_attachment_is_image($attachment_id)) continue;
            $data = $this->generate_attachment_image_seo($attachment_id);
            if (is_wp_error($data)) {
                $results[$attachment_id] = array('error' => $data->get_error_message());
                continue;
            }
            $results[$attachment_id] = $this->save_attachment_image_seo($attachment_id, $data, $replace);
        }
        wp_send_json_success($results);
    }

    private function generate_attachment_image_seo($attachment_id) {
        return new WP_Error('barndseo_free_no_ai', 'AI image SEO generation is not available in Barnd AI SEO Free.');
    }

    private function save_attachment_image_seo($attachment_id, $data, $replace = false) {
        $att = get_post($attachment_id);
        $current_alt = (string)get_post_meta($attachment_id, '_wp_attachment_image_alt', true);
        $new = array(
            'alt' => $current_alt,
            'title' => $att ? $att->post_title : '',
            'caption' => $att ? $att->post_excerpt : '',
            'description' => $att ? $att->post_content : '',
        );
        if ($replace || !$current_alt) {
            if (!empty($data['alt'])) {
                update_post_meta($attachment_id, '_wp_attachment_image_alt', sanitize_text_field($data['alt']));
                $new['alt'] = $data['alt'];
            }
        }
        $post_update = array('ID' => $attachment_id);
        $do_update = false;
        if (($replace || empty($new['title'])) && !empty($data['title'])) {
            $post_update['post_title'] = sanitize_text_field($data['title']);
            $new['title'] = $data['title'];
            $do_update = true;
        }
        if (($replace || empty($new['caption'])) && !empty($data['caption'])) {
            $post_update['post_excerpt'] = sanitize_textarea_field($data['caption']);
            $new['caption'] = $data['caption'];
            $do_update = true;
        }
        if (($replace || empty($new['description'])) && !empty($data['description'])) {
            $post_update['post_content'] = sanitize_textarea_field($data['description']);
            $new['description'] = $data['description'];
            $do_update = true;
        }
        if ($do_update) wp_update_post($post_update);
        return $new;
    }

    public function filter_document_title($title) {
        if (is_singular()) {
            $post_id = get_queried_object_id();
            $seo_title = get_post_meta($post_id, '_slabseo_title', true);
            if ($seo_title) return $seo_title;
        }
        return $title;
    }

    public function output_head_tags() {
        $o = $this->opts();
        if (!empty($o['google_verification'])) {
            echo "\n" . '<meta name="google-site-verification" content="' . esc_attr($o['google_verification']) . '">' . "\n";
        }
        if (is_singular()) {
            $post_id = get_queried_object_id();
            $meta = $this->get_post_seo_meta($post_id);
            $title = $meta['title'] ?: get_the_title($post_id) . ' | ' . get_bloginfo('name');
            $description = $meta['description'] ?: $this->fallback_description($post_id);
            $url = get_permalink($post_id);
            $image = get_the_post_thumbnail_url($post_id, 'large');
            if ($meta['noindex'] === '1') echo '<meta name="robots" content="noindex,nofollow">' . "\n";
            echo '<meta name="description" content="' . esc_attr($description) . '">' . "\n";
            echo '<link rel="canonical" href="' . esc_url($url) . '">' . "\n";
            if (($o['enable_social_meta'] ?? '1') === '1') {
                $og_title = $meta['og_title'] ?: $title;
                $og_desc = $meta['og_description'] ?: $description;
                echo '<meta property="og:type" content="article">' . "\n";
                echo '<meta property="og:title" content="' . esc_attr($og_title) . '">' . "\n";
                echo '<meta property="og:description" content="' . esc_attr($og_desc) . '">' . "\n";
                echo '<meta property="og:url" content="' . esc_url($url) . '">' . "\n";
                echo '<meta property="og:site_name" content="' . esc_attr($o['brand_name'] ?? get_bloginfo('name')) . '">' . "\n";
                if ($image) echo '<meta property="og:image" content="' . esc_url($image) . '">' . "\n";
                echo '<meta name="twitter:card" content="summary_large_image">' . "\n";
                echo '<meta name="twitter:title" content="' . esc_attr($og_title) . '">' . "\n";
                echo '<meta name="twitter:description" content="' . esc_attr($og_desc) . '">' . "\n";
                if ($image) echo '<meta name="twitter:image" content="' . esc_url($image) . '">' . "\n";
            }
            if (($o['enable_schema'] ?? '1') === '1') {
                echo $this->schema_script($post_id, $title, $description, $url, $image);
            }
        } else {
            if (($o['enable_schema'] ?? '1') === '1') echo $this->site_schema_script();
        }
    }

    private function fallback_description($post_id) {
        $excerpt = get_the_excerpt($post_id);
        if (!$excerpt) $excerpt = wp_strip_all_tags(get_post_field('post_content', $post_id));
        return mb_substr(trim(preg_replace('/\s+/', ' ', $excerpt)), 0, 160);
    }

    private function schema_script($post_id, $title, $description, $url, $image) {
        $o = $this->opts();
        $schema = array('@context' => 'https://schema.org', '@graph' => array());
        $schema['@graph'][] = $this->organization_schema($o);
        $schema['@graph'][] = array(
            '@type' => 'WebSite',
            '@id' => home_url('/#website'),
            'url' => home_url('/'),
            'name' => $o['brand_name'] ?? get_bloginfo('name'),
            'publisher' => array('@id' => home_url('/#organization')),
        );
        $schema['@graph'][] = array(
            '@type' => is_page($post_id) ? 'WebPage' : 'BlogPosting',
            '@id' => $url . '#webpage',
            'url' => $url,
            'headline' => $title,
            'description' => $description,
            'datePublished' => get_the_date('c', $post_id),
            'dateModified' => get_the_modified_date('c', $post_id),
            'author' => array('@type' => 'Organization', '@id' => home_url('/#organization')),
            'publisher' => array('@id' => home_url('/#organization')),
            'mainEntityOfPage' => $url,
        );
        if ($image) $schema['@graph'][2]['image'] = $image;
        $schema['@graph'][] = $this->breadcrumb_schema($post_id);
        if (in_array($o['site_type'] ?? '', array('restaurant','local_business'), true)) {
            $schema['@graph'][] = $this->local_business_schema($o);
        }
        return "\n<script type=\"application/ld+json\">" . wp_json_encode($schema, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE) . "</script>\n";
    }

    private function site_schema_script() {
        $o = $this->opts();
        $schema = array('@context' => 'https://schema.org', '@graph' => array($this->organization_schema($o), array('@type'=>'WebSite','@id'=>home_url('/#website'),'url'=>home_url('/'),'name'=>$o['brand_name'] ?? get_bloginfo('name'),'publisher'=>array('@id'=>home_url('/#organization')))));
        if (in_array($o['site_type'] ?? '', array('restaurant','local_business'), true)) $schema['@graph'][] = $this->local_business_schema($o);
        return "\n<script type=\"application/ld+json\">" . wp_json_encode($schema, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE) . "</script>\n";
    }

    private function get_logo_url($o) {
        $logo_id = absint($o['logo_id'] ?? 0);
        if ($logo_id) {
            $url = wp_get_attachment_image_url($logo_id, 'full');
            if ($url) return $url;
        }
        return !empty($o['logo_url']) ? esc_url_raw($o['logo_url']) : '';
    }

    private function get_social_urls($o) {
        $keys = array('instagram_url','tiktok_url','facebook_url','pinterest_url','youtube_url','threads_url','x_url','linkedin_url','google_business_profile_url','reddit_url');
        $urls = array();
        foreach ($keys as $key) {
            if (!empty($o[$key])) $urls[] = esc_url_raw($o[$key]);
        }
        $extra = array_filter(array_map('trim', explode("\n", $o['social_profiles'] ?? '')));
        foreach ($extra as $url) {
            if ($url) $urls[] = esc_url_raw($url);
        }
        return array_values(array_unique(array_filter($urls)));
    }

    private function organization_schema($o) {
        $same = $this->get_social_urls($o);
        $org = array(
            '@type' => 'Organization',
            '@id' => home_url('/#organization'),
            'name' => $o['brand_name'] ?? get_bloginfo('name'),
            'legalName' => $o['legal_owner'] ?? 'Site owner',
            'url' => home_url('/'),
        );
        $logo = $this->get_logo_url($o);
        if ($logo) {
            $org['logo'] = $logo;
            $org['image'] = $logo;
        }
        if ($same) $org['sameAs'] = array_values($same);
        return $org;
    }

    private function local_business_schema($o) {
        $type = ($o['site_type'] ?? '') === 'restaurant' ? 'Restaurant' : 'LocalBusiness';
        $lb = array('@type' => $type, '@id' => home_url('/#localbusiness'), 'name' => $o['brand_name'] ?? get_bloginfo('name'), 'url' => home_url('/'));
        $logo = $this->get_logo_url($o);
        if ($logo) $lb['image'] = $logo;
        $same = $this->get_social_urls($o);
        if ($same) $lb['sameAs'] = $same;
        if (!empty($o['business_phone'])) $lb['telephone'] = $o['business_phone'];
        if (!empty($o['business_email'])) $lb['email'] = $o['business_email'];
        if (!empty($o['price_range'])) $lb['priceRange'] = $o['price_range'];
        if (!empty($o['area_served'])) $lb['areaServed'] = array_map('trim', explode(',', $o['area_served']));
        if (!empty($o['menu_url'])) $lb['hasMenu'] = esc_url_raw($o['menu_url']);
        if (!empty($o['order_url'])) $lb['potentialAction'] = array('@type' => 'OrderAction', 'target' => esc_url_raw($o['order_url']));
        if (!empty($o['opening_hours'])) $lb['openingHours'] = array_map('trim', explode(',', $o['opening_hours']));
        if ($type === 'Restaurant' && !empty($o['serves_cuisine'])) $lb['servesCuisine'] = array_map('trim', explode(',', $o['serves_cuisine']));
        if (($o['show_address'] ?? '0') === '1') {
            $lb['address'] = array('@type'=>'PostalAddress','streetAddress'=>$o['street_address'] ?? '', 'addressLocality'=>$o['address_locality'] ?? '', 'addressRegion'=>$o['address_region'] ?? '', 'postalCode'=>$o['postal_code'] ?? '', 'addressCountry'=>$o['address_country'] ?? 'CA');
        }
        if (!empty($o['latitude']) && !empty($o['longitude'])) $lb['geo'] = array('@type'=>'GeoCoordinates','latitude'=>$o['latitude'],'longitude'=>$o['longitude']);
        return $lb;
    }

    private function breadcrumb_schema($post_id) {
        $items = array(array('@type'=>'ListItem','position'=>1,'name'=>'Home','item'=>home_url('/')));
        $cats = get_the_category($post_id);
        if (!empty($cats)) $items[] = array('@type'=>'ListItem','position'=>2,'name'=>$cats[0]->name,'item'=>get_category_link($cats[0]->term_id));
        $items[] = array('@type'=>'ListItem','position'=>count($items)+1,'name'=>get_the_title($post_id),'item'=>get_permalink($post_id));
        return array('@type'=>'BreadcrumbList','@id'=>get_permalink($post_id).'#breadcrumb','itemListElement'=>$items);
    }

    private function get_sitemap_filename() {
        $host = wp_parse_url(home_url('/'), PHP_URL_HOST);
        $host = strtolower((string) $host);
        $host = preg_replace('/^www\./', '', $host);
        $parts = explode('.', $host);
        $slug = !empty($parts[0]) ? sanitize_title($parts[0]) : 'slab';
        if (!$slug) $slug = 'slab';
        return $slug . '-sitemap.xml';
    }

    private function get_sitemap_url() {
        return home_url('/' . $this->get_sitemap_filename());
    }

    public function add_sitemap_rewrite() {
        $filename = $this->get_sitemap_filename();
        add_rewrite_rule('^' . preg_quote($filename, '/') . '$', 'index.php?slabseo_sitemap=1', 'top');
        add_rewrite_rule('^slab-sitemap\.xml$', 'index.php?slabseo_sitemap=1', 'top'); // legacy fallback
    }

    public function query_vars($vars) {
        $vars[] = 'slabseo_sitemap';
        return $vars;
    }

    public function render_sitemap() {
        if (get_query_var('slabseo_sitemap') != '1') return;
        $o = $this->opts();
        if (($o['enable_sitemap'] ?? '1') !== '1') {
            status_header(404); exit;
        }
        header('Content-Type: application/xml; charset=utf-8');
        echo '<?xml version="1.0" encoding="UTF-8"?>' . "\n";
        echo '<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">' . "\n";
        $this->sitemap_url(home_url('/'), current_time('Y-m-d'));
        $posts = get_posts(array('post_type'=>array('post','page'), 'post_status'=>'publish', 'numberposts'=>500, 'orderby'=>'modified', 'order'=>'DESC'));
        foreach ($posts as $p) {
            if (get_post_meta($p->ID, '_slabseo_noindex', true) === '1') continue;
            $this->sitemap_url(get_permalink($p->ID), get_the_modified_date('Y-m-d', $p->ID));
        }
        echo '</urlset>';
        exit;
    }

    private function sitemap_url($loc, $lastmod) {
        echo "  <url>\n";
        echo '    <loc>' . esc_url($loc) . "</loc>\n";
        echo '    <lastmod>' . esc_html($lastmod) . "</lastmod>\n";
        echo "  </url>\n";
    }
}



/**
 * Barnd AI SEO v1.5 add-ons
 * - SEO audit dashboard
 * - FAQ schema helper
 * - Manual visible FAQ page/section helper
 * - llms.txt generator
 * - internal link and duplicate topic checks
 */

add_action('admin_menu', 'slabseo14_admin_menu');
add_action('add_meta_boxes', 'slabseo14_add_faq_box');
add_action('save_post', 'slabseo14_save_faq_meta', 20, 2);
add_action('wp_ajax_slabseo15_insert_faq_html', 'slabseo15_ajax_insert_faq_html');
add_action('init', 'slabseo14_add_llms_rewrite');
add_filter('query_vars', 'slabseo14_query_vars');
add_action('template_redirect', 'slabseo14_render_llms');
add_action('wp_head', 'slabseo14_output_faq_schema', 20);
add_action('wp_head', 'slabseo14_output_llms_link', 25);

function slabseo14_admin_menu() {
    // Free public build uses the top-level Barnd AI SEO menu only.
}

function slabseo14_opts() {
    $defaults = method_exists('Barnd_AI_SEO', 'default_options') ? Barnd_AI_SEO::default_options() : array();
    $opts = get_option(Barnd_AI_SEO::OPTION, array());
    return wp_parse_args(is_array($opts) ? $opts : array(), $defaults);
}

function slabseo14_get_domain_sitemap_url() {
    $host = wp_parse_url(home_url('/'), PHP_URL_HOST);
    $host = strtolower((string)$host);
    $host = preg_replace('/^www\./', '', $host);
    $parts = explode('.', $host);
    $slug = !empty($parts[0]) ? sanitize_title($parts[0]) : 'slab';
    return home_url('/' . $slug . '-sitemap.xml');
}

function slabseo14_audit_page() {
    if (!current_user_can('manage_options')) return;
    $limit = isset($_GET['limit']) ? max(20, min(500, absint($_GET['limit']))) : 200;
    $issue_filter = isset($_GET['issue_filter']) ? sanitize_key($_GET['issue_filter']) : 'all';
    if ($issue_filter === 'health') $issue_filter = 'claims'; // Backward-compatible old filter name.
    $allowed_filters = array('all','missing_title','missing_meta','missing_image','headings','faq','local','media','thin','content','affiliate','claims');
    if (!in_array($issue_filter, $allowed_filters, true)) $issue_filter = 'all';

    $posts = get_posts(array(
        'post_type' => array('post','page'),
        'post_status' => array('publish','draft','future'),
        'numberposts' => $limit,
        'orderby' => 'modified',
        'order' => 'DESC',
    ));
    $all_rows = slabseo14_build_audit_rows($posts);

    $filter_match = function($r) use ($issue_filter) {
        return slabseo21_audit_filter_matches($r, $issue_filter);
    };
    $rows = array_values(array_filter($all_rows, $filter_match));

    $counts = array('total'=>count($all_rows),'shown'=>count($rows),'critical'=>0,'warning'=>0,'good'=>0);
    foreach ($all_rows as $r) {
        if ($r['score'] < 60) $counts['critical']++;
        elseif ($r['score'] < 85) $counts['warning']++;
        else $counts['good']++;
    }
    $filter_labels = slabseo21_audit_filter_labels();
    $filter_help = slabseo21_audit_filter_help();
    $filter_empty = slabseo21_audit_empty_messages();
    $filter_counts = array();
    foreach ($filter_labels as $key => $label) {
        $filter_counts[$key] = count(array_filter($all_rows, function($r) use ($key) { return slabseo21_audit_filter_matches($r, $key); }));
    }
    ?>
    <div class="wrap">
        <h1>Barnd AI SEO Audit &amp; Quick Fixes</h1>
        <p>Find common SEO cleanup issues. Metadata gaps can be saved here. Content-structure items such as FAQ ideas, local proof, media support, and thin/generic content are shown as next-action guidance because they need real page edits, not another meta field.</p>
        <div style="display:grid;grid-template-columns:repeat(4,minmax(140px,1fr));gap:12px;max-width:900px;margin:18px 0;">
            <div class="card"><h2><?php echo esc_html($counts['total']); ?></h2><p>Pages scanned</p></div>
            <div class="card"><h2 style="color:#b32d2e;"><?php echo esc_html($counts['critical']); ?></h2><p>Need work</p></div>
            <div class="card"><h2 style="color:#b45f06;"><?php echo esc_html($counts['warning']); ?></h2><p>Warnings</p></div>
            <div class="card"><h2 style="color:#007017;"><?php echo esc_html($counts['good']); ?></h2><p>Good</p></div>
        </div>
        <p>
            <a class="button" href="<?php echo esc_url(admin_url('admin.php?page=slabseo-audit&limit=50&issue_filter=' . $issue_filter)); ?>">Scan 50</a>
            <a class="button" href="<?php echo esc_url(admin_url('admin.php?page=slabseo-audit&limit=200&issue_filter=' . $issue_filter)); ?>">Scan 200</a>
            <a class="button" href="<?php echo esc_url(admin_url('admin.php?page=slabseo-audit&limit=500&issue_filter=' . $issue_filter)); ?>">Scan 500</a>
            <a class="button button-primary" href="<?php echo esc_url(admin_url('admin.php?page=slabseo-audit&limit=' . $limit . '&issue_filter=' . $issue_filter)); ?>">Re-run Audit</a>
        </p>
        <div class="barndseo-filter-bar">
            <strong>Show:</strong>
            <?php foreach ($filter_labels as $key => $label): ?>
                <a class="button button-small <?php echo $issue_filter === $key ? 'button-primary' : ''; ?>" href="<?php echo esc_url(admin_url('admin.php?page=slabseo-audit&limit=' . $limit . '&issue_filter=' . $key)); ?>"><?php echo esc_html($label); ?> <span class="barndseo-filter-count"><?php echo esc_html($filter_counts[$key] ?? 0); ?></span></a>
            <?php endforeach; ?>
        </div>
        <p><strong>Showing:</strong> <?php echo esc_html($counts['shown']); ?> of <?php echo esc_html($counts['total']); ?> scanned items. &nbsp; <strong>LLMs.txt:</strong> <a href="<?php echo esc_url(home_url('/llms.txt')); ?>" target="_blank"><?php echo esc_html(home_url('/llms.txt')); ?></a> &nbsp; <strong>Sitemap:</strong> <a href="<?php echo esc_url(slabseo14_get_domain_sitemap_url()); ?>" target="_blank"><?php echo esc_html(slabseo14_get_domain_sitemap_url()); ?></a></p>
        <div class="barndseo-ai-readiness-card">
            <strong><?php echo esc_html($filter_labels[$issue_filter] ?? 'All issues'); ?>:</strong> <?php echo esc_html($filter_help[$issue_filter] ?? $filter_help['all']); ?>
        </div>
        <div class="barndseo-ai-readiness-card barndseo-ai-readiness-card-soft">
            <strong>AI Search readiness note:</strong> Metadata fields and content fixes are different jobs. Titles/descriptions can be quick-saved here. FAQ/checklist, local proof, image/video support, and thin/generic content warnings point you to the page editor, local setup, or Image SEO tool.
        </div>
        <div id="barndseo-audit-status" class="notice notice-success" style="display:none;"><p></p></div>
        <style>
            .barndseo-filter-bar{background:#fff;border:1px solid #dcdcde;border-radius:8px;padding:10px 12px;margin:12px 0;display:flex;gap:8px;align-items:center;flex-wrap:wrap;}.barndseo-ai-readiness-card{background:#fff;border-left:4px solid #2271b1;border-top:1px solid #dcdcde;border-right:1px solid #dcdcde;border-bottom:1px solid #dcdcde;border-radius:6px;padding:12px 14px;margin:12px 0;max-width:1100px;}.barndseo-ai-readiness-card-soft{border-left-color:#72aee6;background:#f6f7f7}.barndseo-filter-count{display:inline-block;margin-left:4px;border-radius:999px;background:#f0f0f1;color:#1d2327;padding:0 6px;font-size:11px;line-height:18px;}
            #barndseo-audit-table{table-layout:fixed;}
            #barndseo-audit-table th:nth-child(1){width:50px;}
            #barndseo-audit-table th:nth-child(2){width:13%;}
            #barndseo-audit-table th:nth-child(3){width:35%;}
            #barndseo-audit-table th:nth-child(4){width:40%;}
            #barndseo-audit-table th:nth-child(5){width:125px;}
            #barndseo-audit-table td{vertical-align:top;}
            #barndseo-audit-table ul{margin:0 0 0 16px;}
            #barndseo-audit-table input[type="text"]{width:100%;height:30px;max-width:none;}
            #barndseo-audit-table textarea{width:100%;height:44px;min-height:44px;max-width:none;resize:vertical;}
            #barndseo-audit-table .barndseo-qf-field{margin:6px 0 0;}
            #barndseo-audit-table .barndseo-qf-field:first-child{margin-top:0;}
            #barndseo-audit-table .barndseo-qf-field strong{font-size:12px;}
            #barndseo-audit-table .barndseo-page-meta{color:#646970;font-size:12px;}
            #barndseo-audit-table .barndseo-guidance-box{background:#f6f7f7;border:1px solid #dcdcde;border-left:4px solid #72aee6;border-radius:6px;padding:9px 10px;margin:0 0 8px;}
            #barndseo-audit-table .barndseo-guidance-box strong{display:block;margin-bottom:3px;}
            #barndseo-audit-table .barndseo-guidance-box p{margin:0;color:#3c434a;font-size:12px;line-height:1.45;}
            #barndseo-audit-table .barndseo-meta-tools{border-top:1px solid #dcdcde;margin-top:10px;padding-top:8px;}
            #barndseo-audit-table .barndseo-row-action .button{width:100%;text-align:center;margin-bottom:8px;}
            .barndseo-row-saved{display:none;color:#007017;font-weight:600;font-size:12px;margin-top:2px;}
        </style>
        <table class="widefat striped" id="barndseo-audit-table">
            <thead><tr><th>Score</th><th>Page/Post</th><th>Issues</th><th>Fix Action</th><th>Action</th></tr></thead>
            <tbody>
                <?php if (empty($rows)): ?>
                    <tr><td colspan="5"><strong><?php echo esc_html($filter_empty[$issue_filter] ?? 'No pages matched this filter.'); ?></strong><br><span class="barndseo-page-meta"><?php echo esc_html($filter_help[$issue_filter] ?? $filter_help['all']); ?></span><br><a class="button button-small" style="margin-top:8px;" href="<?php echo esc_url(admin_url('admin.php?page=slabseo-audit&limit=' . $limit . '&issue_filter=all')); ?>">Show all issues</a></td></tr>
                <?php endif; ?>
                <?php foreach ($rows as $r): ?>
                    <tr data-post-id="<?php echo esc_attr($r['id']); ?>">
                        <td><strong style="color:<?php echo $r['score'] < 60 ? '#b32d2e' : ($r['score'] < 85 ? '#b45f06' : '#007017'); ?>"><?php echo esc_html($r['score']); ?></strong></td>
                        <td><strong><?php echo esc_html($r['title']); ?></strong><br><span class="barndseo-page-meta"><?php echo esc_html($r['type']); ?> · <?php echo esc_html($r['status']); ?></span><br><a href="<?php echo esc_url($r['url']); ?>" target="_blank">View</a></td>
                        <td><?php echo $r['issues'] ? '<ul><li>' . implode('</li><li>', array_map('esc_html', $r['issues'])) . '</li></ul>' : '<span style="color:#007017;font-weight:600;">No major issues found</span>'; ?><?php echo $r['links'] ? '<p><strong>Internal link idea:</strong><br>' . esc_html(implode('; ', $r['links'])) . '</p>' : ''; ?></td>
                        <td>
                            <?php $has_quick_fields = false; ?>
                            <?php $is_guidance_filter = slabseo23_is_content_guidance_filter($issue_filter); ?>
                            <?php $guidance_items = slabseo23_audit_guidance_items($r, $issue_filter); ?>
                            <?php if (!empty($guidance_items)): ?>
                                <?php foreach ($guidance_items as $g): ?>
                                    <div class="barndseo-guidance-box"><strong><?php echo esc_html($g['title']); ?></strong><p><?php echo esc_html($g['body']); ?></p></div>
                                <?php endforeach; ?>
                            <?php endif; ?>
                            <?php if (!$is_guidance_filter): ?>
                                <div class="barndseo-meta-tools">
                                <?php if (trim((string)$r['seo_title']) === ''): $has_quick_fields = true; ?>
                                    <div class="barndseo-qf-field"><label><strong>SEO Title</strong><br><input type="text" class="regular-text barndseo-qf-title" value="" maxlength="70" placeholder="Clear page title for search results"></label></div>
                                <?php endif; ?>
                                <?php if (trim((string)$r['seo_desc']) === ''): $has_quick_fields = true; ?>
                                    <div class="barndseo-qf-field"><label><strong>Meta Description / Google Snippet</strong><br><textarea class="large-text barndseo-qf-description" rows="2" maxlength="170" placeholder="One or two lines that explain why someone should click this page"></textarea></label></div>
                                <?php endif; ?>
                                <?php if (trim((string)$r['pov']) === ''): $has_quick_fields = true; ?>
                                    <div class="barndseo-qf-field"><label><strong>Helpful Angle / Page Notes</strong><br><textarea class="large-text barndseo-qf-pov" rows="2" placeholder="What problem does this page help the visitor solve?"></textarea></label></div>
                                <?php endif; ?>
                                <?php if (trim((string)$r['schema_about']) === ''): $has_quick_fields = true; ?>
                                    <div class="barndseo-qf-field"><label><strong>Schema Description / About</strong><br><textarea class="large-text barndseo-qf-schema" rows="2" placeholder="Short factual description of what this page is about"></textarea></label></div>
                                <?php endif; ?>
                                <?php if (!$has_quick_fields): ?>
                                    <span class="barndseo-page-meta">No blank metadata quick-fix fields. Use Edit for deeper page changes.</span>
                                <?php endif; ?>
                                </div>
                            <?php else: ?>
                                <span class="barndseo-page-meta">This filter is content guidance, not a metadata slot. Open the editor or related tool to make the real fix.</span>
                            <?php endif; ?>
                        </td>
                        <td class="barndseo-row-action"><?php if (!$is_guidance_filter && $has_quick_fields): ?><button type="button" class="button button-primary barndseo-save-audit-row" data-id="<?php echo esc_attr($r['id']); ?>">Save Quick Fixes</button><div class="barndseo-row-saved">Saved</div><?php endif; ?><a class="button" href="<?php echo esc_url(get_edit_post_link($r['id'])); ?>">Edit Page</a><?php if ($issue_filter === 'local'): ?><a class="button" href="<?php echo esc_url(admin_url('admin.php?page=slabseo-wizard')); ?>">Local Setup</a><?php endif; ?><?php if ($issue_filter === 'media'): ?><a class="button" href="<?php echo esc_url(admin_url('admin.php?page=slabseo-image-seo')); ?>">Image SEO</a><?php endif; ?></td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
        <script>
        (function($){
            const ajaxUrl = <?php echo wp_json_encode(admin_url('admin-ajax.php')); ?>;
            const nonce = <?php echo wp_json_encode(wp_create_nonce(Barnd_AI_SEO::NONCE_ACTION)); ?>;
            function showStatus(message, ok){
                const box = $('#barndseo-audit-status');
                box.removeClass('notice-success notice-error').addClass(ok ? 'notice-success' : 'notice-error');
                box.find('p').html(message);
                box.show();
                window.scrollTo({top: box.offset().top - 50, behavior: 'smooth'});
            }
            $('.barndseo-save-audit-row').on('click', function(){
                const btn = $(this);
                const row = btn.closest('tr');
                btn.prop('disabled', true).text('Saving...');
                $.post(ajaxUrl, {
                    action: 'barndseo_quick_save_post_seo',
                    nonce: nonce,
                    post_id: btn.data('id'),
                    seo_title: row.find('.barndseo-qf-title').length ? row.find('.barndseo-qf-title').val() : undefined,
                    meta_description: row.find('.barndseo-qf-description').length ? row.find('.barndseo-qf-description').val() : undefined,
                    pov: row.find('.barndseo-qf-pov').length ? row.find('.barndseo-qf-pov').val() : undefined,
                    schema_about: row.find('.barndseo-qf-schema').length ? row.find('.barndseo-qf-schema').val() : undefined
                }).done(function(resp){
                    if(resp && resp.success){
                        row.find('.barndseo-row-saved').show();
                        showStatus('Quick fixes saved. <a href="' + window.location.href + '">Re-run audit</a> to refresh the score and hide completed fields.', true);
                    } else {
                        showStatus((resp && resp.data) ? resp.data : 'Save failed.', false);
                    }
                }).fail(function(){
                    showStatus('Request failed.', false);
                }).always(function(){
                    btn.prop('disabled', false).text('Save Quick Fixes');
                });
            });
        })(jQuery);
        </script>
    </div>
    <?php
}


function slabseo21_audit_filter_labels() {
    return array(
        'all' => 'All issues',
        'missing_title' => 'Missing titles',
        'missing_meta' => 'Missing descriptions',
        'missing_image' => 'Image / ALT issues',
        'headings' => 'H1/H2 issues',
        'faq' => 'FAQ / checklist ideas',
        'local' => 'Local proof',
        'media' => 'Image/video support',
        'thin' => 'Thin/generic content',
        'content' => 'All content cleanup',
        'affiliate' => 'Affiliate disclosure',
        'claims' => 'Claim warnings',
    );
}

function slabseo21_audit_filter_help() {
    return array(
        'all' => 'Shows every scanned page/post and the cleanup items Barnd found.',
        'missing_title' => 'Finds pages with a blank Barnd SEO title. A clear title helps searchers understand the page before clicking.',
        'missing_meta' => 'Finds pages with a blank Google preview description. Write one or two useful lines that explain why the page is worth visiting.',
        'missing_image' => 'Finds missing featured images or missing image ALT text. ALT text should describe what the image shows when it is useful to the page.',
        'headings' => 'Pinpoints missing or confusing H1/H2 structure, including multiple H1s, empty headings, generic H2s, and heading order issues.',
        'faq' => 'Suggests where a visible FAQ or checklist may help. Use real answers only; do not invent guarantees, reviews, or unsupported claims.',
        'local' => 'Checks for real local proof such as address/service area, phone, hours, Google Maps/Business Profile, menu/order/contact links, nearby landmarks, pickup/delivery notes, or original photos.',
        'media' => 'Reminds you when important pages lack useful image/video support, missing ALT text, captions, or a short text summary near embedded video.',
        'thin' => 'Finds pages that may be too short or too generic. Add specific details, examples, local proof, product/service details, FAQ, images, or buyer/customer guidance.',
        'content' => 'Groups structure and usefulness checks: headings, internal links, helpful angle, FAQ/checklist ideas, thin/generic wording, and media support.',
        'affiliate' => 'Finds affiliate links without disclosure wording. Add clear disclosure before sending users to retailers or partners.',
        'claims' => 'Checks for sensitive claim wording such as health, nutrition, medical, earning, guarantee, fake review, or unsupported best/guaranteed language.',
    );
}

function slabseo21_audit_empty_messages() {
    return array(
        'all' => 'No pages were scanned yet.',
        'missing_title' => 'No missing SEO titles found in the scanned pages.',
        'missing_meta' => 'No missing Google preview descriptions found in the scanned pages.',
        'missing_image' => 'No missing featured image or image ALT issues found in the scanned pages.',
        'headings' => 'No H1/H2 structure issues found in the scanned pages.',
        'faq' => 'No FAQ/checklist suggestions found for the scanned pages.',
        'local' => 'No local proof gaps found for the scanned pages.',
        'media' => 'No image/video support reminders found in the scanned pages.',
        'thin' => 'No thin or generic content warnings found in the scanned pages.',
        'content' => 'No content cleanup warnings found in the scanned pages.',
        'affiliate' => 'No affiliate disclosure warnings found in the scanned pages.',
        'claims' => 'No claim warnings found in the scanned pages.',
    );
}

function slabseo21_audit_filter_matches($r, $filter) {
    if ($filter === 'health') $filter = 'claims';
    if ($filter === 'all') return true;
    $hay = strtolower(implode(' ', (array)($r['issues'] ?? array())));
    if ($filter === 'missing_title') return trim((string)($r['seo_title'] ?? '')) === '';
    if ($filter === 'missing_meta') return trim((string)($r['seo_desc'] ?? '')) === '';
    if ($filter === 'missing_image') return (strpos($hay, 'featured image') !== false || strpos($hay, 'alt text') !== false || strpos($hay, 'alt attribute') !== false);
    if ($filter === 'headings') return (strpos($hay, 'h1') !== false || strpos($hay, 'h2') !== false || strpos($hay, 'heading') !== false);
    if ($filter === 'faq') return (strpos($hay, 'faq') !== false || strpos($hay, 'checklist') !== false || strpos($hay, 'questions') !== false);
    if ($filter === 'local') return (strpos($hay, 'local') !== false || strpos($hay, 'google business') !== false || strpos($hay, 'restaurant') !== false || strpos($hay, 'address') !== false || strpos($hay, 'menu') !== false || strpos($hay, 'order') !== false || strpos($hay, 'pickup') !== false || strpos($hay, 'delivery') !== false);
    if ($filter === 'media') return (strpos($hay, 'image') !== false || strpos($hay, 'video') !== false || strpos($hay, 'media') !== false || strpos($hay, 'alt') !== false || strpos($hay, 'caption') !== false);
    if ($filter === 'thin') return (strpos($hay, 'thin') !== false || strpos($hay, 'generic') !== false || strpos($hay, 'commodity') !== false);
    if ($filter === 'content') return (strpos($hay, 'thin') !== false || strpos($hay, 'generic') !== false || strpos($hay, 'commodity') !== false || strpos($hay, 'internal link') !== false || strpos($hay, 'helpful angle') !== false || strpos($hay, 'heading') !== false || strpos($hay, 'faq') !== false || strpos($hay, 'checklist') !== false || strpos($hay, 'image/video') !== false || strpos($hay, 'media') !== false);
    if ($filter === 'affiliate') return (strpos($hay, 'affiliate') !== false || strpos($hay, 'disclosure') !== false);
    if ($filter === 'claims') return (strpos($hay, 'health') !== false || strpos($hay, 'medical') !== false || strpos($hay, 'nutrition') !== false || strpos($hay, 'claim') !== false || strpos($hay, 'guarantee') !== false || strpos($hay, 'guaranteed') !== false || strpos($hay, 'earning') !== false || strpos($hay, 'review') !== false || strpos($hay, 'rating') !== false);
    return true;
}


function slabseo23_is_content_guidance_filter($filter) {
    return in_array($filter, array('headings','faq','local','media','thin','content'), true);
}

function slabseo23_issue_contains_any($issues, $needles) {
    $hay = strtolower(implode(' ', array_map('strval', (array)$issues)));
    foreach ((array)$needles as $needle) {
        if (strpos($hay, strtolower((string)$needle)) !== false) return true;
    }
    return false;
}

function slabseo23_audit_guidance_items($r, $filter) {
    $issues = isset($r['issues']) && is_array($r['issues']) ? $r['issues'] : array();
    $items = array();
    $add = function($title, $body) use (&$items) {
        $key = strtolower($title . '|' . $body);
        foreach ($items as $existing) {
            if (strtolower($existing['title'] . '|' . $existing['body']) === $key) return;
        }
        $items[] = array('title' => $title, 'body' => $body);
    };

    if (($filter === 'headings' || $filter === 'content' || $filter === 'all') && slabseo23_issue_contains_any($issues, array('heading', 'h1', 'h2', 'h3'))) {
        $add('Heading structure fix', 'Open the page editor and fix the actual heading blocks. Keep one clear H1, use H2 for main sections, avoid empty headings, and replace vague headings like “More Info” with specific section names.');
    }
    if (($filter === 'faq' || $filter === 'content' || $filter === 'all') && slabseo23_issue_contains_any($issues, array('faq', 'checklist', 'questions'))) {
        $add('FAQ / checklist content fix', 'This cannot be filled by a generic SEO field. Add a visible FAQ or checklist inside the page with real answers only. After the FAQ is visible, use the FAQ helper/schema option if appropriate.');
    }
    if (($filter === 'local' || $filter === 'content' || $filter === 'all') && slabseo23_issue_contains_any($issues, array('local proof', 'address', 'phone', 'hours', 'google maps', 'business profile', 'menu link', 'order link', 'pickup', 'delivery'))) {
        $add('Local proof/details fix', 'Add real business proof: address or service area, phone, hours, map/Google Business Profile link, menu/order/contact links, nearby landmarks, pickup/delivery notes, and original location/product photos. Use Local Setup for global business fields.');
    }
    if (($filter === 'media' || $filter === 'content' || $filter === 'all') && slabseo23_issue_contains_any($issues, array('image', 'video', 'media', 'alt', 'caption'))) {
        $add('Image/video support fix', 'Use real supporting media where it helps the visitor. Add descriptive ALT text, useful captions, filenames that make sense, and short text near embedded videos explaining what the video covers.');
    }
    if (($filter === 'thin' || $filter === 'content' || $filter === 'all') && slabseo23_issue_contains_any($issues, array('thin', 'generic', 'commodity'))) {
        $add('Thin/generic content fix', 'Rewrite the page content with specific details, real examples, product/service facts, local proof, original photos, buyer/customer guidance, and helpful sections. A meta description alone will not fix this warning.');
    }
    return $items;
}


function slabseo14_build_audit_rows($posts) {
    $titles = array();
    foreach ($posts as $p) {
        $key = strtolower(trim(preg_replace('/\s+/', ' ', $p->post_title)));
        if (!isset($titles[$key])) $titles[$key] = 0;
        $titles[$key]++;
    }
    $rows = array();
    foreach ($posts as $post) {
        if (function_exists('slabseo22_is_ignored') && slabseo22_is_ignored($post->ID)) continue;
        $low_priority = slabseo25_is_low_priority_page($post);
        $issues = array();
        $score = 100;
        $content_raw = (string)$post->post_content;
        $content = wp_strip_all_tags($content_raw);
        $seo_title = (string)get_post_meta($post->ID, '_slabseo_title', true);
        $seo_desc = (string)get_post_meta($post->ID, '_slabseo_description', true);
        $pov = (string)get_post_meta($post->ID, '_slabseo_pov', true);
        $schema_about = (string)get_post_meta($post->ID, '_slabseo_schema_about', true);
        $noindex = (string)get_post_meta($post->ID, '_slabseo_noindex', true);
        $thumb_id = get_post_thumbnail_id($post->ID);
        $alt = $thumb_id ? (string)get_post_meta($thumb_id, '_wp_attachment_image_alt', true) : '';
        if (!$seo_title) { $issues[] = 'Missing Barnd AI SEO title.'; $score -= 12; }
        if (!$seo_desc) { $issues[] = 'Missing meta description / Google snippet.'; $score -= 12; }
        if (!$pov && !$low_priority) { $issues[] = 'Missing helpful angle / page notes.'; $score -= 10; }
        if (!$schema_about && !$low_priority) { $issues[] = 'Missing schema description / about field.'; $score -= 6; }
        if (!$thumb_id && !$low_priority && $post->post_type === 'post') { $issues[] = 'Missing featured image.'; $score -= 8; }
        elseif ($thumb_id && !$alt) { $issues[] = 'Featured image is missing ALT text.'; $score -= 8; }
        $word_count = str_word_count($content);
        foreach (slabseo20_heading_issues($content_raw, $word_count) as $heading_issue) { $issues[] = $heading_issue; $score -= 4; }
        if (!$low_priority) {
            foreach (slabseo20_content_support_issues($post, $content_raw, $content, $word_count) as $support_issue) { $issues[] = $support_issue; $score -= 5; }
        }
        if (str_word_count($content) < 250 && $post->post_type === 'post') { $issues[] = 'Thin content warning: page has fewer than 250 words. Add real examples, buyer questions, local details, or source-backed facts.'; $score -= 10; }
        if (!$low_priority && !slabseo14_has_internal_link($content_raw)) { $issues[] = 'No internal link found.'; $score -= 10; }
        if (slabseo14_has_affiliate_links($content_raw) && !slabseo14_has_affiliate_disclosure($content)) { $issues[] = 'Affiliate link detected but disclosure wording is missing.'; $score -= 14; }
        if (slabseo14_has_health_claim_language($content)) { $issues[] = 'Health/nutrition/medical claim language detected. Review sources before publishing.'; $score -= 12; }
        $key = strtolower(trim(preg_replace('/\s+/', ' ', $post->post_title)));
        if (!empty($titles[$key]) && $titles[$key] > 1) { $issues[] = 'Duplicate exact title found.'; $score -= 10; }
        if ($noindex === '1') { $issues[] = 'This page is set to noindex.'; $score -= 5; }
        $rows[] = array(
            'id' => $post->ID,
            'title' => get_the_title($post),
            'type' => $post->post_type,
            'status' => $post->post_status,
            'url' => get_permalink($post),
            'issues' => $issues,
            'links' => slabseo14_internal_link_suggestions($post),
            'score' => max(0, min(100, $score)),
            'seo_title' => $seo_title,
            'seo_desc' => $seo_desc,
            'pov' => $pov,
            'schema_about' => $schema_about,
        );
    }
    usort($rows, function($a, $b) { return $a['score'] <=> $b['score']; });
    return $rows;
}

function slabseo25_is_low_priority_page($post) {
    if (!$post || $post->post_type !== 'page') return false;
    $slug = strtolower((string)$post->post_name);
    $title = strtolower((string)$post->post_title);
    $haystack = $slug . ' ' . $title;
    $needles = array(
        'privacy', 'privacy-policy', 'terms', 'terms-of-service', 'legal', 'disclaimer',
        'cookie', 'cart', 'checkout', 'my-account', 'account', 'contact', 'hello-world'
    );
    foreach ($needles as $needle) {
        if (strpos($haystack, $needle) !== false) return true;
    }
    return false;
}


function slabseo20_extract_headings($content_raw) {
    $headings = array();
    if (preg_match_all('/<h([1-6])[^>]*>(.*?)<\/h\1>/is', (string)$content_raw, $matches, PREG_SET_ORDER)) {
        foreach ($matches as $m) {
            $text = trim(wp_strip_all_tags($m[2]));
            $text = preg_replace('/\s+/', ' ', $text);
            $headings[] = array('level' => absint($m[1]), 'text' => $text);
        }
    }
    return $headings;
}

function slabseo20_heading_issues($content_raw, $word_count) {
    $issues = array();
    $headings = slabseo20_extract_headings($content_raw);
    $h1s = array_values(array_filter($headings, function($h) { return (int)$h['level'] === 1; }));
    $h2s = array_values(array_filter($headings, function($h) { return (int)$h['level'] === 2; }));
    if (count($h1s) > 1) {
        $names = array_slice(array_map(function($h) { return $h['text'] !== '' ? '“' . $h['text'] . '”' : '(empty H1)'; }, $h1s), 0, 4);
        $issues[] = 'Heading issue: multiple H1s found in page content: ' . implode(', ', $names) . '. Keep one main H1; use H2 for sections.';
    }
    foreach ($headings as $idx => $h) {
        if ($h['text'] === '') $issues[] = 'Heading issue: empty H' . (int)$h['level'] . ' found near heading #' . ($idx + 1) . '.';
    }
    $generic = array('more info','learn more','welcome','our services','services','about','overview','details','information');
    foreach ($h2s as $h) {
        $t = strtolower(trim($h['text']));
        if (in_array($t, $generic, true)) {
            $issues[] = 'H2 may be too generic: “' . $h['text'] . '”. Use a clearer section heading that explains the topic.';
        }
    }
    if ($word_count >= 400 && count($h2s) === 0) {
        $issues[] = 'Heading issue: long page has no H2 sections. Add H2s for menu/services, location, buyer questions, FAQ, or checklist sections.';
    }
    $seen_h2 = false;
    foreach ($headings as $h) {
        if ((int)$h['level'] === 2) $seen_h2 = true;
        if (!$seen_h2 && (int)$h['level'] >= 3) {
            $issues[] = 'Heading order issue: H' . (int)$h['level'] . ' appears before the first H2. Add an H2 parent section first.';
            break;
        }
    }
    return array_values(array_unique($issues));
}

function slabseo20_content_support_issues($post, $content_raw, $content, $word_count) {
    $issues = array();
    $lower = strtolower((string)$content);
    $raw_lower = strtolower((string)$content_raw);
    $opts = slabseo14_opts();
    $site_type = sanitize_key($opts['site_type'] ?? '');

    $has_faq = (strpos($lower, 'faq') !== false || strpos($lower, 'frequently asked') !== false || strpos($lower, 'question') !== false || strpos($raw_lower, 'wp:yoast/faq-block') !== false);
    $has_checklist = (strpos($lower, 'checklist') !== false || strpos($lower, 'what to check') !== false || strpos($lower, 'before you buy') !== false || strpos($lower, 'before ordering') !== false);
    if ($word_count >= 300 && !$has_faq && !$has_checklist) {
        if (in_array($site_type, array('restaurant','local_business'), true)) {
            $issues[] = 'FAQ/checklist idea: add real questions such as hours, pickup/delivery, location, menu/order link, parking/access, or service area.';
        } elseif ($site_type === 'publisher_review') {
            $issues[] = 'FAQ/checklist idea: add buyer checks such as who it is for, what problem it solves, limits/drawbacks, source details, and return policy reminders.';
        } else {
            $issues[] = 'FAQ/checklist idea: add a visible FAQ or checklist with real answers. Do not invent claims, reviews, or guarantees.';
        }
    }

    if (in_array($site_type, array('restaurant','local_business'), true)) {
        $local_needles = array('address','street','phone','hours','open','google maps','map','menu','order','pickup','delivery','near','located','parking');
        $hits = 0;
        foreach ($local_needles as $needle) if (strpos($lower, $needle) !== false) $hits++;
        if ($hits < 3) {
            $missing = array();
            if (empty($opts['business_phone']) && strpos($lower, 'phone') === false) $missing[] = 'phone';
            if (empty($opts['opening_hours']) && strpos($lower, 'hours') === false && strpos($lower, 'open') === false) $missing[] = 'hours';
            if (empty($opts['google_business_profile_url']) && strpos($lower, 'google maps') === false && strpos($lower, 'map') === false) $missing[] = 'Google Maps/Business Profile';
            if ($site_type === 'restaurant' && empty($opts['menu_url']) && strpos($lower, 'menu') === false) $missing[] = 'menu link';
            if ($site_type === 'restaurant' && empty($opts['order_url']) && strpos($lower, 'order') === false) $missing[] = 'order link';
            $issues[] = 'Local proof/details checklist: add real location details such as address/service area, phone, hours, map link, menu/order/contact link, nearby landmark, pickup/delivery notes, or original photos' . ($missing ? '. Missing signals: ' . implode(', ', $missing) : '') . '.';
        }
    }

    $image_count = preg_match_all('/<img\b/i', (string)$content_raw, $tmp);
    $video_present = (strpos($raw_lower, '<video') !== false || strpos($raw_lower, 'youtube.com') !== false || strpos($raw_lower, 'youtu.be') !== false || strpos($raw_lower, 'vimeo.com') !== false || strpos($raw_lower, 'wp:embed') !== false || strpos($raw_lower, 'wp:video') !== false);
    if ($word_count >= 350 && !$image_count && !has_post_thumbnail($post->ID)) {
        $issues[] = 'Image/video support reminder: important pages should include useful original images or video when helpful. Add descriptive ALT text and place media near related text.';
    } elseif ($image_count > 0 && strpos($raw_lower, 'alt=') === false) {
        $issues[] = 'Image support issue: page contains images but no visible ALT attributes in the content. Add descriptive ALT text where relevant.';
    }
    if ($video_present && (strpos($lower, 'transcript') === false && strpos($lower, 'video') === false)) {
        $issues[] = 'Video support reminder: add a clear video title/description or short text summary near the video so visitors and search engines understand it.';
    }

    $generic_phrases = array('high quality', 'affordable prices', 'customer satisfaction', 'best service', 'one stop shop', 'we care about our customers', 'professional team', 'top notch');
    $generic_hits = 0;
    foreach ($generic_phrases as $phrase) if (strpos($lower, $phrase) !== false) $generic_hits++;
    if ($generic_hits >= 2 || ($word_count < 180 && $post->post_type === 'page')) {
        $issues[] = 'Thin/commodity content warning: this page may sound generic. Add specific details, real examples, local proof, product/service details, FAQs, images, or customer guidance.';
    }
    return array_values(array_unique($issues));
}

function slabseo14_has_internal_link($content) {
    $host = preg_quote((string)wp_parse_url(home_url('/'), PHP_URL_HOST), '/');
    return (bool)(preg_match('/href=["\']https?:\/\/[^"\']*' . $host . '/i', $content) || preg_match('/href=["\']\//i', $content));
}

function slabseo14_has_affiliate_links($content) {
    $o = slabseo14_opts();
    $domains = array_filter(array_map('trim', explode(',', $o['affiliate_domains'] ?? '')));
    foreach ($domains as $domain) if ($domain && stripos($content, $domain) !== false) return true;
    return false;
}

function slabseo14_has_affiliate_disclosure($text) {
    return (stripos($text, 'affiliate') !== false || stripos($text, 'commission') !== false || stripos($text, 'sponsored') !== false || stripos($text, 'may earn') !== false);
}

function slabseo14_has_health_claim_language($text) {
    $terms = array('cure','treats','treatment','prevent disease','prevents disease','heal','guaranteed results','guaranteed income','guaranteed profit','medical','clinically proven','vitamin','supplement','nutrition','immune','inflammation','blood sugar','weight loss','anxiety','depression','pain relief','personally tested','five star','5-star','review count','rating score','earnings claim','passive income');
    foreach ($terms as $term) if (stripos($text, $term) !== false) return true;
    return false;
}

function slabseo14_internal_link_suggestions($post) {
    $suggestions = array();
    if ($post->post_type === 'post') {
        $cats = wp_get_post_categories($post->ID);
        if ($cats) {
            $related = get_posts(array('post_type'=>'post','post_status'=>'publish','numberposts'=>3,'post__not_in'=>array($post->ID),'category__in'=>$cats,'orderby'=>'date','order'=>'DESC'));
            foreach ($related as $r) $suggestions[] = 'Link to: ' . get_the_title($r);
        }
    }
    if (!$suggestions) {
        $pages = get_posts(array('post_type'=>'page','post_status'=>'publish','numberposts'=>3,'orderby'=>'menu_order','order'=>'ASC'));
        foreach ($pages as $p) $suggestions[] = 'Consider linking to page: ' . get_the_title($p);
    }
    return array_slice($suggestions, 0, 3);
}

function slabseo14_add_faq_box() {
    foreach (array('post','page') as $screen) {
        add_meta_box('slabseo14_faq_box', 'Barnd FAQ Schema Helper', 'slabseo14_render_faq_box', $screen, 'normal', 'default');
    }
}

function slabseo14_render_faq_box($post) {
    wp_nonce_field('slabseo14_faq_nonce_action', 'slabseo14_faq_nonce');
    $enabled = get_post_meta($post->ID, '_slabseo_enable_faq_schema', true);
    $faq = (string)get_post_meta($post->ID, '_slabseo_faq_schema', true);
    ?>
    <div class="slabseo-faq-helper">
        <p><strong>Manual FAQ Questions & Answers</strong></p>
        <p class="description"><strong>Google-safe rule:</strong> FAQ schema should only be enabled when the same questions and answers are visible on the page. Use the button below to insert a visible FAQ section into the content.</p>
        <p>
            <button type="button" class="button" id="slabseo15-insert-faq" data-post-id="<?php echo esc_attr($post->ID); ?>">Insert / Update Visible FAQ Section</button>
            <button type="button" class="button" id="slabseo15-copy-faq-html">Copy FAQ HTML</button>
            <span id="slabseo14-faq-status" style="color:#646970;margin-left:8px;"></span>
        </p>
        <p><label><input type="checkbox" name="slabseo_enable_faq_schema" value="1" <?php checked($enabled, '1'); ?>> Output FAQPage schema for this FAQ.</label></p>
        <textarea name="slabseo_faq_schema" id="slabseo14-faq-text" rows="10" style="width:100%;font-family:monospace;" placeholder='[{"question":"What should I check first?","answer":"Start by comparing..."}]'><?php echo esc_textarea($faq); ?></textarea>
        <p class="description">The JSON above is saved as the source for FAQ schema. The visible FAQ block is inserted into the page content with replace-safe markers.</p>
        <details style="margin-top:10px;">
            <summary><strong>Preview / Copy HTML</strong></summary>
            <textarea id="slabseo15-faq-html-preview" rows="8" readonly style="width:100%;font-family:monospace;margin-top:8px;"></textarea>
        </details>
    </div>
    <script>
    (function(){
        const genBtn = document.getElementById('slabseo14-generate-faq');
        const insertBtn = document.getElementById('slabseo15-insert-faq');
        const copyBtn = document.getElementById('slabseo15-copy-faq-html');
        const box = document.getElementById('slabseo14-faq-text');
        const preview = document.getElementById('slabseo15-faq-html-preview');
        const status = document.getElementById('slabseo14-faq-status');
        function esc(s){return String(s||'').replace(/[&<>"']/g,function(c){return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#039;'}[c];});}
        function buildHtml(){
            let faqs=[];
            try{ faqs = JSON.parse(box.value || '[]'); }catch(e){ return ''; }
            if(!Array.isArray(faqs)) return '';
            let html = '<!-- slabseo-faq-start -->\n<section class="slab-faq-section">\n<h2>Frequently Asked Questions</h2>\n';
            faqs.forEach(function(f){
                if(!f || !f.question || !f.answer) return;
                html += '<div class="slab-faq-item">\n<h3>' + esc(f.question) + '</h3>\n<p>' + esc(f.answer) + '</p>\n</div>\n';
            });
            html += '</section>\n<!-- slabseo-faq-end -->';
            return html;
        }
        function updatePreview(){ preview.value = buildHtml(); }
        if(box){ box.addEventListener('input', updatePreview); updatePreview(); }
        if(insertBtn){
            insertBtn.addEventListener('click', function(){
                updatePreview();
                const html = preview.value;
                if(!html){ status.textContent = 'Generate valid FAQ JSON first.'; return; }
                if(!confirm('Insert or replace the visible FAQ section in this post/page content?')) return;
                insertBtn.disabled = true; status.textContent = 'Inserting FAQ section...';
                const fd = new FormData();
                fd.append('action','slabseo15_insert_faq_html');
                fd.append('nonce','<?php echo esc_js(wp_create_nonce('slabseo14_ajax')); ?>');
                fd.append('post_id',insertBtn.dataset.postId);
                fd.append('faq_json', box.value || '[]');
                fetch(ajaxurl,{method:'POST',credentials:'same-origin',body:fd}).then(r=>r.json()).then(j=>{
                    if(j.success){ status.textContent = 'Visible FAQ section inserted. Reloading editor...'; setTimeout(function(){ location.reload(); }, 900); }
                    else { status.textContent = j.data || 'Failed.'; }
                }).catch(()=>{status.textContent='Request failed.';}).finally(()=>{insertBtn.disabled=false;});
            });
        }
        if(copyBtn){ copyBtn.addEventListener('click', function(){ updatePreview(); preview.select(); document.execCommand('copy'); status.textContent='FAQ HTML copied.'; }); }
    })();
    </script>
    <?php
}

function slabseo14_save_faq_meta($post_id, $post) {
    if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) return;
    if (wp_is_post_revision($post_id)) return;
    if (!in_array($post->post_type, array('post','page'), true)) return;
    if (!current_user_can('edit_post', $post_id)) return;
    if (!isset($_POST['slabseo14_faq_nonce']) || !wp_verify_nonce(sanitize_text_field(wp_unslash($_POST['slabseo14_faq_nonce'])), 'slabseo14_faq_nonce_action')) return;
    update_post_meta($post_id, '_slabseo_enable_faq_schema', isset($_POST['slabseo_enable_faq_schema']) ? '1' : '0');
    if (isset($_POST['slabseo_faq_schema'])) {
        $raw = wp_unslash($_POST['slabseo_faq_schema']);
        update_post_meta($post_id, '_slabseo_faq_schema', wp_kses_post($raw));
    }
}

function slabseo14_ajax_generate_faq() {
    wp_send_json_error('AI FAQ generation is not available in Barnd AI SEO Free.');
}

function slabseo15_build_faq_html($faqs) {
    if (!is_array($faqs) || empty($faqs)) return '';
    $html = "<!-- slabseo-faq-start -->\n";
    $html .= '<section class="slab-faq-section">' . "\n";
    $html .= '<h2>Frequently Asked Questions</h2>' . "\n";
    foreach ($faqs as $f) {
        $q = isset($f['question']) ? trim(wp_strip_all_tags($f['question'])) : '';
        $a = isset($f['answer']) ? trim(wp_strip_all_tags($f['answer'])) : '';
        if (!$q || !$a) continue;
        $html .= '<div class="slab-faq-item">' . "\n";
        $html .= '<h3>' . esc_html($q) . '</h3>' . "\n";
        $html .= '<p>' . esc_html($a) . '</p>' . "\n";
        $html .= '</div>' . "\n";
    }
    $html .= '</section>' . "\n";
    $html .= "<!-- slabseo-faq-end -->";
    return $html;
}

function slabseo15_ajax_insert_faq_html() {
    if (!current_user_can('edit_posts')) wp_send_json_error('Permission denied.');
    check_ajax_referer('slabseo14_ajax', 'nonce');
    $post_id = absint($_POST['post_id'] ?? 0);
    if (!$post_id || !current_user_can('edit_post', $post_id)) wp_send_json_error('Invalid post.');
    $raw = isset($_POST['faq_json']) ? wp_unslash($_POST['faq_json']) : '';
    $faqs = json_decode($raw, true);
    if (!is_array($faqs) || empty($faqs)) wp_send_json_error('Invalid FAQ JSON.');
    $html = slabseo15_build_faq_html($faqs);
    if (!$html) wp_send_json_error('No valid FAQ questions and answers found.');
    $post = get_post($post_id);
    if (!$post) wp_send_json_error('Post not found.');
    $content = (string)$post->post_content;
    $pattern = '/<!--\s*slabseo-faq-start\s*-->.*?<!--\s*slabseo-faq-end\s*-->/is';
    if (preg_match($pattern, $content)) {
        $content = preg_replace($pattern, $html, $content, 1);
    } else {
        $content = rtrim($content) . "\n\n" . $html;
    }
    update_post_meta($post_id, '_slabseo_faq_schema', wp_json_encode($faqs, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE));
    update_post_meta($post_id, '_slabseo_enable_faq_schema', '1');
    $updated = wp_update_post(array('ID'=>$post_id, 'post_content'=>$content), true);
    if (is_wp_error($updated)) wp_send_json_error($updated->get_error_message());
    wp_send_json_success(array('message'=>'FAQ inserted', 'post_id'=>$post_id));
}

function slabseo14_output_faq_schema() {
    if (!is_singular()) return;
    $opts = slabseo14_opts();
    if (($opts['enable_schema'] ?? '1') !== '1') return;
    $post_id = get_queried_object_id();
    if (get_post_meta($post_id, '_slabseo_enable_faq_schema', true) !== '1') return;
    $visible_content = (string)get_post_field('post_content', $post_id);
    if (stripos($visible_content, '<!-- slabseo-faq-start -->') === false || stripos($visible_content, '<!-- slabseo-faq-end -->') === false) return;
    $raw = (string)get_post_meta($post_id, '_slabseo_faq_schema', true);
    $faqs = json_decode($raw, true);
    if (!is_array($faqs) || empty($faqs)) return;
    $entities = array();
    foreach ($faqs as $f) {
        $q = isset($f['question']) ? wp_strip_all_tags($f['question']) : '';
        $a = isset($f['answer']) ? wp_strip_all_tags($f['answer']) : '';
        if ($q && $a) $entities[] = array('@type'=>'Question','name'=>$q,'acceptedAnswer'=>array('@type'=>'Answer','text'=>$a));
    }
    if (!$entities) return;
    $schema = array('@context'=>'https://schema.org','@type'=>'FAQPage','mainEntity'=>$entities);
    echo "\n<script type=\"application/ld+json\">" . wp_json_encode($schema, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE) . "</script>\n";
}

function slabseo14_add_llms_rewrite() {
    add_rewrite_rule('^llms\.txt$', 'index.php?slabseo_llms=1', 'top');
}

function slabseo14_query_vars($vars) {
    $vars[] = 'slabseo_llms';
    return $vars;
}

function slabseo14_render_llms() {
    if (get_query_var('slabseo_llms') != '1') return;
    $o = slabseo14_opts();
    if (($o['enable_llms'] ?? '1') !== '1') {
        status_header(404);
        nocache_headers();
        return;
    }
    header('Content-Type: text/plain; charset=utf-8');
    echo '# ' . sanitize_text_field($o['brand_name'] ?? get_bloginfo('name')) . "\n\n";
    echo 'Legal owner: ' . sanitize_text_field($o['legal_owner'] ?? 'Site owner') . "\n";
    echo 'Website: ' . home_url('/') . "\n";
    echo 'Sitemap: ' . slabseo14_get_domain_sitemap_url() . "\n";
    echo 'Site type: ' . sanitize_text_field($o['site_type'] ?? '') . "\n\n";
    if (!empty($o['site_description'])) echo 'Summary: ' . sanitize_textarea_field($o['site_description']) . "\n\n";
    if (!empty($o['default_pov'])) echo 'Editorial point of view: ' . sanitize_textarea_field($o['default_pov']) . "\n\n";
    echo "## Important Pages\n";
    $pages = get_posts(array('post_type'=>'page','post_status'=>'publish','numberposts'=>30,'orderby'=>'menu_order','order'=>'ASC'));
    foreach ($pages as $p) echo '- ' . get_the_title($p) . ': ' . get_permalink($p) . "\n";
    echo "\n## Recent Posts\n";
    $posts = get_posts(array('post_type'=>'post','post_status'=>'publish','numberposts'=>30,'orderby'=>'date','order'=>'DESC'));
    foreach ($posts as $p) echo '- ' . get_the_title($p) . ': ' . get_permalink($p) . "\n";
    echo "\n## Content Use Notes\n";
    echo "This file summarizes public website content for AI search and assistant systems. Always use the live page as the source of truth. Affiliate, health, nutrition, restaurant, franchise, price, availability, and review information should be verified on the source page before use.\n";
    exit;
}

function slabseo14_output_llms_link() {
    $o = slabseo14_opts();
    if (($o['enable_llms'] ?? '1') !== '1') return;
    echo "\n" . '<link rel="alternate" type="text/plain" href="' . esc_url(home_url('/llms.txt')) . '" title="LLMs.txt">' . "\n";
}

register_activation_hook(__FILE__, 'slabseo14_activate');
function slabseo14_activate() {
    slabseo14_add_llms_rewrite();
    flush_rewrite_rules();
}

register_activation_hook(__FILE__, array('Barnd_AI_SEO', 'activate'));
register_deactivation_hook(__FILE__, array('Barnd_AI_SEO', 'deactivate'));
add_action('plugins_loaded', array('Barnd_AI_SEO', 'instance'));

/*
 * Barnd AI SEO v1.6
 * - Redirect manager
 * - 404 monitor
 * - Internal broken-link scanner
 * - Auto redirect when post/page slug changes
 * - Menu/MenuItem schema helper for restaurant/menu pages
 */
add_action('admin_menu', 'slabseo16_admin_menu');
add_action('template_redirect', 'slabseo16_handle_redirects', 0);
add_action('template_redirect', 'slabseo16_log_404', 99);
add_action('save_post', 'slabseo16_track_slug_redirects', 30, 3);
add_action('add_meta_boxes', 'slabseo16_add_menu_schema_box');
add_action('save_post', 'slabseo16_save_menu_schema_meta', 40, 2);
add_action('wp_head', 'slabseo16_output_menu_schema', 22);

function slabseo16_admin_menu() {
    // Free public build uses the top-level Barnd AI SEO menu only.
}

function slabseo16_redirects_option() { return 'slabseo16_redirects'; }
function slabseo16_404_option() { return 'slabseo16_404_log'; }

function slabseo16_normalize_path($path) {
    $path = trim((string)$path);
    if ($path === '') return '';
    $parts = wp_parse_url($path);
    if (is_array($parts) && !empty($parts['path'])) $path = $parts['path'];
    $path = '/' . ltrim($path, '/');
    $path = strtok($path, '?#');
    return untrailingslashit($path) ?: '/';
}

function slabseo16_get_redirects() {
    $items = get_option(slabseo16_redirects_option(), array());
    return is_array($items) ? $items : array();
}

function slabseo16_save_redirects($items) {
    update_option(slabseo16_redirects_option(), array_values($items), false);
}

function slabseo16_redirects_page() {
    if (!current_user_can('manage_options')) return;
    $message = '';
    if (isset($_POST['slabseo16_nonce']) && wp_verify_nonce(sanitize_text_field(wp_unslash($_POST['slabseo16_nonce'])), 'slabseo16_redirects')) {
        $redirects = slabseo16_get_redirects();
        if (isset($_POST['slabseo16_add_redirect'])) {
            $from = slabseo16_normalize_path(wp_unslash($_POST['from_path'] ?? ''));
            $to = esc_url_raw(wp_unslash($_POST['to_url'] ?? ''));
            $code = (int)($_POST['status_code'] ?? 301);
            if (!in_array($code, array(301,302,307,308), true)) $code = 301;
            if ($from && $to) {
                $redirects[] = array('from'=>$from, 'to'=>$to, 'code'=>$code, 'created'=>current_time('mysql'), 'source'=>'manual');
                slabseo16_save_redirects($redirects);
                $message = 'Redirect added.';
            }
        }
        if (isset($_POST['slabseo16_delete_redirect']) && isset($_POST['delete_index'])) {
            $idx = (int)$_POST['delete_index'];
            if (isset($redirects[$idx])) {
                unset($redirects[$idx]);
                slabseo16_save_redirects($redirects);
                $message = 'Redirect deleted.';
            }
        }
        if (isset($_POST['slabseo16_clear_404'])) {
            update_option(slabseo16_404_option(), array(), false);
            $message = '404 log cleared.';
        }
    }
    $redirects = slabseo16_get_redirects();
    $logs = get_option(slabseo16_404_option(), array());
    if (!is_array($logs)) $logs = array();
    uasort($logs, function($a,$b){ return strcmp($b['last_seen'] ?? '', $a['last_seen'] ?? ''); });
    ?>
    <div class="wrap">
        <h1>Barnd Redirects &amp; 404 Monitor</h1>
        <p>v1.6 adds a practical redirect manager, automatic old-slug redirects, and 404 logging. This is useful after changing page URLs, menu pages, franchise pages, and location pages.</p>
        <?php if ($message): ?><div class="notice notice-success"><p><?php echo esc_html($message); ?></p></div><?php endif; ?>
        <h2>Add Redirect</h2>
        <form method="post">
            <?php wp_nonce_field('slabseo16_redirects', 'slabseo16_nonce'); ?>
            <table class="form-table" role="presentation">
                <tr><th scope="row">From Path</th><td><input type="text" name="from_path" class="regular-text" placeholder="/old-page/"> <p class="description">Use a local path, not the full URL.</p></td></tr>
                <tr><th scope="row">To URL</th><td><input type="url" name="to_url" class="regular-text" placeholder="https://example.com/new-page/"></td></tr>
                <tr><th scope="row">Status</th><td><select name="status_code"><option value="301">301 Permanent</option><option value="302">302 Temporary</option><option value="307">307 Temporary</option><option value="308">308 Permanent</option></select></td></tr>
            </table>
            <p><button type="submit" name="slabseo16_add_redirect" class="button button-primary">Add Redirect</button></p>
        </form>
        <h2>Active Redirects</h2>
        <table class="widefat striped"><thead><tr><th>From</th><th>To</th><th>Status</th><th>Source</th><th>Created</th><th>Action</th></tr></thead><tbody>
        <?php if (!$redirects): ?><tr><td colspan="6">No redirects yet.</td></tr><?php endif; ?>
        <?php foreach ($redirects as $i=>$r): ?>
            <tr><td><code><?php echo esc_html($r['from'] ?? ''); ?></code></td><td><a href="<?php echo esc_url($r['to'] ?? ''); ?>" target="_blank"><?php echo esc_html($r['to'] ?? ''); ?></a></td><td><?php echo esc_html($r['code'] ?? 301); ?></td><td><?php echo esc_html($r['source'] ?? 'manual'); ?></td><td><?php echo esc_html($r['created'] ?? ''); ?></td><td><form method="post" style="display:inline"><?php wp_nonce_field('slabseo16_redirects','slabseo16_nonce'); ?><input type="hidden" name="delete_index" value="<?php echo esc_attr($i); ?>"><button class="button" name="slabseo16_delete_redirect">Delete</button></form></td></tr>
        <?php endforeach; ?>
        </tbody></table>
        <h2>404 Monitor</h2>
        <form method="post" style="margin:10px 0"><?php wp_nonce_field('slabseo16_redirects','slabseo16_nonce'); ?><button class="button" name="slabseo16_clear_404">Clear 404 Log</button></form>
        <table class="widefat striped"><thead><tr><th>Path</th><th>Hits</th><th>Last Seen</th><th>Referrer</th><th>Quick Redirect</th></tr></thead><tbody>
        <?php if (!$logs): ?><tr><td colspan="5">No 404s logged yet.</td></tr><?php endif; ?>
        <?php $n=0; foreach ($logs as $path=>$row): if ($n++ >= 100) break; ?>
            <tr><td><code><?php echo esc_html($path); ?></code></td><td><?php echo esc_html($row['count'] ?? 0); ?></td><td><?php echo esc_html($row['last_seen'] ?? ''); ?></td><td><?php echo esc_html($row['referrer'] ?? ''); ?></td><td><form method="post"><?php wp_nonce_field('slabseo16_redirects','slabseo16_nonce'); ?><input type="hidden" name="from_path" value="<?php echo esc_attr($path); ?>"><input type="url" name="to_url" placeholder="https://..." style="width:260px"><input type="hidden" name="status_code" value="301"> <button class="button" name="slabseo16_add_redirect">Add 301</button></form></td></tr>
        <?php endforeach; ?>
        </tbody></table>
    </div>
    <?php
}

function slabseo16_handle_redirects() {
    if (is_admin() || wp_doing_ajax()) return;
    $path = slabseo16_normalize_path($_SERVER['REQUEST_URI'] ?? '');
    foreach (slabseo16_get_redirects() as $r) {
        if (($r['from'] ?? '') === $path) {
            $to = $r['to'] ?? '';
            $code = (int)($r['code'] ?? 301);
            if ($to) { wp_redirect($to, $code); exit; }
        }
    }
}

function slabseo16_log_404() {
    if (is_admin() || wp_doing_ajax() || !is_404()) return;
    $path = slabseo16_normalize_path($_SERVER['REQUEST_URI'] ?? '');
    if (!$path || $path === '/favicon.ico' || preg_match('/\.(png|jpg|jpeg|gif|webp|css|js|ico|svg)$/i', $path)) return;
    $logs = get_option(slabseo16_404_option(), array());
    if (!is_array($logs)) $logs = array();
    if (!isset($logs[$path])) $logs[$path] = array('count'=>0, 'first_seen'=>current_time('mysql'), 'last_seen'=>'', 'referrer'=>'');
    $logs[$path]['count'] = (int)$logs[$path]['count'] + 1;
    $logs[$path]['last_seen'] = current_time('mysql');
    $logs[$path]['referrer'] = esc_url_raw($_SERVER['HTTP_REFERER'] ?? '');
    if (count($logs) > 500) $logs = array_slice($logs, -500, null, true);
    update_option(slabseo16_404_option(), $logs, false);
}

function slabseo16_track_slug_redirects($post_id, $post, $update) {
    if (wp_is_post_revision($post_id) || wp_is_post_autosave($post_id)) return;
    if (!in_array($post->post_type, array('post','page'), true)) return;
    if ($post->post_status !== 'publish') {
        update_post_meta($post_id, '_slabseo16_last_path', slabseo16_normalize_path(str_replace(home_url(), '', get_permalink($post_id))));
        return;
    }
    $new_path = slabseo16_normalize_path(str_replace(home_url(), '', get_permalink($post_id)));
    $old_path = (string)get_post_meta($post_id, '_slabseo16_last_path', true);
    if ($old_path && $new_path && $old_path !== $new_path) {
        $redirects = slabseo16_get_redirects();
        $exists = false;
        foreach ($redirects as $r) { if (($r['from'] ?? '') === $old_path) { $exists = true; break; } }
        if (!$exists) {
            $redirects[] = array('from'=>$old_path, 'to'=>get_permalink($post_id), 'code'=>301, 'created'=>current_time('mysql'), 'source'=>'auto-slug-change');
            slabseo16_save_redirects($redirects);
        }
    }
    update_post_meta($post_id, '_slabseo16_last_path', $new_path);
}

function slabseo16_link_scanner_page() {
    if (!current_user_can('manage_options')) return;
    $results = array();
    if (isset($_POST['slabseo16_scan_links']) && check_admin_referer('slabseo16_scan_links')) {
        $results = slabseo16_scan_internal_links();
    }
    ?>
    <div class="wrap"><h1>Barnd Internal Link Scanner</h1>
    <p>Scans published posts/pages for internal links that may be broken. This is a lightweight scanner, not a full crawler.</p>
    <form method="post"><?php wp_nonce_field('slabseo16_scan_links'); ?><p><button class="button button-primary" name="slabseo16_scan_links">Scan Internal Links</button></p></form>
    <?php if ($results): ?><h2>Possible Broken Internal Links</h2><table class="widefat striped"><thead><tr><th>Source Page</th><th>Broken Link</th><th>Reason</th></tr></thead><tbody>
    <?php foreach ($results as $r): ?><tr><td><a href="<?php echo esc_url($r['source_url']); ?>" target="_blank"><?php echo esc_html($r['source_title']); ?></a></td><td><code><?php echo esc_html($r['url']); ?></code></td><td><?php echo esc_html($r['reason']); ?></td></tr><?php endforeach; ?>
    </tbody></table><?php elseif (isset($_POST['slabseo16_scan_links'])): ?><div class="notice notice-success"><p>No obvious broken internal links found.</p></div><?php endif; ?></div>
    <?php
}

function slabseo16_scan_internal_links() {
    $out = array();
    $home_host = wp_parse_url(home_url(), PHP_URL_HOST);
    $posts = get_posts(array('post_type'=>array('post','page'), 'post_status'=>'publish', 'numberposts'=>250));
    foreach ($posts as $p) {
        if (!preg_match_all('/href=["\']([^"\']+)["\']/i', $p->post_content, $m)) continue;
        foreach (array_unique($m[1]) as $url) {
            if (strpos($url, '#') === 0 || strpos($url, 'mailto:') === 0 || strpos($url, 'tel:') === 0) continue;
            $host = wp_parse_url($url, PHP_URL_HOST);
            if ($host && $host !== $home_host) continue;
            $path = $host ? (wp_parse_url($url, PHP_URL_PATH) ?: '/') : $url;
            $path = strtok($path, '?#');
            if (!$path || $path === '/') continue;
            $full = home_url($path);
            $id = url_to_postid($full);
            if (!$id) {
                $out[] = array('source_title'=>get_the_title($p), 'source_url'=>get_permalink($p), 'url'=>$url, 'reason'=>'No matching published post/page found for this internal URL.');
            }
        }
    }
    return $out;
}

function slabseo16_add_menu_schema_box() {
    foreach (array('page','post') as $screen) {
        add_meta_box('slabseo16_menu_schema', 'Barnd Menu / MenuItem Schema', 'slabseo16_render_menu_schema_box', $screen, 'normal', 'default');
    }
}

function slabseo16_render_menu_schema_box($post) {
    wp_nonce_field('slabseo16_menu_schema_save', 'slabseo16_menu_schema_nonce');
    $enabled = get_post_meta($post->ID, '_slabseo16_enable_menu_schema', true);
    $items = (string)get_post_meta($post->ID, '_slabseo16_menu_items', true);
    if (!$items) $items = "[{\n  \"name\": \"Example Burger\",\n  \"description\": \"Certified Angus Beef patty served on a brioche bun.\",\n  \"price\": \"\",\n  \"currency\": \"CAD\",\n  \"category\": \"Burgers\"\n}]";
    echo '<p><label><input type="checkbox" name="slabseo16_enable_menu_schema" value="1" ' . checked($enabled, '1', false) . '> Output Menu / MenuItem schema for this page.</label></p>';
    echo '<p class="description">Use this for restaurant menu pages. Only add prices if they are current and visible on the page.</p>';
    echo '<textarea name="slabseo16_menu_items" rows="12" style="width:100%;font-family:monospace;">' . esc_textarea($items) . '</textarea>';
    echo '<p class="description">JSON list format: name, description, price, currency, category. Keep menu information consistent with visible page content.</p>';
}

function slabseo16_save_menu_schema_meta($post_id, $post) {
    if (wp_is_post_revision($post_id) || wp_is_post_autosave($post_id)) return;
    if (!isset($_POST['slabseo16_menu_schema_nonce']) || !wp_verify_nonce(sanitize_text_field(wp_unslash($_POST['slabseo16_menu_schema_nonce'])), 'slabseo16_menu_schema_save')) return;
    update_post_meta($post_id, '_slabseo16_enable_menu_schema', isset($_POST['slabseo16_enable_menu_schema']) ? '1' : '0');
    if (isset($_POST['slabseo16_menu_items'])) update_post_meta($post_id, '_slabseo16_menu_items', wp_unslash($_POST['slabseo16_menu_items']));
}

function slabseo16_output_menu_schema() {
    if (!is_singular()) return;
    $opts = slabseo14_opts();
    if (($opts['enable_schema'] ?? '1') !== '1') return;
    $post_id = get_the_ID();
    if (get_post_meta($post_id, '_slabseo16_enable_menu_schema', true) !== '1') return;
    $raw = (string)get_post_meta($post_id, '_slabseo16_menu_items', true);
    $items = json_decode($raw, true);
    if (!is_array($items) || !$items) return;
    $menu_items = array();
    foreach ($items as $it) {
        if (empty($it['name'])) continue;
        $mi = array('@type'=>'MenuItem', 'name'=>sanitize_text_field($it['name']));
        if (!empty($it['description'])) $mi['description'] = sanitize_textarea_field($it['description']);
        if (!empty($it['price'])) {
            $mi['offers'] = array('@type'=>'Offer', 'price'=>sanitize_text_field($it['price']), 'priceCurrency'=>sanitize_text_field($it['currency'] ?? 'CAD'));
        }
        if (!empty($it['category'])) $mi['menuAddOn'] = sanitize_text_field($it['category']);
        $menu_items[] = $mi;
    }
    if (!$menu_items) return;
    $schema = array('@context'=>'https://schema.org', '@type'=>'Menu', '@id'=>get_permalink($post_id) . '#menu', 'name'=>get_the_title($post_id), 'url'=>get_permalink($post_id), 'hasMenuItem'=>$menu_items);
    echo "\n<script type=\"application/ld+json\">" . wp_json_encode($schema, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE) . "</script>\n";
}


/*
 * Barnd AI SEO v2.2
 * - Bulk SEO Fixer for posts/pages
 * - Filter audit work by type/status/missing fields
 * - Bulk Pro generation for blank SEO fields and featured image ALT text
 * - Category/date/Product Finder filters, ignore-from-audit, bulk FAQ, affiliate disclosure fixer
 * - Fill blanks only by default; optional replace mode
 */
add_action('add_meta_boxes', 'slabseo22_add_ignore_box');
add_action('save_post', 'slabseo22_save_ignore_meta', 20, 2);

function slabseo21_admin_menu() {
    add_submenu_page('slab-seo-assistant', 'Bulk SEO Fixer', 'Bulk SEO Fixer', 'manage_options', 'slabseo-bulk-fixer', 'slabseo21_bulk_fixer_page');
}

function slabseo21_bulk_fixer_page() {
    if (!current_user_can('manage_options')) return;
    echo '<div class="wrap"><h1>Bulk SEO Fixer</h1><div class="notice notice-info inline"><p><strong>Pro preview only.</strong> Bulk generation is not active in Barnd AI SEO Free. Use SEO Audit and Image SEO for manual Free fixes.</p></div><p><a class="button button-primary" href="' . esc_url(admin_url('admin.php?page=slabseo-audit')) . '">Open SEO Audit</a> <a class="button" href="' . esc_url(admin_url('admin.php?page=slabseo-pro-features')) . '">View Pro Preview</a></p></div>';
    return;
    $message = '';
    $results = array();
    if (isset($_POST['slabseo21_bulk_action']) && check_admin_referer('slabseo21_bulk_fixer')) {
        $ids = isset($_POST['post_ids']) && is_array($_POST['post_ids']) ? array_map('absint', wp_unslash($_POST['post_ids'])) : array();
        $ids = array_values(array_filter(array_unique($ids)));
        $ids = array_slice($ids, 0, 10); // protect server/API from very large one-click batches
        $replace = !empty($_POST['replace_existing']);
        $mode = sanitize_key($_POST['slabseo21_bulk_action']);
        if (!$ids) {
            $message = '<div class="notice notice-warning"><p>No posts selected.</p></div>';
        } else {
            foreach ($ids as $post_id) {
                if (!current_user_can('edit_post', $post_id)) continue;
                $results[] = slabseo21_fix_post($post_id, $mode, $replace);
            }
            $message = '<div class="notice notice-success"><p>Bulk fixer finished. Review the result table below. Maximum 10 items per run for safety.</p></div>';
        }
    }

    $post_type = isset($_GET['post_type_filter']) ? sanitize_key($_GET['post_type_filter']) : 'post,page';
    $status = isset($_GET['post_status_filter']) ? sanitize_key($_GET['post_status_filter']) : 'publish';
    $missing = isset($_GET['missing_filter']) ? sanitize_key($_GET['missing_filter']) : 'any';
    $limit = isset($_GET['limit']) ? max(10, min(100, absint($_GET['limit']))) : 50;
    $category_filter = isset($_GET['category_filter']) ? sanitize_title(wp_unslash($_GET['category_filter'])) : '';
    $date_after = isset($_GET['date_after']) ? sanitize_text_field(wp_unslash($_GET['date_after'])) : '';
    $product_finder_only = !empty($_GET['product_finder_only']);
    $include_ignored = !empty($_GET['include_ignored']);

    $types = ($post_type === 'page') ? array('page') : (($post_type === 'post') ? array('post') : array('post','page'));
    $statuses = in_array($status, array('publish','draft','future','private'), true) ? array($status) : array('publish','draft','future');
    $query_args = array('post_type'=>$types, 'post_status'=>$statuses, 'numberposts'=>$limit, 'orderby'=>'modified', 'order'=>'DESC');
    if ($category_filter && in_array('post', $types, true)) $query_args['category_name'] = $category_filter;
    if ($date_after && preg_match('/^\d{4}-\d{2}-\d{2}$/', $date_after)) $query_args['date_query'] = array(array('after'=>$date_after, 'inclusive'=>true));
    $posts = get_posts($query_args);
    $rows = array();
    foreach ($posts as $p) {
        if (!$include_ignored && slabseo22_is_ignored($p->ID)) continue;
        if ($product_finder_only && !slabseo22_is_product_finder_post($p->ID)) continue;
        $row = slabseo21_get_missing_summary($p);
        if (slabseo21_row_matches_filter($row, $missing)) $rows[] = $row;
    }
    ?>
    <div class="wrap slabseo21-wrap">
        <h1>Barnd Bulk SEO Fixer</h1>
        <p>Fix missing SEO fields without opening each post. Default mode fills blanks only and keeps posts as-is.</p>
        <?php echo $message; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
        <style>
            .slabseo21-toolbar{background:#fff;border:1px solid #dcdcde;padding:14px;margin:15px 0;border-radius:8px}.slabseo21-bad{color:#b32d2e;font-weight:600}.slabseo21-good{color:#007017;font-weight:600}.slabseo21-pill{display:inline-block;background:#f0f0f1;border-radius:999px;padding:2px 8px;margin:2px;font-size:12px}.slabseo21-actions{position:sticky;bottom:0;background:#fff;border:1px solid #dcdcde;padding:12px;margin-top:10px}.slabseo21-results{margin:16px 0}.slabseo21-small{color:#646970;font-size:12px}
        </style>
        <div class="slabseo21-toolbar">
            <form method="get">
                <input type="hidden" name="page" value="slabseo-bulk-fixer">
                <label>Content type
                    <select name="post_type_filter">
                        <option value="post,page" <?php selected($post_type,'post,page'); ?>>Posts + Pages</option>
                        <option value="post" <?php selected($post_type,'post'); ?>>Posts only</option>
                        <option value="page" <?php selected($post_type,'page'); ?>>Pages only</option>
                    </select>
                </label>
                <label>Status
                    <select name="post_status_filter">
                        <option value="publish" <?php selected($status,'publish'); ?>>Published</option>
                        <option value="draft" <?php selected($status,'draft'); ?>>Drafts</option>
                        <option value="future" <?php selected($status,'future'); ?>>Scheduled</option>
                        <option value="all" <?php selected($status,'all'); ?>>Published + Draft + Scheduled</option>
                    </select>
                </label>
                <label>Problem
                    <select name="missing_filter">
                        <option value="any" <?php selected($missing,'any'); ?>>Any missing SEO field</option>
                        <option value="title" <?php selected($missing,'title'); ?>>Missing SEO title</option>
                        <option value="description" <?php selected($missing,'description'); ?>>Missing meta description</option>
                        <option value="pov" <?php selected($missing,'pov'); ?>>Missing point of view</option>
                        <option value="schema" <?php selected($missing,'schema'); ?>>Missing schema/about</option>
                        <option value="alt" <?php selected($missing,'alt'); ?>>Missing featured image ALT</option>
                        <option value="faq" <?php selected($missing,'faq'); ?>>Missing visible FAQ</option>
                        <option value="disclosure" <?php selected($missing,'disclosure'); ?>>Affiliate disclosure missing</option>
                    </select>
                </label>
                <label>Category
                    <?php wp_dropdown_categories(array('show_option_all'=>'All categories','hide_empty'=>false,'name'=>'category_filter','value_field'=>'slug','selected'=>$category_filter,'hierarchical'=>true)); ?>
                </label>
                <label>Modified after <input type="date" name="date_after" value="<?php echo esc_attr($date_after); ?>"></label>
                <label><input type="checkbox" name="product_finder_only" value="1" <?php checked($product_finder_only); ?>> Product Finder posts only</label>
                <label><input type="checkbox" name="include_ignored" value="1" <?php checked($include_ignored); ?>> Include ignored</label>
                <label>Limit <input type="number" name="limit" min="10" max="100" value="<?php echo esc_attr($limit); ?>" style="width:80px;"></label>
                <button class="button">Filter</button>
            </form>
        </div>

        <?php if ($results): ?>
            <div class="slabseo21-results">
                <h2>Bulk Fix Results</h2>
                <table class="widefat striped"><thead><tr><th>Post</th><th>Result</th><th>Updated Fields</th><th>Notes</th></tr></thead><tbody>
                <?php foreach ($results as $r): ?>
                    <tr>
                        <td><strong><?php echo esc_html($r['title']); ?></strong><br><a href="<?php echo esc_url(get_edit_post_link($r['id'])); ?>">Edit</a></td>
                        <td><?php echo $r['ok'] ? '<span class="slabseo21-good">OK</span>' : '<span class="slabseo21-bad">Issue</span>'; ?></td>
                        <td><?php echo $r['updated'] ? esc_html(implode(', ', $r['updated'])) : '<span class="slabseo21-small">No fields changed</span>'; ?></td>
                        <td><?php echo esc_html($r['note']); ?></td>
                    </tr>
                <?php endforeach; ?>
                </tbody></table>
            </div>
        <?php endif; ?>

        <form method="post">
            <?php wp_nonce_field('slabseo21_bulk_fixer'); ?>
            <table class="widefat fixed striped">
                <thead><tr><td style="width:36px;"><input type="checkbox" onclick="document.querySelectorAll('.slabseo21-check').forEach(c=>c.checked=this.checked)"></td><th>Post/Page</th><th>Missing</th><th>Current SEO Fields</th></tr></thead>
                <tbody>
                <?php if (!$rows): ?>
                    <tr><td colspan="4">No matching posts/pages found for this filter.</td></tr>
                <?php else: foreach ($rows as $r): ?>
                    <tr>
                        <td><input class="slabseo21-check" type="checkbox" name="post_ids[]" value="<?php echo esc_attr($r['id']); ?>"></td>
                        <td><strong><?php echo esc_html($r['title']); ?></strong><br><span class="slabseo21-small"><?php echo esc_html($r['type'] . ' · ' . $r['status']); ?><?php echo !empty($r['ignored']) ? ' · <strong>Ignored</strong>' : ''; ?></span><br><a href="<?php echo esc_url(get_permalink($r['id'])); ?>" target="_blank">View</a> | <a href="<?php echo esc_url(get_edit_post_link($r['id'])); ?>">Edit</a></td>
                        <td>
                            <?php foreach ($r['missing'] as $m): ?><span class="slabseo21-pill"><?php echo esc_html($m); ?></span><?php endforeach; ?>
                            <?php if (!$r['missing']): ?><span class="slabseo21-good">No missing fields</span><?php endif; ?>
                        </td>
                        <td><span class="slabseo21-small">SEO title:</span> <?php echo $r['seo_title'] ? esc_html($r['seo_title']) : '<span class="slabseo21-bad">blank</span>'; ?><br><span class="slabseo21-small">Meta:</span> <?php echo $r['seo_desc'] ? esc_html(wp_trim_words($r['seo_desc'], 18)) : '<span class="slabseo21-bad">blank</span>'; ?></td>
                    </tr>
                <?php endforeach; endif; ?>
                </tbody>
            </table>
            <div class="slabseo21-actions">
                <p><strong>Bulk action for selected items</strong></p>
                <button class="button button-primary" name="slabseo21_bulk_action" value="all_missing">Generate All Missing SEO Fields</button>
                <button class="button" name="slabseo21_bulk_action" value="title_desc">Review SEO Title + Meta</button>
                <button class="button" name="slabseo21_bulk_action" value="pov_schema">Generate POV + Schema About</button>
                <button class="button" name="slabseo21_bulk_action" value="image_alt">Generate Featured Image ALT</button>
                <button class="button" name="slabseo21_bulk_action" value="faq_insert">Generate + Insert FAQ</button>
                <button class="button" name="slabseo21_bulk_action" value="affiliate_disclosure">Insert Affiliate Disclosure</button>
                <button class="button" name="slabseo21_bulk_action" value="ignore_audit">Ignore From Audit</button>
                <button class="button" name="slabseo21_bulk_action" value="unignore_audit">Remove Ignore</button>
                <label style="margin-left:14px;"><input type="checkbox" name="replace_existing" value="1"> Replace existing fields</label>
                <p class="description">Safety: maximum 10 selected posts per run. Health/nutrition posts are not published automatically; this only fills SEO metadata/content helpers.</p>
            </div>
        </form>
    </div>
    <?php
}

function slabseo21_get_missing_summary($post) {
    $thumb_id = get_post_thumbnail_id($post->ID);
    $seo_title = (string)get_post_meta($post->ID, '_slabseo_title', true);
    $seo_desc = (string)get_post_meta($post->ID, '_slabseo_description', true);
    $pov = (string)get_post_meta($post->ID, '_slabseo_pov', true);
    $schema = (string)get_post_meta($post->ID, '_slabseo_schema_about', true);
    $alt = $thumb_id ? (string)get_post_meta($thumb_id, '_wp_attachment_image_alt', true) : '';
    $content_raw = (string)$post->post_content;
    $content_text = wp_strip_all_tags($content_raw);
    $faq_raw = (string)get_post_meta($post->ID, '_slabseo_faq_schema', true);
    $has_faq = (stripos($content_raw, 'slabseo-faq-start') !== false) || (!empty($faq_raw) && json_decode($faq_raw, true));
    $has_aff_link = function_exists('slabseo14_has_affiliate_links') ? slabseo14_has_affiliate_links($content_raw) : false;
    $has_aff_disclosure = function_exists('slabseo14_has_affiliate_disclosure') ? slabseo14_has_affiliate_disclosure($content_text) : false;
    $missing = array();
    if (!$seo_title) $missing[] = 'SEO title';
    if (!$seo_desc) $missing[] = 'Meta description';
    if (!$pov) $missing[] = 'Point of view';
    if (!$schema) $missing[] = 'Schema/about';
    if ($thumb_id && !$alt) $missing[] = 'Featured image ALT';
    if (!$has_faq) $missing[] = 'FAQ';
    if ($has_aff_link && !$has_aff_disclosure) $missing[] = 'Affiliate disclosure';
    return array('id'=>$post->ID,'title'=>get_the_title($post),'type'=>$post->post_type,'status'=>$post->post_status,'missing'=>$missing,'seo_title'=>$seo_title,'seo_desc'=>$seo_desc,'pov'=>$pov,'schema'=>$schema,'thumb_id'=>$thumb_id,'alt'=>$alt,'ignored'=>slabseo22_is_ignored($post->ID));
}

function slabseo21_row_matches_filter($row, $filter) {
    if ($filter === 'any') return !empty($row['missing']);
    $map = array('title'=>'SEO title','description'=>'Meta description','pov'=>'Point of view','schema'=>'Schema/about','alt'=>'Featured image ALT','faq'=>'FAQ','disclosure'=>'Affiliate disclosure');
    return in_array($map[$filter] ?? '', $row['missing'], true);
}

function slabseo21_fix_post($post_id, $mode, $replace=false) {
    $post = get_post($post_id);
    $out = array('id'=>$post_id,'title'=>$post ? get_the_title($post) : ('#'.$post_id),'ok'=>false,'updated'=>array(),'note'=>'');
    if (!$post) { $out['note']='Post not found.'; return $out; }
    $needs_ai = in_array($mode, array('all_missing','title_desc','pov_schema'), true);
    if ($mode === 'ignore_audit') { update_post_meta($post_id, '_slabseo_ignore_audit', '1'); $out['ok']=true; $out['updated'][]='Ignore flag'; $out['note']='Post will be hidden from default audit/bulk lists.'; return $out; }
    if ($mode === 'unignore_audit') { delete_post_meta($post_id, '_slabseo_ignore_audit'); $out['ok']=true; $out['updated'][]='Ignore flag removed'; $out['note']='Post is visible in audit/bulk lists again.'; return $out; }
    $data = array();
    if ($needs_ai) {
        $data = slabseo21_generate_post_ai_fields($post_id);
        if (is_wp_error($data)) { $out['note'] = $data->get_error_message(); return $out; }
    }
    $map = array(
        '_slabseo_title' => array('label'=>'SEO title','json'=>'seo_title','modes'=>array('all_missing','title_desc')),
        '_slabseo_description' => array('label'=>'Meta description','json'=>'meta_description','modes'=>array('all_missing','title_desc')),
        '_slabseo_og_title' => array('label'=>'OG title','json'=>'og_title','modes'=>array('all_missing','title_desc')),
        '_slabseo_og_description' => array('label'=>'OG description','json'=>'og_description','modes'=>array('all_missing','title_desc')),
        '_slabseo_pov' => array('label'=>'Point of view','json'=>'point_of_view','modes'=>array('all_missing','pov_schema')),
        '_slabseo_schema_about' => array('label'=>'Schema/about','json'=>'schema_about','modes'=>array('all_missing','pov_schema')),
    );
    foreach ($map as $meta_key=>$cfg) {
        if (!in_array($mode, $cfg['modes'], true)) continue;
        $current = (string)get_post_meta($post_id, $meta_key, true);
        $value = isset($data[$cfg['json']]) ? trim(wp_strip_all_tags((string)$data[$cfg['json']])) : '';
        if ($value && ($replace || !$current)) {
            update_post_meta($post_id, $meta_key, sanitize_textarea_field($value));
            $out['updated'][] = $cfg['label'];
        }
    }
    if (in_array($mode, array('all_missing','image_alt'), true)) {
        $thumb_id = get_post_thumbnail_id($post_id);
        if ($thumb_id) {
            $current_alt = (string)get_post_meta($thumb_id, '_wp_attachment_image_alt', true);
            if ($replace || !$current_alt) {
                $alt = '';
                if (!empty($data['image_alt'])) $alt = trim(wp_strip_all_tags((string)$data['image_alt']));
                if (!$alt) $alt = slabseo21_generate_image_alt_for_post($post_id);
                if (is_wp_error($alt)) {
                    $out['note'] .= ' ALT not updated: ' . $alt->get_error_message();
                } elseif ($alt) {
                    update_post_meta($thumb_id, '_wp_attachment_image_alt', sanitize_text_field($alt));
                    $out['updated'][] = 'Featured image ALT';
                }
            }
        } elseif ($mode === 'image_alt') {
            $out['note'] .= ' No featured image.';
        }
    }
    if ($mode === 'faq_insert') {
        $faq_result = slabseo22_generate_and_insert_faq($post_id, $replace);
        if (is_wp_error($faq_result)) { $out['note'] .= ' FAQ not inserted: ' . $faq_result->get_error_message(); }
        elseif ($faq_result) { $out['updated'][] = 'Visible FAQ + FAQ schema'; }
    }
    if ($mode === 'affiliate_disclosure') {
        $disc = slabseo22_insert_affiliate_disclosure($post_id, $replace);
        if (is_wp_error($disc)) { $out['note'] .= ' Disclosure not inserted: ' . $disc->get_error_message(); }
        elseif ($disc) { $out['updated'][] = 'Affiliate disclosure'; }
    }
    $out['ok'] = true;
    if (!$out['note']) $out['note'] = $out['updated'] ? 'Saved blanks/replacements.' : 'Nothing needed or existing fields protected.';
    return $out;
}

function slabseo21_generate_post_ai_fields($post_id) {
    return new WP_Error('barndseo_free_no_ai', 'AI generation is not available in Barnd AI SEO Free.');
}

function slabseo21_generate_image_alt_for_post($post_id) {
    return new WP_Error('barndseo_free_no_ai', 'AI generation is not available in Barnd AI SEO Free.');
}

function slabseo21_call_openai_json($prompt, $o) {
    return new WP_Error('barndseo_free_no_ai', 'AI generation is not available in Barnd AI SEO Free.');
}
function slabseo21_call_openai_text($prompt, $o) {
    return new WP_Error('barndseo_free_no_ai', 'AI generation is not available in Barnd AI SEO Free.');
}
function slabseo21_call_openai_raw($body, $o) {
    return new WP_Error('barndseo_free_no_ai', 'AI generation is not available in Barnd AI SEO Free.');
}


/*
 * Barnd AI SEO v2.2 helpers
 * - Better Bulk Fixer filters
 * - Ignore from audit meta box
 * - Bulk FAQ generator/inserter
 * - Bulk affiliate disclosure inserter
 */
function slabseo22_is_ignored($post_id) {
    return get_post_meta($post_id, '_slabseo_ignore_audit', true) === '1';
}

function slabseo22_is_product_finder_post($post_id) {
    $slugs = array('dog-guides','cat-guides','pet-product-guides','home-gadgets','diy-tools','pet-friendly-home','bath-glow','gifts','deals','smart-services','pets','home-diy','best-picks','buying-guides');
    $terms = wp_get_post_terms($post_id, 'category', array('fields'=>'slugs'));
    if (is_wp_error($terms) || empty($terms)) return false;
    foreach ($terms as $slug) {
        if (in_array($slug, $slugs, true)) return true;
    }
    $content = (string)get_post_field('post_content', $post_id);
    return (stripos($content, 'Tail&Home product research draft') !== false || stripos($content, 'Product Snapshot') !== false || stripos($content, 'Draft Verdict') !== false);
}

function slabseo22_add_ignore_box() {
    foreach (array('post','page') as $screen) {
        add_meta_box('slabseo22_ignore_box', 'Barnd AI SEO Audit Control', 'slabseo22_render_ignore_box', $screen, 'side', 'default');
    }
}

function slabseo22_render_ignore_box($post) {
    wp_nonce_field('slabseo22_ignore_save', 'slabseo22_ignore_nonce');
    $ignored = slabseo22_is_ignored($post->ID);
    echo '<p><label><input type="checkbox" name="slabseo22_ignore_audit" value="1" ' . checked($ignored, true, false) . '> Ignore this post/page from Barnd AI SEO Audit and default Bulk Fixer lists.</label></p>';
    echo '<p class="description">Use this for old imported posts, tests, archive-style content, or pages you do not want to fix now.</p>';
}

function slabseo22_save_ignore_meta($post_id, $post) {
    if (wp_is_post_revision($post_id) || wp_is_post_autosave($post_id)) return;
    if (!isset($_POST['slabseo22_ignore_nonce']) || !wp_verify_nonce(sanitize_text_field(wp_unslash($_POST['slabseo22_ignore_nonce'])), 'slabseo22_ignore_save')) return;
    if (!current_user_can('edit_post', $post_id)) return;
    if (isset($_POST['slabseo22_ignore_audit'])) update_post_meta($post_id, '_slabseo_ignore_audit', '1');
    else delete_post_meta($post_id, '_slabseo_ignore_audit');
}

function slabseo22_generate_and_insert_faq($post_id, $replace=false) {
    return new WP_Error('barndseo_free_no_ai', 'AI FAQ generation is not available in Barnd AI SEO Free.');
}

function slabseo22_insert_affiliate_disclosure($post_id, $replace=false) {
    $post = get_post($post_id);
    if (!$post) return new WP_Error('missing_post', 'Post not found.');
    $content = (string)$post->post_content;
    $text = wp_strip_all_tags($content);
    if (function_exists('slabseo14_has_affiliate_links') && !slabseo14_has_affiliate_links($content)) return false;
    if (!$replace && function_exists('slabseo14_has_affiliate_disclosure') && slabseo14_has_affiliate_disclosure($text)) return false;
    $disclosure = '<!-- slabseo-affiliate-disclosure-start -->\n<p><em>Affiliate disclosure: This page may contain affiliate links. If you buy through these links, this site may earn a commission at no extra cost to you.</em></p>\n<!-- slabseo-affiliate-disclosure-end -->';
    $pattern = '/<!--\s*slabseo-affiliate-disclosure-start\s*-->.*?<!--\s*slabseo-affiliate-disclosure-end\s*-->/is';
    if (preg_match($pattern, $content)) $content = preg_replace($pattern, $disclosure, $content, 1);
    else {
        // Place after first paragraph when possible, otherwise at top.
        if (preg_match('/<\/p>/i', $content)) $content = preg_replace('/<\/p>/i', '</p>' . "\n\n" . $disclosure, $content, 1);
        else $content = $disclosure . "\n\n" . $content;
    }
    $updated = wp_update_post(array('ID'=>$post_id, 'post_content'=>$content), true);
    if (is_wp_error($updated)) return $updated;
    return true;
}


/*
 * Barnd AI SEO v2.4
 * Google Google Performance Import / CTR Opportunity Planner
 * - Manual Search Console CSV import/paste
 * - Low CTR and striking-distance opportunity table
 * - Maps page URLs to WordPress posts/pages when possible
 * - Manual Google Performance opportunity review without overwriting live SEO fields
 */
// Search Console submenu is registered inside the main Barnd AI SEO menu for reliable visibility.

function slabseo24_search_console_page() {
    if (!current_user_can('manage_options')) return;

    $message = '';
    $rows = get_option('slabseo24_gsc_rows', array());
    if (!is_array($rows)) $rows = array();

    if (isset($_POST['slabseo24_clear']) && check_admin_referer('slabseo24_gsc')) {
        delete_option('slabseo24_gsc_rows');
        $rows = array();
        $message = 'Search Console import cleared.';
    }

    if (isset($_POST['slabseo24_import']) && check_admin_referer('slabseo24_gsc')) {
        $csv = isset($_POST['slabseo24_csv']) ? wp_unslash($_POST['slabseo24_csv']) : '';
        if (isset($_FILES['slabseo24_csv_file']) && !empty($_FILES['slabseo24_csv_file']['tmp_name']) && is_uploaded_file($_FILES['slabseo24_csv_file']['tmp_name'])) {
            $max_csv_bytes = 2 * 1024 * 1024;
            $upload_size = isset($_FILES['slabseo24_csv_file']['size']) ? (int)$_FILES['slabseo24_csv_file']['size'] : 0;
            if ($upload_size <= 0 || $upload_size > $max_csv_bytes) {
                $message = 'CSV upload must be smaller than 2 MB.';
            } else {
                $uploaded = file_get_contents($_FILES['slabseo24_csv_file']['tmp_name']);
                if ($uploaded !== false && trim($uploaded) !== '') {
                    $csv = $uploaded;
                }
            }
        }
        if ($message === '') {
            $parsed = slabseo24_parse_gsc_csv($csv);
            if (is_wp_error($parsed)) $message = $parsed->get_error_message();
            else {
                update_option('slabseo24_gsc_rows', $parsed, false);
                $rows = $parsed;
                $message = 'Imported ' . count($rows) . ' Search Console rows.';
            }
        }
    }

    $opps = slabseo24_find_gsc_opportunities($rows);
    $site_url = home_url('/');
    $barnd_opts = get_option('slab_seo_assistant_options', array());
    $barnd_mode = isset($barnd_opts['setup_mode']) ? sanitize_key($barnd_opts['setup_mode']) : 'simple';
    ?>
    <div class="wrap slabseo24-wrap">
        <h1>Google Performance Import</h1>
        <?php if ($barnd_mode === 'simple'): ?>
            <div class="notice notice-info inline" style="margin:12px 0 16px;"><p><strong>This is an Agency / Advanced tool.</strong> Google Performance Import is hidden in Simple Mode because it requires exporting a Google Search Console report. Simple users can start with <strong>SEO Audit & Quick Fixes</strong> and <strong>Image SEO</strong> instead.</p></div>
            <div class="slabseo24-box">
                <h2>Recommended Simple Mode path</h2>
                <ol>
                    <li>Run <strong>SEO Audit & Quick Fixes</strong>.</li>
                    <li>Fix missing titles and descriptions directly in the table.</li>
                    <li>Open <strong>Image SEO</strong> and fill missing ALT text.</li>
                    <li>Switch to Agency Mode later if you want to import Google Search Console performance reports.</li>
                </ol>
                <p><a class="button button-primary" href="<?php echo esc_url(admin_url('admin.php?page=slabseo-audit')); ?>">Open SEO Audit</a> <a class="button" href="<?php echo esc_url(admin_url('admin.php?page=slabseo-setup-wizard')); ?>">Change Setup Mode</a></p>
            </div>
            <?php return; ?>
        <?php endif; ?>
        <p>Upload or paste a Google Search Console Pages export to find pages with impressions, low CTR, and ranking opportunities. No Google login is required in Free mode.</p>
        <style>
            .slabseo24-box{background:#fff;border:1px solid #dcdcde;border-radius:8px;padding:14px;margin:14px 0}.slabseo24-grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(210px,1fr));gap:14px}.slabseo24-card{background:#fff;border:1px solid #dcdcde;border-radius:8px;padding:14px}.slabseo24-big{font-size:26px;font-weight:700}.slabseo24-small{color:#646970;font-size:12px}.slabseo24-bad{color:#b32d2e;font-weight:600}.slabseo24-good{color:#007017;font-weight:600}.slabseo24-url{word-break:break-all}.slabseo24-table td{vertical-align:top}.slabseo24-pill{display:inline-block;background:#f0f0f1;border-radius:999px;padding:2px 8px;font-size:12px;margin:2px}
        </style>
        <?php if ($message): ?><div class="notice notice-info"><p><?php echo esc_html($message); ?></p></div><?php endif; ?>

        <div class="slabseo24-grid">
            <div class="slabseo24-card"><div class="slabseo24-big"><?php echo count($rows); ?></div><p>Total imported rows</p></div>
            <div class="slabseo24-card"><div class="slabseo24-big"><?php echo count($opps); ?></div><p>Priority opportunities</p></div>
            <div class="slabseo24-card"><p><strong>Current property target:</strong><br><span class="slabseo24-url"><?php echo esc_html($site_url); ?></span></p></div>
        </div>

        <div class="slabseo24-box">
            <h2>Import Google Search Console Pages Report</h2>
            <ol>
                <li>Open Google Search Console and choose your website property.</li>
                <li>Go to <strong>Performance → Search results</strong>.</li>
                <li>Choose the last 3 months for a normal review.</li>
                <li>Open the <strong>Pages</strong> tab.</li>
                <li>Click <strong>Export</strong> and use the Pages CSV file.</li>
                <li>Upload the file below.</li>
            </ol>
            <p class="description"><strong>Easy way:</strong> upload the <code>Pages.csv</code> file from Google Search Console. You do not need to open Excel or copy cells.</p>
            <p class="description">Supported formats: Google CSV, Excel copy/paste with tabs, comma CSV, semicolon CSV. Use the Pages report when possible. Supported URL columns include <code>Top pages</code>, <code>Page</code>, <code>URL</code>, and <code>Landing page</code>.</p>
            <form method="post" enctype="multipart/form-data">
                <?php wp_nonce_field('slabseo24_gsc'); ?>
                <p><label><strong>Upload Pages.csv directly:</strong><br><input type="file" name="slabseo24_csv_file" accept=".csv,text/csv,text/plain"></label></p>
                <p><strong>Or paste CSV / Excel rows here:</strong></p>
                <textarea name="slabseo24_csv" rows="8" style="width:100%;font-family:monospace;" placeholder="Top pages,Clicks,Impressions,CTR,Position&#10;https://tailandhome.org/,1,3,33.33%,4"></textarea>
                <p>
                    <button class="button button-primary" name="slabseo24_import" value="1">Import / Replace CSV Data</button>
                    <button class="button" name="slabseo24_clear" value="1" onclick="return confirm('Clear imported Search Console data?')">Clear Imported Data</button>
                </p>
            </form>
        </div>

        <div class="slabseo24-box">
            <h2>What to fix next</h2>
            <p>After import, Barnd looks for pages Google already shows but users may not click enough. Use these rows as a manual cleanup list, not an automatic ranking promise.</p>
            <ul>
                <li><strong>High impressions + low CTR:</strong> rewrite the SEO title and Google preview description so the benefit is clearer.</li>
                <li><strong>Position 4–20:</strong> improve headings, internal links, FAQ/checklist sections, and page usefulness.</li>
                <li><strong>Keyword/page fit:</strong> if a query is available, use it naturally in the title, H1/H2, first paragraph, and image ALT only when accurate.</li>
            </ul>
        </div>

        <form method="post">
            <?php wp_nonce_field('slabseo24_gsc'); ?>
            <div class="slabseo24-box">
                <h2>Priority CTR / Ranking Opportunities</h2>
                <p class="description">Default priority: impressions ≥ 50 and CTR below 2.5%, or average position between 4 and 20. Use these rows to decide which pages need better titles, descriptions, internal links, content structure, or local/details proof.</p>
                <table class="widefat striped slabseo24-table">
                    <thead><tr><th>Search Query / Page</th><th>Metrics</th><th>Matched WP Content</th><th>Opportunity</th><th>Suggested Manual Action</th></tr></thead>
                    <tbody>
                    <?php if (!$opps): ?>
                        <tr><td colspan="5">No imported opportunities yet. Upload or paste a Google Search Console Pages export above.</td></tr>
                    <?php else: foreach (array_slice($opps, 0, 100) as $key => $r):
                        $post_id = slabseo24_url_to_post_id($r['page']);
                    ?>
                        <tr>
                            <td>
                                <?php if ($r['query']): ?><strong><?php echo esc_html($r['query']); ?></strong><br><?php endif; ?>
                                <span class="slabseo24-url"><a href="<?php echo esc_url($r['page']); ?>" target="_blank"><?php echo esc_html($r['page']); ?></a></span>
                            </td>
                            <td>Clicks: <?php echo esc_html($r['clicks']); ?><br>Impressions: <?php echo esc_html($r['impressions']); ?><br>CTR: <?php echo esc_html($r['ctr']); ?>%<br>Position: <?php echo esc_html($r['position']); ?></td>
                            <td><?php if ($post_id): ?><a href="<?php echo esc_url(get_edit_post_link($post_id)); ?>"><?php echo esc_html(get_the_title($post_id)); ?></a><?php else: ?><span class="slabseo24-bad">No match</span><?php endif; ?></td>
                            <td><?php foreach ($r['reasons'] as $reason): ?><span class="slabseo24-pill"><?php echo esc_html($reason); ?></span><?php endforeach; ?></td>
                            <td><?php echo wp_kses_post(slabseo21_gsc_manual_action($r, $post_id)); ?></td>
                        </tr>
                    <?php endforeach; endif; ?>
                    </tbody>
                </table>
            </div>
        </form>

        <div class="slabseo24-box">
            <h2>Next step after import</h2>
            <ol>
                <li>Open the matched post/page.</li>
                <li>Review the page title, meta description, headings, internal links, and CTA.</li>
                <li>Recheck Search Console after Google recrawls the page.</li>
            </ol>
        </div>
    </div>
    <?php
}

function slabseo24_parse_gsc_csv($csv) {
    $csv = trim((string)$csv);
    if ($csv === '') return new WP_Error('empty_csv', 'No CSV data pasted or uploaded. Use the Pages.csv file from the Google Search Console export ZIP.');

    // Remove UTF-8 BOM and normalize line endings.
    $csv = preg_replace('/^\xEF\xBB\xBF/', '', $csv);
    $lines = preg_split('/\r\n|\r|\n/', $csv);
    $lines = array_values(array_filter($lines, function($line){ return trim((string)$line) !== ''; }));
    if (count($lines) < 2) return new WP_Error('short_csv', 'CSV needs a header row and at least one data row. Upload Pages.csv or paste the rows including the header.');

    $header_line = array_shift($lines);
    $delimiter = slabseo24_detect_csv_delimiter($header_line);
    $header = str_getcsv($header_line, $delimiter);

    // If Excel copy/paste was used, fields are often tab-delimited.
    if (count($header) < 2 && strpos($header_line, "\t") !== false) {
        $delimiter = "\t";
        $header = str_getcsv($header_line, $delimiter);
    }

    $map = array();
    foreach ($header as $i => $h) {
        $key = slabseo24_normalize_gsc_header($h);
        if ($key !== '') $map[$key] = $i;
    }

    $get = function($row, $names) use ($map) {
        foreach ((array)$names as $name) {
            $k = slabseo24_normalize_gsc_header($name);
            if (isset($map[$k])) return isset($row[$map[$k]]) ? trim((string)$row[$map[$k]]) : '';
        }
        return '';
    };

    $out = array();
    $n = 0;
    foreach ($lines as $line) {
        if (trim($line) === '') continue;
        $row = str_getcsv($line, $delimiter);
        if (count($row) < 2 && $delimiter !== "\t" && strpos($line, "\t") !== false) {
            $row = str_getcsv($line, "\t");
        }

        $query = $get($row, array('query','queries','top queries','search query'));
        $page = $get($row, array('page','pages','top pages','top page','url','urls','landing page','landing pages','page url','page path'));

        // Google Pages.csv usually has the URL in the first column named "Top pages".
        if (!$page && isset($row[0]) && filter_var(trim((string)$row[0]), FILTER_VALIDATE_URL)) {
            $page = trim((string)$row[0]);
        }
        if (!$page && filter_var($query, FILTER_VALIDATE_URL)) { $page = $query; $query = ''; }
        if (!$page || !filter_var($page, FILTER_VALIDATE_URL)) continue;

        $clicks = slabseo24_parse_number($get($row, array('clicks','click')));
        $impressions = slabseo24_parse_number($get($row, array('impressions','impression')));
        $ctr = slabseo24_parse_percent($get($row, array('ctr','click through rate','click-through rate')));
        $position = slabseo24_parse_float($get($row, array('position','average position','avg position')));
        $key = md5(strtolower($query . '|' . $page));
        $out[$key] = array('query'=>$query,'page'=>$page,'clicks'=>$clicks,'impressions'=>$impressions,'ctr'=>$ctr,'position'=>$position);
        $n++;
        if ($n >= 2000) break;
    }
    if (!$out) return new WP_Error('no_rows', 'No valid Search Console rows found. Use Pages.csv from the export ZIP. If copying from Excel, select the header row plus URL rows, not just the grey selected area.');
    return $out;
}

function slabseo24_detect_csv_delimiter($line) {
    $delimiters = array(",", "\t", ";");
    $best = ",";
    $best_count = 0;
    foreach ($delimiters as $d) {
        $count = count(str_getcsv((string)$line, $d));
        if ($count > $best_count) { $best_count = $count; $best = $d; }
    }
    return $best;
}

function slabseo24_normalize_gsc_header($h) {
    $h = strtolower(trim((string)$h));
    $h = preg_replace('/^\xEF\xBB\xBF/', '', $h);
    $h = str_replace(array(' ', '-', '_', '/', '\\'), '', $h);
    return $h;
}

function slabseo24_parse_number($v) { $v = preg_replace('/[^0-9.]/', '', (string)$v); return $v === '' ? 0 : intval(floatval($v)); }
function slabseo24_parse_float($v) { $v = preg_replace('/[^0-9.]/', '', (string)$v); return $v === '' ? 0 : round(floatval($v), 2); }
function slabseo24_parse_percent($v) { $v = trim((string)$v); $v = str_replace('%', '', $v); $v = preg_replace('/[^0-9.]/', '', $v); return $v === '' ? 0 : round(floatval($v), 2); }

function slabseo24_find_gsc_opportunities($rows) {
    $out = array();
    foreach ($rows as $key => $r) {
        $reasons = array();
        $imp = intval($r['impressions']);
        $ctr = floatval($r['ctr']);
        $pos = floatval($r['position']);
        if ($imp >= 50 && $ctr > 0 && $ctr < 2.5) $reasons[] = 'low CTR';
        if ($imp >= 50 && $ctr == 0) $reasons[] = 'impressions no clicks';
        if ($pos >= 4 && $pos <= 20) $reasons[] = 'striking distance';
        if ($imp >= 500 && $ctr < 4) $reasons[] = 'high impression page';
        if ($reasons) {
            $r['reasons'] = $reasons;
            $out[$key] = $r;
        }
    }
    uasort($out, function($a, $b){ return intval($b['impressions']) <=> intval($a['impressions']); });
    return $out;
}

function slabseo24_url_to_post_id($url) {
    $id = url_to_postid($url);
    if ($id) return $id;
    $path = trim((string)parse_url($url, PHP_URL_PATH), '/');
    if (!$path) return 0;
    $slug = basename($path);
    $post = get_page_by_path($slug, OBJECT, array('post','page'));
    return $post ? intval($post->ID) : 0;
}


function slabseo21_gsc_manual_action($r, $post_id = 0) {
    $parts = array();
    $reasons = array_map('strtolower', (array)($r['reasons'] ?? array()));
    if (in_array('low ctr', $reasons, true) || in_array('impressions no clicks', $reasons, true) || in_array('high impression page', $reasons, true)) {
        $parts[] = 'Rewrite the SEO title and Google preview description to make the page benefit more specific.';
    }
    if (in_array('striking distance', $reasons, true)) {
        $parts[] = 'Improve H1/H2 structure, add useful internal links, and add a visible FAQ/checklist if it helps the visitor.';
    }
    if (!empty($r['query'])) {
        $parts[] = 'Use the query <code>' . esc_html($r['query']) . '</code> naturally in the title, heading, opening paragraph, or image ALT only when it accurately describes the page.';
    }
    if ($post_id) {
        $meta_desc = (string)get_post_meta($post_id, '_slabseo_description', true);
        if (trim($meta_desc) === '') $parts[] = 'This matched WordPress page is missing a Barnd meta description. Fix it in SEO Audit & Quick Fixes.';
    }
    if (!$parts) $parts[] = 'Review the page title, meta description, headings, internal links, and CTA.';
    return '<ul><li>' . implode('</li><li>', array_map('wp_kses_post', $parts)) . '</li></ul>';
}

function slabseo24_generate_gsc_snippet_suggestion($post_id, $row) {
    return new WP_Error('barndseo_free_no_ai', 'AI snippet suggestions are not available in Barnd AI SEO Free.');
}
